export type RoomType =
  | 'chambre'
  | 'sejour'
  | 'cuisine'
  | 'sdb'
  | 'wc'
  | 'couloir'
  | 'bureau'
  | 'garage'
  | 'terrasse'
  | 'autre';

export type WallSide = 'top' | 'right' | 'bottom' | 'left';

export type FinishStyle = 'blanc_mat' | 'anthracite' | 'laiton' | 'alu';

export type WallFinishId =
  | 'peinture_blanche'
  | 'peinture_lin'
  | 'peinture_sauge'
  | 'peinture_terracotta'
  | 'peinture_bleu_nuit'
  | 'carrelage_blanc'
  | 'carrelage_marbre'
  | 'carrelage_ardoise'
  | 'brique';

export type FloorFinishId =
  | 'auto'
  | 'parquet_chene'
  | 'parquet_noyer'
  | 'carrelage_gris'
  | 'carrelage_travertin'
  | 'beton_cire';

export type ItemType =
  | 'light'
  | 'sconce'
  | 'spots'
  | 'neon'
  | 'switch'
  | 'dimmer'
  | 'motion'
  | 'pushbutton'
  | 'socket'
  | 'socket2'
  | 'usb_socket'
  | 'spec'
  | 'irve'
  | 'rj45'
  | 'heater'
  | 'ac_split'
  | 'ac_outdoor'
  | 'thermostat'
  | 'cooktop'
  | 'smoke'
  | 'camera'
  | 'nvr_screen'
  | 'alarm_panel'
  | 'siren'
  | 'intercom'
  | 'panel'
  | 'door'
  | 'window'
  | 'staircase'
  | 'bed1'
  | 'bed2'
  | 'sofa'
  | 'table'
  | 'desk'
  | 'wardrobe'
  | 'tv'
  | 'fridge'
  | 'pc'
  | 'counter'
  | 'bath'
  | 'shower'
  | 'sink'
  | 'wc';

export type ToolId = 'select' | 'room' | ItemType;

export type ToolTabId =
  | 'pieces'
  | 'eclairage'
  | 'prises'
  | 'surveillance'
  | 'mobilier';

export type AppViewMode = 'plan2d' | 'cablage' | 'tableau' | 'vue3d' | 'simu' | 'devis';

export interface FloorLevel {
  id: number;
  name: string;
  elevationIndex: number; // 0 = RDC, 1 = 1er étage, -1 = Sous-sol
}

export interface Room {
  id: number;
  floorId: number;
  x: number; // cm
  y: number; // cm
  w: number; // cm
  h: number; // cm
  type: RoomType;
  name: string;
  wallFinish?: WallFinishId;
  floorFinish?: FloorFinishId;
}

export interface PlanItem {
  id: number;
  floorId: number;
  type: ItemType;
  x: number; // cm
  y: number; // cm
  roomId: number;
  side: WallSide | null;
  rot: number;
  name: string;
  watts: number;
  len?: number;
  w?: number;
  h?: number;
  wpm?: number;
  count?: number;
  spacing?: number;
  // Staircase LED parameters
  stepCount?: number;
  ledColor?: 'warm' | 'amber' | 'neutral';
  wattsPerStep?: number;
  // Surveillance camera FOV & orientation parameters
  camPlacement?: 'interior' | 'exterior';
  camAngle?: number; // degrees (-75 to +75 relative to wall normal)
  camFov?: number; // degrees (45 to 135)
  camRange?: number; // cm (200 to 1200)
  // 3D placement surface & elevation
  elevationCm?: number;
  mountSurface?: 'floor' | 'wall' | 'ceiling' | 'furniture';
  mountHostId?: number | null;
  locked?: boolean;
  /** Face du mur sur laquelle l'équipement est fixé : 'in' (intérieur, défaut) ou 'out' (face extérieure). */
  face?: 'in' | 'out';
  /** Interrupteur / variateur / poussoir qui commande ce luminaire (absent = interrupteur le plus proche de la pièce). */
  switchId?: number;
  /** Équipement ajouté automatiquement pour l'équipement parent (id). */
  autoOf?: number;
  /** Rôle de l'équipement associé (ex. 'outdoor', 'thermo', 'switch'…). */
  autoRole?: string;
  /** true = l'utilisateur l'a déplacé à la main : il ne suit plus son parent. */
  autoDetached?: boolean;
}

export type GroundStyle = 'neutre' | 'herbe' | 'terre' | 'sable' | 'dalles';

export type EnvKind =
  | 'tree'
  | 'palm'
  | 'bush'
  | 'hedge'
  | 'fence'
  | 'wall'
  | 'gate'
  | 'car'
  | 'path'
  | 'lawn'
  | 'pool'
  | 'garden_light'
  | 'generator'
  | 'solar'
  | 'tank';

/** Élément d'environnement extérieur (jardin, clôture, véhicule…), posé sur le sol de la vue 3D. */
export interface EnvObject {
  id: number;
  kind: EnvKind;
  x: number; // cm (même repère que le plan)
  y: number; // cm
  rot: number; // degrés
  scale?: number; // 0.5 – 2
  len?: number; // cm (longueur : clôture, haie, allée, portail)
  w?: number; // cm (largeur : pelouse, piscine, allée)
  h?: number; // cm (profondeur : pelouse, piscine)
  locked?: boolean;
  name?: string;
}

export interface LinkedApplianceExtra {
  item: PlanItem;
  watts: number;
}

export type CircuitKind =
  | 'light'
  | 'spot'
  | 'neon'
  | 'stair_led'
  | 'socket'
  | 'heat'
  | 'hvac'
  | 'spec'
  | 'cook'
  | 'irve'
  | 'surveillance';

export interface ComputedCircuit {
  id: string;
  kind: CircuitKind;
  name: string;
  items: PlanItem[];
  sectionMm2: number;
  breakerA: number;
  dropMaxPct: number;
  diffType: 'A' | 'AC';
  warnings: string[];
  extras: LinkedApplianceExtra[];
  color: string;
  watts: number;
  points: number;
  currentA: number;
  chain: { x: number; y: number; floorId?: number; roomId?: number; itemId?: number }[];
  lengthM: number | null;
  dropPct: number | null;
}

export interface CheckMessage {
  level: 'ok' | 'warn' | 'info';
  text: string;
}

export interface RoomReport {
  room: Room;
  floorName: string;
  checks: CheckMessage[];
  powerW: number;
  areaM2: number;
  warnCount: number;
}

export interface DifferentialGroup {
  id: string;
  rowIndex: number;
  type: 'A' | 'AC';
  ratingA: 40 | 63;
  sensitivityMa: 30;
  circuits: ComputedCircuit[];
  totalWatts: number;
  modulesCount: number;
}

export interface DistributionPanelModel {
  agcpRatingA: 30 | 45 | 60;
  hasSurgeProtector: boolean;
  hasJourNuitContactor: boolean;
  hasTelerupteur: boolean;
  hasStairController: boolean;
  rows: DifferentialGroup[];
  totalModules: number;
  recommendedRows: number;
}

export interface MaterialRow {
  id: string;
  category: 'Protection' | 'Appareillage' | 'Câblage' | 'Sécurité' | 'Automatisme';
  label: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  total: number;
}

export interface PlanProjectData {
  floors: FloorLevel[];
  activeFloorId: number;
  finishStyle: FinishStyle;
  rooms: Room[];
  items: PlanItem[];
  nextId: number;
  k: number;
  sockMode: 8 | 12;
  includeSurgeProtector: boolean;
  subscriptionKva: 6 | 9 | 12 | 15;
  /** Environnement extérieur de la vue 3D (arbres, clôtures…). */
  env?: EnvObject[];
  groundStyle?: GroundStyle;
}

export interface SelectionTarget {
  kind: 'room' | 'item';
  id: number;
}

// Manual Wiring Lab & Component Library types
export type LibraryCategory =
  | 'comptage'
  | 'protection'
  | 'automatisme'
  | 'surveillance'
  | 'style'
  | 'charges';

export type WireType = 'phase' | 'neutral' | 'earth' | 'command' | 'signal';

export interface ComponentTerminal {
  id: string;
  label: string;
  wireType: WireType;
  rx: number; // relative x inside component box
  ry: number; // relative y inside component box
}

export interface LibraryComponentDef {
  typeId: string;
  category: LibraryCategory;
  name: string;
  shortName: string;
  spec: string;
  description: string;
  modulesDin?: number;
  width: number;
  height: number;
  interactive?: 'toggle' | 'pushbutton' | 'sensor' | 'clock';
  planToolType?: ItemType;
  terminals: ComponentTerminal[];
}

export interface ManualNode {
  id: string;
  typeId: string;
  label: string;
  x: number;
  y: number;
  stateOn: boolean;
  rating?: string;
}

export interface ManualWire {
  id: string;
  fromNodeId: string;
  fromTerminalId: string;
  toNodeId: string;
  toTerminalId: string;
  wireType: WireType;
}
