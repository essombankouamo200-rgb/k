export type TaskStatus = 'a_faire' | 'en_cours' | 'revue' | 'termine';

export type TaskPriority = 'urgente' | 'haute' | 'normale' | 'basse';

export type TaskCategory = 'Design' | 'Frontend' | 'Backend' | 'Infrastructure' | 'Produit';

export type WorkspaceView = 'kanban' | 'liste' | 'chronologie' | 'synthese';

export type SortField = 'code' | 'titre' | 'statut' | 'priorite' | 'echeance' | 'heuresEstimees';
export type SortDirection = 'asc' | 'desc';

export interface TeamMember {
  id: string;
  nom: string;
  role: string;
  initiales: string;
  avatarUrl: string;
  capaciteHebdo: number;
}

export interface Subtask {
  id: string;
  titre: string;
  terminee: boolean;
}

export interface Task {
  id: string;
  code: string;
  projectId: string;
  titre: string;
  description: string;
  statut: TaskStatus;
  priorite: TaskPriority;
  categorie: TaskCategory;
  assigneeId: string;
  dateDebut: string; // YYYY-MM-DD
  echeance: string; // YYYY-MM-DD
  heuresEstimees: number;
  heuresPassees: number;
  sousTaches: Subtask[];
}

export interface Project {
  id: string;
  cle: string;
  nom: string;
  description: string;
  objectifSprint: string;
}

export interface WorkspaceState {
  projects: Project[];
  tasks: Task[];
  activeProjectId: string;
}
