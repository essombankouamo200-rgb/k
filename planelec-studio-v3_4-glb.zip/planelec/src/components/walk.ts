import { PlanProjectData, WallSide } from '../types/planelec';
import { TYPES } from '../data/catalog';
import { SCALE_3D as SCALE, WALL_THICK_M } from '../utils/snap3d';

/** Rayon du « corps » du marcheur (m). */
export const WALK_RADIUS = 0.22;
export const EYE_HEIGHT = 1.65;

interface Rect {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
}

interface Gap extends Rect {}

interface Obb {
  cx: number;
  cz: number;
  hw: number;
  hd: number;
  cos: number;
  sin: number;
}

export interface WalkWorld {
  walls: Rect[];
  gaps: Gap[];
  furniture: Obb[];
  /** Emprise globale de la maison (m) pour savoir si l'on est dehors. */
  bounds: Rect | null;
}

function circleHitsRect(px: number, pz: number, r: number, b: Rect): boolean {
  const cx = Math.max(b.x0, Math.min(px, b.x1));
  const cz = Math.max(b.z0, Math.min(pz, b.z1));
  const dx = px - cx;
  const dz = pz - cz;
  return dx * dx + dz * dz < r * r;
}

function circleHitsObb(px: number, pz: number, r: number, o: Obb): boolean {
  const dx = px - o.cx;
  const dz = pz - o.cz;
  const lx = dx * o.cos + dz * o.sin;
  const lz = -dx * o.sin + dz * o.cos;
  const qx = Math.max(-o.hw, Math.min(lx, o.hw));
  const qz = Math.max(-o.hd, Math.min(lz, o.hd));
  const ex = lx - qx;
  const ez = lz - qz;
  return ex * ex + ez * ez < r * r;
}

/** Construit les obstacles (murs pleins, passages de portes, meubles) d'un étage. */
export function buildWalkWorld(project: PlanProjectData, floorId: number): WalkWorld {
  const t = WALL_THICK_M;
  const walls: Rect[] = [];
  const gaps: Gap[] = [];
  const furniture: Obb[] = [];
  let minX = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxZ = -Infinity;

  for (const r of project.rooms) {
    if (r.floorId !== floorId || r.type === 'terrasse') continue;
    const rx = r.x * SCALE;
    const rz = r.y * SCALE;
    const rw = r.w * SCALE;
    const rd = r.h * SCALE;
    minX = Math.min(minX, rx);
    minZ = Math.min(minZ, rz);
    maxX = Math.max(maxX, rx + rw);
    maxZ = Math.max(maxZ, rz + rd);
    walls.push(
      { x0: rx - t / 2, x1: rx + rw + t / 2, z0: rz - t / 2, z1: rz + t / 2 },
      { x0: rx - t / 2, x1: rx + rw + t / 2, z0: rz + rd - t / 2, z1: rz + rd + t / 2 },
      { x0: rx - t / 2, x1: rx + t / 2, z0: rz - t / 2, z1: rz + rd + t / 2 },
      { x0: rx + rw - t / 2, x1: rx + rw + t / 2, z0: rz - t / 2, z1: rz + rd + t / 2 }
    );
  }

  const across = t / 2 + WALK_RADIUS + 0.06;
  for (const it of project.items) {
    if (it.floorId !== floorId) continue;
    const T = TYPES[it.type];
    if (it.type === 'door' && it.side) {
      const half = ((it.len ?? T.len ?? 90) * SCALE) / 2 - WALK_RADIUS * 0.4;
      if (half <= 0.05) continue;
      const cx = it.x * SCALE;
      const cz = it.y * SCALE;
      const alongX = it.side === 'top' || it.side === 'bottom';
      gaps.push(
        alongX
          ? { x0: cx - half, x1: cx + half, z0: cz - across, z1: cz + across }
          : { x0: cx - across, x1: cx + across, z0: cz - half, z1: cz + half }
      );
      continue;
    }
    if (
      T.furn &&
      it.type !== 'tv' &&
      it.type !== 'pc' &&
      it.type !== 'staircase' &&
      it.mountSurface !== 'wall' &&
      it.mountSurface !== 'furniture' &&
      !(it.elevationCm && it.elevationCm > 0)
    ) {
      const w = ((it.w ?? T.w ?? 80) * SCALE) / 2;
      const d = ((it.h ?? T.h ?? 80) * SCALE) / 2;
      const a = -((it.rot || 0) * Math.PI) / 180;
      furniture.push({
        cx: it.x * SCALE,
        cz: it.y * SCALE,
        hw: w,
        hd: d,
        cos: Math.cos(a),
        sin: Math.sin(a),
      });
    }
  }

  return {
    walls,
    gaps,
    furniture,
    bounds: Number.isFinite(minX) ? { x0: minX, x1: maxX, z0: minZ, z1: maxZ } : null,
  };
}

function blocked(world: WalkWorld, x: number, z: number): boolean {
  const r = WALK_RADIUS;
  let inGap = false;
  for (const g of world.gaps) {
    if (x >= g.x0 && x <= g.x1 && z >= g.z0 && z <= g.z1) {
      inGap = true;
      break;
    }
  }
  if (!inGap) {
    for (const w of world.walls) if (circleHitsRect(x, z, r, w)) return true;
  }
  for (const f of world.furniture) if (circleHitsObb(x, z, r * 0.8, f)) return true;
  return false;
}

/** Déplace (x,z) de (dx,dz) en glissant le long des obstacles. */
export function moveWalker(
  world: WalkWorld,
  pos: { x: number; z: number },
  dx: number,
  dz: number
): void {
  // sous-pas pour éviter de traverser un mur fin à grande vitesse
  const steps = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.08));
  const sx = dx / steps;
  const sz = dz / steps;
  for (let i = 0; i < steps; i++) {
    if (!blocked(world, pos.x + sx, pos.z)) pos.x += sx;
    if (!blocked(world, pos.x, pos.z + sz)) pos.z += sz;
  }
}

/** Position de départ : centre de la pièce, ou le point libre le plus proche. */
export function findFreeSpot(world: WalkWorld, x: number, z: number): { x: number; z: number } {
  if (!blocked(world, x, z)) return { x, z };
  for (let rad = 0.2; rad < 2.5; rad += 0.2) {
    for (let a = 0; a < Math.PI * 2; a += Math.PI / 8) {
      const px = x + Math.cos(a) * rad;
      const pz = z + Math.sin(a) * rad;
      if (!blocked(world, px, pz)) return { x: px, z: pz };
    }
  }
  return { x, z };
}

export type { WallSide };
