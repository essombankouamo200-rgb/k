import { useState } from 'react';
import { TeamMember } from '../types/project';

interface AvatarProps {
  member: TeamMember;
  size?: 'sm' | 'md' | 'lg';
}

const SIZE_CLASSES = {
  sm: 'h-6 w-6 text-[10px]',
  md: 'h-8 w-8 text-xs',
  lg: 'h-10 w-10 text-sm',
};

export function Avatar({ member, size = 'sm' }: AvatarProps) {
  const [failed, setFailed] = useState(false);

  if (failed || !member.avatarUrl) {
    return (
      <span
        title={member.nom}
        aria-label={member.nom}
        className={`${SIZE_CLASSES[size]} inline-flex shrink-0 items-center justify-center rounded-full bg-slate-200 font-medium text-slate-700 dark:bg-slate-800 dark:text-slate-200`}
      >
        {member.initiales}
      </span>
    );
  }

  return (
    <img
      src={member.avatarUrl}
      alt={member.nom}
      title={member.nom}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`${SIZE_CLASSES[size]} shrink-0 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700`}
    />
  );
}
