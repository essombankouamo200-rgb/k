import * as THREE from 'three';
import { ComputedCircuit, PlanItem } from '../types/planelec';
import { defaultWallElevationCm, resolveItemElevationCm } from '../utils/snap3d';

/**
 * Niveaux d'affichage du câblage :
 *  0 = masqué
 *  1 = Tracé        : cheminements des câbles vus à travers les murs
 *  2 = Gaines       : conduits ICTA annelés + boîtes d'encastrement
 *  3 = Câblage tiré : conducteurs (L / N / PE) torsadés dans les gaines
 *  4 = Terminé      : murs finis, câblage masqué ; coupe du circuit de l'équipement sélectionné
 */
export type CablingLevel = 0 | 1 | 2 | 3 | 4;

export const CABLING_LEVEL_INFO: { level: CablingLevel; short: string; title: string; hint: string }[] = [
  { level: 0, short: 'Off', title: 'Câblage masqué', hint: 'Aucun câble affiché' },
  { level: 1, short: '1', title: 'Niveau 1 · Tracé', hint: 'Cheminements des câbles à travers les murs' },
  { level: 2, short: '2', title: 'Niveau 2 · Gaines', hint: 'Gaines ICTA annelées et boîtes d’encastrement dans les murs' },
  { level: 3, short: '3', title: 'Niveau 3 · Câblage', hint: 'Conducteurs L / N / PE tirés dans les gaines' },
  { level: 4, short: '4', title: 'Niveau 4 · Terminé', hint: 'Installation terminée : murs finis. Sélectionnez un équipement pour voir sa gaine et son câble en coupe' },
];

export interface CablingInput {
  items: PlanItem[];
  circuits: ComputedCircuit[];
  level: CablingLevel;
  floorYOf: (floorId: number) => number;
  /** ne garder que cet étage (mode « étage actif ») */
  onlyFloorId: number | null;
  wallHeight: number;
  scale: number;
  trippedCircuitIds: Set<string>;
  selectedItemId: number | null;
  texCache: Map<string, THREE.CanvasTexture>;
  maxAniso: number;
}

const ICTA_R = 0.0105;
const CORE_R = 0.0028;

function ribbedTexture(cache: Map<string, THREE.CanvasTexture>, aniso: number): THREE.CanvasTexture {
  const key = 'cab:ribbed';
  const hit = cache.get(key);
  if (hit) return hit;
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 16;
  const g = c.getContext('2d')!;
  g.fillStyle = '#f97316';
  g.fillRect(0, 0, 64, 16);
  // annelures : bande sombre + liseré clair
  g.fillStyle = '#c2410c';
  g.fillRect(0, 0, 16, 16);
  g.fillStyle = '#fdba74';
  g.fillRect(16, 0, 6, 16);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  cache.set(key, t);
  return t;
}

function peTexture(cache: Map<string, THREE.CanvasTexture>): THREE.CanvasTexture {
  const key = 'cab:pe';
  const hit = cache.get(key);
  if (hit) return hit;
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 8;
  const g = c.getContext('2d')!;
  g.fillStyle = '#facc15';
  g.fillRect(0, 0, 32, 8);
  g.fillStyle = '#16a34a';
  g.fillRect(0, 0, 16, 8);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  cache.set(key, t);
  return t;
}

/** Chemin polyligne à angles arrondis (rayon r). */
function roundedPath(pts: THREE.Vector3[], r: number): THREE.CurvePath<THREE.Vector3> {
  const path = new THREE.CurvePath<THREE.Vector3>();
  if (pts.length < 2) return path;
  let cursor = pts[0].clone();
  for (let i = 1; i < pts.length - 1; i++) {
    const prev = pts[i - 1];
    const cur = pts[i];
    const next = pts[i + 1];
    const a = cur.clone().sub(prev);
    const b = next.clone().sub(cur);
    const la = a.length();
    const lb = b.length();
    if (la < 1e-4 || lb < 1e-4) continue;
    const rr = Math.min(r, la / 2, lb / 2);
    const p1 = cur.clone().addScaledVector(a.normalize(), -rr);
    const p2 = cur.clone().addScaledVector(b.normalize(), rr);
    if (cursor.distanceTo(p1) > 1e-4) path.add(new THREE.LineCurve3(cursor.clone(), p1));
    path.add(new THREE.QuadraticBezierCurve3(p1, cur.clone(), p2));
    cursor = p2;
  }
  const last = pts[pts.length - 1];
  if (cursor.distanceTo(last) > 1e-4) path.add(new THREE.LineCurve3(cursor.clone(), last.clone()));
  return path;
}

function dedupe(pts: THREE.Vector3[]): THREE.Vector3[] {
  const out: THREE.Vector3[] = [];
  for (const p of pts) {
    if (!out.length || out[out.length - 1].distanceTo(p) > 1e-3) out.push(p);
  }
  // supprime les points alignés inutiles
  const res: THREE.Vector3[] = [];
  for (let i = 0; i < out.length; i++) {
    if (i > 0 && i < out.length - 1) {
      const a = out[i].clone().sub(out[i - 1]).normalize();
      const b = out[i + 1].clone().sub(out[i]).normalize();
      if (a.dot(b) > 0.9999) continue;
    }
    res.push(out[i]);
  }
  return res;
}

interface Route {
  circuit: ComputedCircuit;
  /** un tronçon par paire d'équipements consécutifs (même étage) */
  legs: THREE.Vector3[][];
  /** extrémités (boîtes d'encastrement) */
  boxes: { pos: THREE.Vector3; yaw: number }[];
}

function deviceY(it: PlanItem, items: PlanItem[], fy: number, H: number, scale: number): number {
  if (
    it.mountSurface === 'ceiling' ||
    it.type === 'light' ||
    it.type === 'spots' ||
    it.type === 'neon' ||
    it.type === 'smoke'
  ) {
    return fy + H - 0.06;
  }
  const e = resolveItemElevationCm(it, items) || defaultWallElevationCm(it.type);
  return fy + Math.min(e * scale, H - 0.1);
}

function buildRoutes(inp: CablingInput): Route[] {
  const { circuits, items, floorYOf, wallHeight: H, scale, onlyFloorId } = inp;
  const byId = new Map(items.map((i) => [i.id, i]));
  const routes: Route[] = [];
  circuits.forEach((c, ci) => {
    const pts = c.chain
      .map((p) => ({ p, it: p.itemId !== undefined ? byId.get(p.itemId) : undefined }))
      .filter((q) => q.it && (onlyFloorId === null || (q.p.floorId ?? 0) === onlyFloorId));
    if (pts.length < 2) return;
    const lane = (ci % 5) * 0.028;
    const legs: THREE.Vector3[][] = [];
    const boxes: Route['boxes'] = [];
    const seen = new Set<number>();
    for (let i = 0; i < pts.length; i++) {
      const it = pts[i].it!;
      const fy = floorYOf(pts[i].p.floorId ?? 0);
      const x = pts[i].p.x * scale;
      const z = pts[i].p.y * scale;
      const y = deviceY(it, items, fy, H, scale);
      if (!seen.has(it.id)) {
        seen.add(it.id);
        const yaw =
          it.side === 'left' ? Math.PI / 2 : it.side === 'right' ? -Math.PI / 2 : it.side === 'bottom' ? Math.PI : 0;
        boxes.push({ pos: new THREE.Vector3(x, y, z), yaw });
      }
      if (i === 0) continue;
      const prev = pts[i - 1];
      const pit = prev.it!;
      const pfy = floorYOf(prev.p.floorId ?? 0);
      const px = prev.p.x * scale;
      const pz = prev.p.y * scale;
      const py = deviceY(pit, items, pfy, H, scale);
      const trunkPrev = pfy + H - 0.12 - lane;
      const trunk = fy + H - 0.12 - lane;
      const leg: THREE.Vector3[] = [new THREE.Vector3(px, py, pz), new THREE.Vector3(px, trunkPrev, pz)];
      if (Math.abs(pfy - fy) > 0.01) {
        // changement d'étage : remontée par la trémie, au droit du point d'arrivée
        leg.push(new THREE.Vector3(x, trunkPrev, pz));
        leg.push(new THREE.Vector3(x, trunk, pz));
        leg.push(new THREE.Vector3(x, trunk, z));
      } else {
        // cheminement orthogonal en plafond (x puis z)
        leg.push(new THREE.Vector3(x, trunk, pz));
        leg.push(new THREE.Vector3(x, trunk, z));
      }
      leg.push(new THREE.Vector3(x, y, z));
      legs.push(dedupe(leg));
    }
    routes.push({ circuit: c, legs, boxes });
  });
  return routes;
}

function addTube(
  group: THREE.Group,
  pts: THREE.Vector3[],
  radius: number,
  mat: THREE.Material,
  tubular: number
): THREE.Mesh | null {
  if (pts.length < 2) return null;
  const path = roundedPath(pts, 0.07);
  if (path.curves.length === 0) return null;
  const geo = new THREE.TubeGeometry(path, tubular, radius, 8, false);
  const mesh = new THREE.Mesh(geo, mat);
  group.add(mesh);
  return mesh;
}

/** Trois conducteurs torsadés autour de l'axe de la gaine. */
function addConductors(
  group: THREE.Group,
  pts: THREE.Vector3[],
  mats: THREE.Material[],
  onTop: boolean,
  cache: Map<string, THREE.CanvasTexture>
) {
  const path = roundedPath(pts, 0.07);
  if (path.curves.length === 0) return;
  const len = path.getLength();
  const n = Math.max(12, Math.round(len * 60));
  const frameGeo = new THREE.TubeGeometry(path, n, 0.001, 3, false);
  const { normals, binormals } = frameGeo;
  const centers = path.getSpacedPoints(n);
  const twistTurns = len / 0.22;
  mats.forEach((m, k) => {
    const phase = (k / mats.length) * Math.PI * 2;
    const arr: THREE.Vector3[] = [];
    for (let i = 0; i <= n; i++) {
      const th = phase + (i / n) * twistTurns * Math.PI * 2;
      const nrm = normals[Math.min(i, normals.length - 1)];
      const bin = binormals[Math.min(i, binormals.length - 1)];
      const off = nrm.clone().multiplyScalar(Math.cos(th) * ICTA_R * 0.5).addScaledVector(bin, Math.sin(th) * ICTA_R * 0.5);
      arr.push(centers[i].clone().add(off));
    }
    const curve = new THREE.CatmullRomCurve3(arr, false, 'centripetal');
    const geo = new THREE.TubeGeometry(curve, n, CORE_R, 6, false);
    const mesh = new THREE.Mesh(geo, m);
    if (onTop) mesh.renderOrder = 12;
    group.add(mesh);
  });
  frameGeo.dispose();
  void cache;
}

export interface CablingResult {
  group: THREE.Group;
  /** objets cliquables (libellé de circuit au survol / clic) */
  pickables: THREE.Object3D[];
}

export function buildCabling(inp: CablingInput): CablingResult {
  const group = new THREE.Group();
  const pickables: THREE.Object3D[] = [];
  const { level } = inp;
  if (level === 0) return { group, pickables };

  const routes = buildRoutes(inp);
  const ribbed = ribbedTexture(inp.texCache, inp.maxAniso);
  const pe = peTexture(inp.texCache);

  // niveau 4 : uniquement les circuits de l'équipement sélectionné, vus « à travers » le mur fini
  let list = routes;
  let onTop = false;
  let effLevel: 1 | 2 | 3 = level === 4 ? 3 : (level as 1 | 2 | 3);
  if (level === 4) {
    onTop = true;
    list = routes.filter(
      (r) => inp.selectedItemId !== null && r.circuit.chain.some((p) => p.itemId === inp.selectedItemId)
    );
    if (list.length === 0) return { group, pickables };
  }

  const boxMat = new THREE.MeshStandardMaterial({ color: 0xe5e7eb, roughness: 0.6 });
  const wireMats = [
    new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.4, depthTest: !onTop }), // phase
    new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.4, depthTest: !onTop }), // neutre
    new THREE.MeshStandardMaterial({ map: pe, roughness: 0.4, depthTest: !onTop }), // terre
  ];

  for (const r of list) {
    const tripped = inp.trippedCircuitIds.has(r.circuit.id);
    const label = `Circuit ${r.circuit.name} · ${r.circuit.sectionMm2.toString().replace('.', ',')} mm² · ${r.circuit.breakerA} A`;
    for (const leg of r.legs) {
      const len = leg.reduce((a, p, i) => (i ? a + p.distanceTo(leg[i - 1]) : 0), 0);
      const tub = Math.max(16, Math.round(len * 40));
      if (effLevel === 1) {
        const m = new THREE.MeshStandardMaterial({
          color: r.circuit.color,
          emissive: new THREE.Color(r.circuit.color),
          emissiveIntensity: tripped ? 0 : 0.35,
          roughness: 0.4,
          transparent: tripped,
          opacity: tripped ? 0.25 : 1,
        });
        const mesh = addTube(group, leg, 0.0075, m, tub);
        if (mesh) {
          mesh.userData.label = label;
          pickables.push(mesh);
        }
      } else {
        const tex = ribbed.clone();
        tex.needsUpdate = true;
        tex.repeat.set(Math.max(1, len / 0.03), 1);
        const m = new THREE.MeshStandardMaterial({
          map: tex,
          roughness: 0.55,
          transparent: effLevel === 3 || tripped,
          opacity: tripped ? 0.25 : effLevel === 3 ? 0.34 : 1,
          depthWrite: effLevel !== 3,
          depthTest: !onTop,
        });
        const mesh = addTube(group, leg, ICTA_R, m, tub);
        if (mesh) {
          mesh.userData.label = label;
          if (onTop) mesh.renderOrder = 11;
          pickables.push(mesh);
        }
        if (effLevel === 3 && !tripped) addConductors(group, leg, wireMats, onTop, inp.texCache);
      }
    }
    if (effLevel >= 2) {
      for (const b of r.boxes) {
        const box = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.034, 0.045, 18), boxMat);
        box.rotation.x = Math.PI / 2;
        const g = new THREE.Group();
        g.position.copy(b.pos);
        g.rotation.y = b.yaw;
        box.position.z = 0.0;
        g.add(box);
        group.add(g);
      }
    }
  }
  return { group, pickables };
}
