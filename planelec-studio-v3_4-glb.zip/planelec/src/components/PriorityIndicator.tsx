import { AlertCircle, ArrowUp, Minus, ArrowDown } from 'lucide-react';
import { TaskPriority } from '../types/project';
import { PRIORITY_CONFIG } from '../data/seedData';

interface PriorityIndicatorProps {
  priority: TaskPriority;
}

export function PriorityIndicator({ priority }: PriorityIndicatorProps) {
  const config = PRIORITY_CONFIG[priority];

  const Icon =
    priority === 'urgente'
      ? AlertCircle
      : priority === 'haute'
      ? ArrowUp
      : priority === 'normale'
      ? Minus
      : ArrowDown;

  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium whitespace-nowrap shrink-0 ${config.colorClass}`}>
      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span>{config.label}</span>
    </span>
  );
}
