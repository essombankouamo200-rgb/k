import { useState } from 'react';
import { X } from 'lucide-react';
import { Project } from '../types/project';

interface CreateProjectModalProps {
  onClose: () => void;
  onCreate: (project: Project) => void;
}

export function CreateProjectModal({ onClose, onCreate }: CreateProjectModalProps) {
  const [nom, setNom] = useState('');
  const [cle, setCle] = useState('');
  const [description, setDescription] = useState('');
  const [objectifSprint, setObjectifSprint] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nom.trim()) return;

    const cleanKey =
      cle
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, '')
        .slice(0, 4) ||
      nom
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, '')
        .slice(0, 3) ||
      'PRJ';

    onCreate({
      id: `proj-${Date.now()}`,
      cle: cleanKey,
      nom: nom.trim(),
      description:
        description.trim() || 'Nouveau projet produit géré dans Cadence.',
      objectifSprint:
        objectifSprint.trim() || 'Définir le premier lot de livrables prioritaires.',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-slate-950/50" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="create-project-title"
        className="relative z-10 w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="flex items-center justify-between">
          <h2
            id="create-project-title"
            className="font-display text-lg font-semibold text-slate-950 dark:text-white"
          >
            Nouveau projet
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div className="grid grid-cols-[1fr_100px] gap-3">
            <div>
              <label
                htmlFor="proj-name"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Nom du projet
              </label>
              <input
                id="proj-name"
                type="text"
                required
                autoFocus
                value={nom}
                onChange={(e) => setNom(e.target.value)}
                placeholder="Ex. Espace Partenaires"
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="proj-key"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Préfixe
              </label>
              <input
                id="proj-key"
                type="text"
                maxLength={4}
                value={cle}
                onChange={(e) => setCle(e.target.value.toUpperCase())}
                placeholder="PAR"
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm uppercase text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="proj-desc"
              className="block text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              Description
            </label>
            <input
              id="proj-desc"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Périmètre fonctionnel et équipe"
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label
              htmlFor="proj-goal"
              className="block text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              Objectif du sprint en cours
            </label>
            <textarea
              id="proj-goal"
              rows={2}
              value={objectifSprint}
              onChange={(e) => setObjectifSprint(e.target.value)}
              placeholder="Résultat clé visé pour ce cycle"
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-4 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
            >
              Créer le projet
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
