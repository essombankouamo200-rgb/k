import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { Task, TeamMember } from '../types/project';
import { STATUS_CONFIG } from '../data/seedData';
import { addDaysIso, daysBetween, formatShortDateFr, TODAY_ISO } from '../utils/formatters';
import { Avatar } from './Avatar';

interface TimelineViewProps {
  tasks: Task[];
  members: TeamMember[];
  onSelectTask: (taskId: string) => void;
}

const WINDOW_DAYS = 21;

export function TimelineView({ tasks, members, onSelectTask }: TimelineViewProps) {
  const [windowStart, setWindowStart] = useState<string>(() => addDaysIso(TODAY_ISO, -7));
  const memberById = new Map(members.map((m) => [m.id, m]));

  const days = Array.from({ length: WINDOW_DAYS }, (_, idx) => addDaysIso(windowStart, idx));
  const todayOffset = daysBetween(windowStart, TODAY_ISO);

  const sortedTasks = [...tasks].sort((a, b) => a.dateDebut.localeCompare(b.dateDebut));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
        <div className="text-sm text-slate-600 dark:text-slate-300">
          Fenêtre de planification :{' '}
          <span className="font-mono font-medium tabular-nums text-slate-900 dark:text-white">
            {formatShortDateFr(days[0])} — {formatShortDateFr(days[days.length - 1])}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setWindowStart((prev) => addDaysIso(prev, -7))}
            className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
            <span>-7 jours</span>
          </button>
          <button
            type="button"
            onClick={() => setWindowStart(addDaysIso(TODAY_ISO, -7))}
            className="rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            Aujourd’hui
          </button>
          <button
            type="button"
            onClick={() => setWindowStart((prev) => addDaysIso(prev, 7))}
            className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <span>+7 jours</span>
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="min-w-[980px]">
          <div className="grid grid-cols-[280px_1fr] border-b border-slate-200 bg-slate-50/80 dark:border-slate-800 dark:bg-slate-950/40">
            <div className="border-r border-slate-200 px-4 py-2.5 text-xs font-medium text-slate-500 dark:border-slate-800 dark:text-slate-400">
              Tâche et responsable
            </div>
            <div
              className="grid"
              style={{ gridTemplateColumns: `repeat(${WINDOW_DAYS}, minmax(0, 1fr))` }}
            >
              {days.map((day) => {
                const isToday = day === TODAY_ISO;
                const d = new Date(`${day}T00:00:00Z`);
                const dayNum = d.getUTCDate();
                const isWeekend = d.getUTCDay() === 0 || d.getUTCDay() === 6;

                return (
                  <div
                    key={day}
                    className={`border-r border-slate-100 py-2 text-center font-mono text-[11px] tabular-nums last:border-r-0 dark:border-slate-800/70 ${
                      isToday
                        ? 'bg-indigo-50 font-semibold text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300'
                        : isWeekend
                        ? 'bg-slate-100/70 text-slate-400 dark:bg-slate-900/70 dark:text-slate-500'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {dayNum}
                  </div>
                );
              })}
            </div>
          </div>

          {sortedTasks.length === 0 ? (
            <div className="p-12 text-center text-sm text-slate-500 dark:text-slate-400">
              Aucune tâche à afficher sur cette chronologie.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {sortedTasks.map((task) => {
                const member = memberById.get(task.assigneeId);
                const rawStart = daysBetween(windowStart, task.dateDebut);
                const rawEnd = daysBetween(windowStart, task.echeance);
                const clampedStart = Math.max(0, rawStart);
                const clampedEnd = Math.min(WINDOW_DAYS - 1, rawEnd);
                const isVisibleInWindow = rawEnd >= 0 && rawStart < WINDOW_DAYS;
                const spanCols = Math.max(1, clampedEnd - clampedStart + 1);

                const barColor =
                  task.statut === 'termine'
                    ? 'bg-emerald-600/90 text-white dark:bg-emerald-500/80'
                    : task.statut === 'revue'
                    ? 'bg-amber-600/90 text-white dark:bg-amber-500/85'
                    : task.statut === 'en_cours'
                    ? 'bg-indigo-600 text-white dark:bg-indigo-500'
                    : 'bg-slate-700 text-white dark:bg-slate-600';

                return (
                  <div
                    key={task.id}
                    className="grid grid-cols-[280px_1fr] items-center hover:bg-slate-50/70 dark:hover:bg-slate-800/30"
                  >
                    <div className="flex items-center gap-2.5 border-r border-slate-200 px-4 py-2.5 dark:border-slate-800">
                      {member && <Avatar member={member} size="sm" />}
                      <div className="min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={() => onSelectTask(task.id)}
                          className="block w-full truncate text-left text-xs font-medium text-slate-900 hover:text-indigo-700 dark:text-slate-100 dark:hover:text-indigo-400"
                        >
                          {task.titre}
                        </button>
                        <div className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
                          {task.code} · {STATUS_CONFIG[task.statut].shortLabel}
                        </div>
                      </div>
                    </div>

                    <div className="relative h-12">
                      <div
                        className="pointer-events-none absolute inset-0 grid"
                        style={{ gridTemplateColumns: `repeat(${WINDOW_DAYS}, minmax(0, 1fr))` }}
                      >
                        {days.map((day) => {
                          const d = new Date(`${day}T00:00:00Z`);
                          const isWeekend = d.getUTCDay() === 0 || d.getUTCDay() === 6;
                          return (
                            <div
                              key={day}
                              className={`border-r border-slate-100 last:border-r-0 dark:border-slate-800/60 ${
                                isWeekend ? 'bg-slate-50/80 dark:bg-slate-950/30' : ''
                              }`}
                            />
                          );
                        })}
                      </div>

                      {todayOffset >= 0 && todayOffset < WINDOW_DAYS && (
                        <div
                          aria-hidden="true"
                          className="pointer-events-none absolute top-0 bottom-0 z-10 w-px bg-indigo-500/70"
                          style={{
                            left: `${((todayOffset + 0.5) / WINDOW_DAYS) * 100}%`,
                          }}
                        />
                      )}

                      {isVisibleInWindow && (
                        <button
                          type="button"
                          onClick={() => onSelectTask(task.id)}
                          title={`${task.code} — ${formatShortDateFr(task.dateDebut)} au ${formatShortDateFr(task.echeance)}`}
                          className={`absolute top-2.5 z-20 flex h-7 items-center justify-between gap-2 overflow-hidden rounded-md px-2.5 text-xs font-medium transition-opacity hover:opacity-90 ${barColor}`}
                          style={{
                            left: `${(clampedStart / WINDOW_DAYS) * 100}%`,
                            width: `${(spanCols / WINDOW_DAYS) * 100}%`,
                          }}
                        >
                          <span className="truncate font-mono text-[11px] tabular-nums">
                            {task.code}
                          </span>
                          <span className="hidden truncate text-[11px] sm:inline">
                            {task.heuresEstimees}h
                          </span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
