import { useRef } from 'react';
import {
  Kanban,
  ListChecks,
  CalendarRange,
  BarChart3,
  Plus,
  Sun,
  Moon,
  Download,
  Upload,
  RotateCcw,
  FolderKanban,
  X,
} from 'lucide-react';
import { Project, Task, WorkspaceView } from '../types/project';

interface SidebarProps {
  projects: Project[];
  tasks: Task[];
  activeProjectId: string;
  activeView: WorkspaceView;
  isDark: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onSelectProject: (projectId: string) => void;
  onSelectView: (view: WorkspaceView) => void;
  onOpenCreateProject: () => void;
  onToggleTheme: () => void;
  onExportJson: () => void;
  onImportJson: (file: File) => void;
  onResetDemo: () => void;
}

const NAV_ITEMS: { id: WorkspaceView; label: string; icon: typeof Kanban }[] = [
  { id: 'kanban', label: 'Tableau Kanban', icon: Kanban },
  { id: 'liste', label: 'Liste & Suivi', icon: ListChecks },
  { id: 'chronologie', label: 'Chronologie', icon: CalendarRange },
  { id: 'synthese', label: 'Synthèse', icon: BarChart3 },
];

export function Sidebar({
  projects,
  tasks,
  activeProjectId,
  activeView,
  isDark,
  mobileOpen,
  onCloseMobile,
  onSelectProject,
  onSelectView,
  onOpenCreateProject,
  onToggleTheme,
  onExportJson,
  onImportJson,
  onResetDemo,
}: SidebarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between bg-white px-4 py-5 text-slate-900 dark:bg-slate-900 dark:text-slate-100">
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <span className="font-display text-lg font-bold tracking-tight text-slate-950 dark:text-white whitespace-nowrap shrink-0">
            Cadence
          </span>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Fermer le menu"
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 lg:hidden dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav aria-label="Vues de l’espace de travail" className="space-y-1">
          <div className="px-2 pb-1.5 text-xs font-medium text-slate-500 dark:text-slate-400">
            Espace de travail
          </div>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobile();
                }}
                className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 ${
                  isActive
                    ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-950'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-200 pt-5 dark:border-slate-800">
          <div className="flex items-center justify-between px-2 pb-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Projets actifs
            </span>
            <button
              type="button"
              onClick={onOpenCreateProject}
              title="Créer un projet"
              className="inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Nouveau</span>
            </button>
          </div>

          <div className="space-y-1">
            {projects.map((project) => {
              const projectTasks = tasks.filter((t) => t.projectId === project.id);
              const doneCount = projectTasks.filter((t) => t.statut === 'termine').length;
              const isSelected = project.id === activeProjectId;

              return (
                <button
                  key={project.id}
                  type="button"
                  onClick={() => {
                    onSelectProject(project.id);
                    onCloseMobile();
                  }}
                  className={`flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-left text-sm transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 ${
                    isSelected
                      ? 'bg-slate-100 font-semibold text-slate-950 dark:bg-slate-800 dark:text-white'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800/60 dark:hover:text-white'
                  }`}
                >
                  <span className="flex min-w-0 items-center gap-2">
                    <FolderKanban className="h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
                    <span className="truncate">{project.nom}</span>
                  </span>
                  <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                    {doneCount}/{projectTasks.length}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="space-y-1 border-t border-slate-200 pt-4 dark:border-slate-800">
        <button
          type="button"
          onClick={onToggleTheme}
          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
        >
          {isDark ? (
            <>
              <Sun className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Mode clair</span>
            </>
          ) : (
            <>
              <Moon className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Mode sombre</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={onExportJson}
          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
        >
          <Download className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>Exporter JSON</span>
        </button>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
        >
          <Upload className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>Importer JSON</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              onImportJson(file);
              e.target.value = '';
            }
          }}
        />

        <button
          type="button"
          onClick={onResetDemo}
          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
        >
          <RotateCcw className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span>Réinitialiser</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden w-64 shrink-0 border-r border-slate-200 dark:border-slate-800 lg:block">
        {sidebarContent}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 flex lg:hidden">
          <div
            className="fixed inset-0 bg-slate-950/50"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative z-50 w-72 max-w-[85vw] border-r border-slate-200 dark:border-slate-800">
            {sidebarContent}
          </aside>
        </div>
      )}
    </>
  );
}
