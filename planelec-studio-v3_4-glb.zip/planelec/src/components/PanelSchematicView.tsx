import { COMPANY } from '../data/company';
import { brandSvg } from '../utils/reportExport';
import { useRef, useState } from 'react';
import { Cable, Download, LayoutGrid, Power, ShieldAlert, Zap } from 'lucide-react';
import { ComputedCircuit } from '../types/planelec';
import { frNum, SimulationOutput } from '../utils/electricalEngine';
import { CircuitPrincipleSection } from './CircuitPrincipleSection';

interface PanelSchematicViewProps {
  sim: SimulationOutput;
  subscriptionKva: 6 | 9 | 12 | 15;
  includeSurgeProtector: boolean;
  trippedCircuitIds: Set<string>;
  highlightedCircuitId: string | null;
  onToggleCircuitTrip: (circuitId: string) => void;
  onHighlightCircuit: (circuitId: string | null) => void;
  onToggleSurgeProtector: (enabled: boolean) => void;
  onChangeSubscriptionKva: (kva: 6 | 9 | 12 | 15) => void;
}

export function PanelSchematicView({
  sim,
  subscriptionKva,
  includeSurgeProtector,
  trippedCircuitIds,
  highlightedCircuitId,
  onToggleCircuitTrip,
  onHighlightCircuit,
  onToggleSurgeProtector,
  onChangeSubscriptionKva,
}: PanelSchematicViewProps) {
  const schematicRef = useRef<SVGSVGElement>(null);
  const [subTab, setSubTab] = useState<'tableau' | 'principe'>('tableau');
  const [principleCircuitId, setPrincipleCircuitId] = useState<string | null>(
    () => sim.circuits[0]?.id ?? null
  );
  const { panel } = sim;

  const exportPanelSvg = () => {
    const svgEl = schematicRef.current;
    if (!svgEl) return;
    const clone = svgEl.cloneNode(true) as SVGSVGElement;
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const vb = (clone.getAttribute('viewBox') ?? '').split(/[\s,]+/).map(Number);
    const vw = vb[2] || Number(clone.getAttribute('width')) || 1000;
    const vh = vb[3] || Number(clone.getAttribute('height')) || 700;
    const cs = getComputedStyle(document.documentElement);
    const serialized = brandSvg(
      new XMLSerializer()
        .serializeToString(clone)
        .replace(/var\((--[\w-]+)\)/g, (_m, v: string) => cs.getPropertyValue(v).trim() || '#0f172a'),
      { w: vw, h: vh },
      'Schéma du tableau électrique',
      `${COMPANY.name} — ${new Date().toLocaleDateString('fr-FR')}`
    );
    const blob = new Blob([serialized], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'schema-tableau-electrique.svg';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Layout geometry for multi-row schematic (similar to reference wiring diagram)
  const maxBreakersInRow = Math.max(4, ...panel.rows.map((r) => r.circuits.length));
  const moduleSlotW = 104;
  const rowWidth = Math.max(920, 220 + maxBreakersInRow * moduleSlotW);
  const rowHeight = 290;
  const topHeaderH = 190;
  const totalHeight = topHeaderH + panel.rows.length * rowHeight + 80;

  const activePowerW = sim.circuits
    .filter((c) => !trippedCircuitIds.has(c.id))
    .reduce((sum, c) => sum + c.watts, 0);

  return (
    <div className="space-y-4">
      {/* Sub-navigation: Full Distribution Panel vs Detailed Circuit Principle */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-2.5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setSubTab('tableau')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
              subTab === 'tableau'
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
            }`}
          >
            <LayoutGrid className="h-3.5 w-3.5" />
            <span>Tableau de répartition complet</span>
          </button>
          <button
            type="button"
            onClick={() => setSubTab('principe')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
              subTab === 'principe'
                ? 'bg-blue-700 text-white dark:bg-sky-500 dark:text-slate-950'
                : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
            }`}
          >
            <Cable className="h-3.5 w-3.5" />
            <span>Principe de câblage détaillé par circuit</span>
          </button>
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400">
          {subTab === 'principe'
            ? 'Schéma multifilaire : Protection → Commande / Relais → Points raccordés'
            : 'Cliquez sur « Principe » d’un circuit pour inspecter son câblage détaillé'}
        </div>
      </div>

      {subTab === 'principe' ? (
        <CircuitPrincipleSection
          sim={sim}
          selectedCircuitId={principleCircuitId}
          trippedCircuitIds={trippedCircuitIds}
          onSelectCircuit={setPrincipleCircuitId}
          onToggleCircuitTrip={onToggleCircuitTrip}
        />
      ) : (
        <>
          {/* Top Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center gap-4">
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Dimensionnement tableau
                </div>
                <div className="font-mono text-sm font-semibold tabular-nums text-slate-900 dark:text-white">
                  Coffret {panel.recommendedRows} rangée{panel.recommendedRows > 1 ? 's' : ''} · {panel.totalModules} modules occupés
                </div>
              </div>

              <div className="h-8 w-px bg-slate-200 dark:bg-slate-800" />

              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                <span>Abonnement</span>
                <select
                  value={subscriptionKva}
                  onChange={(e) =>
                    onChangeSubscriptionKva(Number(e.target.value) as 6 | 9 | 12 | 15)
                  }
                  className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                >
                  <option value={6}>6 kVA (AGCP 30 A)</option>
                  <option value={9}>9 kVA (AGCP 45 A)</option>
                  <option value={12}>12 kVA (AGCP 60 A)</option>
                  <option value={15}>15 kVA (AGCP 60 A+)</option>
                </select>
              </label>

              <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  checked={includeSurgeProtector}
                  onChange={(e) => onToggleSurgeProtector(e.target.checked)}
                  className="rounded border-slate-300"
                />
                <span>Parafoudre Type 2</span>
              </label>
            </div>

            <div className="flex items-center gap-3">
              <div className="font-mono text-xs tabular-nums text-slate-600 dark:text-slate-300">
                Charge active : <strong className="text-slate-950 dark:text-white">{frNum(activePowerW)} W</strong> ({frNum(activePowerW / 230, 1)} A)
              </div>
              <button
                type="button"
                onClick={exportPanelSvg}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Schéma (.svg)</span>
              </button>
            </div>
          </div>

          {/* Interactive Wiring Diagram SVG */}
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>
            Schéma multifilaire normalisé (Phase rouge · Neutre bleu · Terre vert/jaune). Cliquez sur un disjoncteur pour le couper / réarmer.
          </span>
          {trippedCircuitIds.size > 0 && (
            <span className="inline-flex items-center gap-1 font-medium text-amber-700 dark:text-amber-400">
              <ShieldAlert className="h-3.5 w-3.5" />
              <span>{trippedCircuitIds.size} circuit(s) coupé(s) manuellement</span>
            </span>
          )}
        </div>

        <svg
          ref={schematicRef}
          viewBox={`0 0 ${rowWidth} ${totalHeight}`}
          className="w-full min-w-[880px] select-none"
          role="img"
          aria-label="Schéma électrique du tableau de répartition"
        >
          {/* Background */}
          <rect x="0" y="0" width={rowWidth} height={totalHeight} fill="#ffffff" rx="8" />

          {/* TOP: AGCP (Disjoncteur de Branchement) & Main Busbars */}
          <g transform={`translate(${rowWidth / 2 - 42}, 16)`}>
            <rect x="0" y="0" width="84" height="92" rx="4" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
            <rect x="10" y="8" width="64" height="18" rx="2" fill="#e2e8f0" />
            <text x="42" y="21" textAnchor="middle" fontSize="10" fontWeight="700" fill="#0f172a">
              AGCP {panel.agcpRatingA} A
            </text>
            <text x="42" y="42" textAnchor="middle" fontSize="9" fill="#475569">
              500 mA Sélectif
            </text>
            {/* Switch toggle */}
            <rect x="24" y="50" width="36" height="18" rx="3" fill="#0f172a" />
            <text x="42" y="62" textAnchor="middle" fontSize="9" fontWeight="700" fill="#ffffff">
              I / ON
            </text>
            <text x="42" y="83" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#475569">
              N          L
            </text>
          </g>

          {/* Bornier Neutre (Left) & Bornier Phase (Right) */}
          <g transform="translate(220, 128)">
            <rect x="0" y="0" width="90" height="20" rx="3" fill="#2563eb" />
            <text x="45" y="13.5" textAnchor="middle" fontSize="10" fontWeight="700" fill="#ffffff">
              Bornier Neutre
            </text>
          </g>
          <g transform={`translate(${rowWidth / 2 + 120}, 128)`}>
            <rect x="0" y="0" width="90" height="20" rx="3" fill="#dc2626" />
            <text x="45" y="13.5" textAnchor="middle" fontSize="10" fontWeight="700" fill="#ffffff">
              Bornier Phase
            </text>
          </g>

          {/* Main wires from AGCP to Borniers */}
          {/* Neutral Blue */}
          <path
            d={`M${rowWidth / 2 - 18} 108 V138 H310`}
            fill="none"
            stroke="#2563eb"
            strokeWidth="3"
          />
          {/* Phase Red */}
          <path
            d={`M${rowWidth / 2 + 18} 108 V138 H${rowWidth / 2 + 120}`}
            fill="none"
            stroke="#dc2626"
            strokeWidth="3"
          />

          {/* Main vertical feeder trunk down to rows */}
          <path
            d={`M220 138 H92 V${topHeaderH + (panel.rows.length - 1) * rowHeight + 35}`}
            fill="none"
            stroke="#2563eb"
            strokeWidth="2.8"
          />
          <path
            d={`M${rowWidth / 2 + 120} 138 H74 V${topHeaderH + (panel.rows.length - 1) * rowHeight + 25}`}
            fill="none"
            stroke="#dc2626"
            strokeWidth="2.8"
          />

          {/* Bornier Terre & Piquet de Terre (Bottom Right) */}
          <g transform={`translate(${rowWidth - 220}, ${totalHeight - 66})`}>
            <rect x="0" y="0" width="170" height="16" rx="3" fill="#16a34a" />
            <text x="85" y="11.5" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#ffffff">
              Bornier Terre (PE)
            </text>
            {/* Earth spike */}
            <path d="M150 16 V42 M138 42 H162 M142 47 H158 M146 52 H154" stroke="#16a34a" strokeWidth="2.5" fill="none" />
            <text x="115" y="45" textAnchor="end" fontSize="9" fill="#475569">
              Prise de terre ≤ 100 Ω
            </text>
          </g>

          {/* Vertical PE trunk on right */}
          <path
            d={`M${rowWidth - 55} ${topHeaderH + 40} V${totalHeight - 66}`}
            fill="none"
            stroke="#16a34a"
            strokeWidth="2.5"
            strokeDasharray="6 3"
          />

          {/* Parafoudre, Télérupteur, Contrôleur Escalier & Contacteur Jour/Nuit badges if active */}
          {panel.hasSurgeProtector && (
            <g transform="translate(30, 32)">
              <rect x="0" y="0" width="136" height="44" rx="4" fill="#fef3c7" stroke="#d97706" strokeWidth="1.5" />
              <text x="68" y="18" textAnchor="middle" fontSize="10" fontWeight="700" fill="#92400e">
                Parafoudre Type 2
              </text>
              <text x="68" y="33" textAnchor="middle" fontSize="9" fill="#78350f">
                Protection surtensions
              </text>
            </g>
          )}
          {panel.hasTelerupteur && (
            <g transform="translate(178, 32)">
              <rect x="0" y="0" width="134" height="44" rx="4" fill="#f3e8ff" stroke="#7c3aed" strokeWidth="1.5" />
              <text x="67" y="18" textAnchor="middle" fontSize="10" fontWeight="700" fill="#5b21b6">
                Télérupteur 16 A
              </text>
              <text x="67" y="33" textAnchor="middle" fontSize="9" fill="#6d28d9">
                Commande poussoirs
              </text>
            </g>
          )}
          {panel.hasStairController && (
            <g transform={`translate(${rowWidth - 332}, 32)`}>
              <rect x="0" y="0" width="144" height="44" rx="4" fill="#fef9c3" stroke="#ca8a04" strokeWidth="1.5" />
              <text x="72" y="18" textAnchor="middle" fontSize="10" fontWeight="700" fill="#854d0e">
                Contrôleur Escalier LED
              </text>
              <text x="72" y="33" textAnchor="middle" fontSize="9" fill="#a16207">
                Allumage séquentiel 24V
              </text>
            </g>
          )}
          {panel.hasJourNuitContactor && (
            <g transform={`translate(${rowWidth - 178}, 32)`}>
              <rect x="0" y="0" width="148" height="44" rx="4" fill="#eff6ff" stroke="#2563eb" strokeWidth="1.5" />
              <text x="74" y="18" textAnchor="middle" fontSize="10" fontWeight="700" fill="#1e40af">
                Contacteur Jour / Nuit
              </text>
              <text x="74" y="33" textAnchor="middle" fontSize="9" fill="#1e3a8a">
                Asservissement Chauffe-eau
              </text>
            </g>
          )}

          {/* DIN RAILS / ROWS */}
          {panel.rows.map((row, rIdx) => {
            const ry = topHeaderH + rIdx * rowHeight;
            const diffX = 118;

            return (
              <g key={row.id} transform={`translate(0, ${ry})`}>
                {/* DIN Rail metal bar */}
                <rect x="96" y="42" width={rowWidth - 150} height="48" rx="3" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1.5" />
                <text x="36" y="68" fontSize="11" fontWeight="700" fill="#334155">
                  R{row.rowIndex}
                </text>

                {/* Feeder connections to Differential */}
                <path d={`M74 25 H${diffX + 52} V34`} fill="none" stroke="#dc2626" strokeWidth="2.5" />
                <path d={`M92 35 H${diffX + 20} V34`} fill="none" stroke="#2563eb" strokeWidth="2.5" />

                {/* 30mA Differential Switch (Interrupteur Différentiel) */}
                <g transform={`translate(${diffX}, 22)`}>
                  <rect
                    x="0"
                    y="0"
                    width="74"
                    height="92"
                    rx="4"
                    fill={row.type === 'A' ? '#fff7ed' : '#f8fafc'}
                    stroke={row.type === 'A' ? '#c2410c' : '#334155'}
                    strokeWidth="2"
                  />
                  <rect x="6" y="6" width="62" height="16" rx="2" fill={row.type === 'A' ? '#fed7aa' : '#e2e8f0'} />
                  <text x="37" y="17" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#0f172a">
                    ID 30 mA
                  </text>
                  <text x="37" y="36" textAnchor="middle" fontSize="10" fontWeight="700" fill={row.type === 'A' ? '#9a3412' : '#1e293b'}>
                    {row.ratingA} A · Type {row.type}
                  </text>
                  <rect x="18" y="48" width="38" height="16" rx="2" fill="#0f172a" />
                  <text x="37" y="59" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">
                    ON
                  </text>
                  <text x="37" y="82" textAnchor="middle" fontSize="8" fill="#64748b">
                    {row.circuits.length}/8 circuits
                  </text>
                </g>

                {/* Peigne d'alimentation (Busbars from Diff bottom to Breakers top) */}
                {row.circuits.length > 0 && (
                  <>
                    <path
                      d={`M${diffX + 20} 114 V126 H${diffX + 105 + (row.circuits.length - 1) * moduleSlotW + 18}`}
                      fill="none"
                      stroke="#2563eb"
                      strokeWidth="2.5"
                    />
                    <path
                      d={`M${diffX + 52} 114 V134 H${diffX + 105 + (row.circuits.length - 1) * moduleSlotW + 38}`}
                      fill="none"
                      stroke="#dc2626"
                      strokeWidth="2.5"
                    />
                  </>
                )}

                {/* Individual Circuit Breakers */}
                {row.circuits.map((c: ComputedCircuit, cIdx: number) => {
                  const bx = diffX + 102 + cIdx * moduleSlotW;
                  const isTripped = trippedCircuitIds.has(c.id);
                  const isHighlighted = highlightedCircuitId === c.id;

                  return (
                    <g
                      key={c.id}
                      transform={`translate(${bx}, 22)`}
                      onClick={() => onToggleCircuitTrip(c.id)}
                      onMouseEnter={() => onHighlightCircuit(c.id)}
                      onMouseLeave={() => onHighlightCircuit(null)}
                      className="cursor-pointer"
                    >
                      {/* Top jumper wires from Peigne */}
                      <path d="M21 0 V-10 M41 0 V-18" fill="none" stroke="transparent" />
                      <line x1="21" y1="-12" x2="21" y2="0" stroke="#2563eb" strokeWidth="2" />
                      <line x1="41" y1="-20" x2="41" y2="0" stroke="#dc2626" strokeWidth="2" />

                      {/* Breaker Module Body */}
                      <rect
                        x="4"
                        y="0"
                        width="56"
                        height="92"
                        rx="4"
                        fill={isTripped ? '#fef2f2' : isHighlighted ? '#eff6ff' : '#ffffff'}
                        stroke={isTripped ? '#dc2626' : isHighlighted ? '#2563eb' : '#475569'}
                        strokeWidth={isHighlighted || isTripped ? 2.2 : 1.6}
                      />
                      {/* Circuit Color Bar */}
                      <rect x="6" y="2" width="52" height="5" rx="1.5" fill={c.color} />

                      <text x="32" y="22" textAnchor="middle" fontSize="10" fontWeight="700" fill="#0f172a">
                        C{c.breakerA}
                      </text>
                      <text x="32" y="34" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#475569">
                        {frNum(c.sectionMm2, 1)} mm²
                      </text>

                      {/* Toggle Handle */}
                      <rect
                        x="14"
                        y="46"
                        width="36"
                        height="17"
                        rx="2"
                        fill={isTripped ? '#dc2626' : '#16a34a'}
                      />
                      <text x="32" y="57.5" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">
                        {isTripped ? 'OFF' : 'ON'}
                      </text>

                      <text x="32" y="81" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#334155">
                        {frNum(c.watts)} W
                      </text>

                      {/* Outgoing 3-wire cable down (Blue, Red, Green-Yellow) */}
                      <line
                        x1="20"
                        y1="92"
                        x2="20"
                        y2="165"
                        stroke="#2563eb"
                        strokeWidth="2"
                        opacity={isTripped ? 0.25 : 0.9}
                      />
                      <line
                        x1="36"
                        y1="92"
                        x2="36"
                        y2="165"
                        stroke="#dc2626"
                        strokeWidth="2"
                        opacity={isTripped ? 0.25 : 0.9}
                      />
                      <line
                        x1="50"
                        y1="106"
                        x2="50"
                        y2="165"
                        stroke="#16a34a"
                        strokeWidth="1.8"
                        strokeDasharray="4 2"
                        opacity={isTripped ? 0.25 : 0.85}
                      />
                      {/* Earth tap to PE bus */}
                      <line
                        x1="50"
                        y1="106"
                        x2={rowWidth - 55 - bx}
                        y2="106"
                        stroke="#16a34a"
                        strokeWidth="1.2"
                        strokeDasharray="3 3"
                        opacity="0.45"
                      />

                      {/* Equipment Terminal Box */}
                      <rect
                        x="-12"
                        y="165"
                        width="88"
                        height="58"
                        rx="6"
                        fill="#f8fafc"
                        stroke={c.color}
                        strokeWidth="1.5"
                        opacity={isTripped ? 0.45 : 1}
                      />
                      <text
                        x="32"
                        y="184"
                        textAnchor="middle"
                        fontSize="9.5"
                        fontWeight="700"
                        fill="#0f172a"
                      >
                        {c.name.length > 14 ? `${c.name.slice(0, 13)}…` : c.name}
                      </text>
                      <text
                        x="32"
                        y="198"
                        textAnchor="middle"
                        fontSize="8.5"
                        fill="#475569"
                      >
                        {c.points} pt{c.points > 1 ? 's' : ''} · {frNum(c.currentA, 1)} A
                      </text>
                      <text
                        x="32"
                        y="212"
                        textAnchor="middle"
                        fontSize="8"
                        fontFamily="JetBrains Mono, monospace"
                        fill="#64748b"
                      >
                        {c.lengthM !== null ? `≈ ${frNum(c.lengthM)} m` : 'Tableau requis'}
                      </text>
                    </g>
                  );
                })}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Interactive Circuit Breaker Quick Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {sim.circuits.map((c) => {
          const isTripped = trippedCircuitIds.has(c.id);
          return (
            <div
              key={c.id}
              onMouseEnter={() => onHighlightCircuit(c.id)}
              onMouseLeave={() => onHighlightCircuit(null)}
              className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className="h-3 w-3 shrink-0 rounded-sm"
                    style={{ backgroundColor: c.color }}
                  />
                  <span className="truncate text-sm font-semibold text-slate-900 dark:text-white">
                    {c.name}
                  </span>
                </div>
                <div className="mt-0.5 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                  Disj. {c.breakerA} A · Diff. Type {c.diffType} · {frNum(c.watts)} W
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setPrincipleCircuitId(c.id);
                    setSubTab('principe');
                  }}
                  className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  title="Voir le principe de câblage détaillé"
                >
                  <Cable className="h-3 w-3" />
                  <span>Principe</span>
                </button>
                <button
                  type="button"
                  onClick={() => onToggleCircuitTrip(c.id)}
                  className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 ${
                    isTripped
                      ? 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-400'
                      : 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-400'
                  }`}
                >
                  {isTripped ? (
                    <>
                      <Power className="h-3.5 w-3.5" />
                      <span>Coupé</span>
                    </>
                  ) : (
                    <>
                      <Zap className="h-3.5 w-3.5" />
                      <span>Actif</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
        </>
      )}
    </div>
  );
}
