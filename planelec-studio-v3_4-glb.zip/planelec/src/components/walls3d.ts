import * as THREE from 'three';
import { PlanItem } from '../types/planelec';
import { TYPES } from '../data/catalog';

export interface Opening {
  c: number; // centre le long du mur (m)
  half: number;
  sill: number;
  top: number;
}

export const DOOR_TOP = 2.05;
export const WINDOW_SILL = 0.9;
export const WINDOW_TOP = 2.05;

/** UV à l'échelle du monde (1 tuile = tile m) : un décor continu d'un segment à l'autre. */
export function worldUV(geo: THREE.BufferGeometry, tile = 1.2) {
  const pos = geo.getAttribute('position');
  const nor = geo.getAttribute('normal');
  const uv = geo.getAttribute('uv');
  for (let i = 0; i < pos.count; i++) {
    const nx = Math.abs(nor.getX(i));
    const ny = Math.abs(nor.getY(i));
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    if (ny > 0.5) uv.setXY(i, x / tile, z / tile);
    else if (nx > 0.5) uv.setXY(i, z / tile, y / tile);
    else uv.setXY(i, x / tile, y / tile);
  }
  uv.needsUpdate = true;
}

/** Boîtes (u0,u1,y0,y1) d'un mur percé d'ouvertures. */
export function segmentWall(a: number, b: number, H: number, ops: Opening[]) {
  const boxes: { u0: number; u1: number; y0: number; y1: number }[] = [];
  const sorted = ops
    .map((o) => ({ ...o, u0: Math.max(a, o.c - o.half), u1: Math.min(b, o.c + o.half) }))
    .filter((o) => o.u1 - o.u0 > 0.05)
    .sort((p, q) => p.u0 - q.u0);
  let cur = a;
  for (const o of sorted) {
    if (o.u0 > cur) boxes.push({ u0: cur, u1: o.u0, y0: 0, y1: H });
    if (o.sill > 0.001) boxes.push({ u0: o.u0, u1: o.u1, y0: 0, y1: o.sill });
    if (o.top < H - 0.001) boxes.push({ u0: o.u0, u1: o.u1, y0: o.top, y1: H });
    cur = Math.max(cur, o.u1);
  }
  if (cur < b) boxes.push({ u0: cur, u1: b, y0: 0, y1: H });
  return { boxes, gaps: sorted.filter((o) => o.sill < 0.01).map((o) => [o.u0, o.u1] as [number, number]) };
}

/** Ouvertures (portes/fenêtres) tombant sur une arête de mur. */
export function openingsOnEdge(
  items: PlanItem[],
  floorId: number,
  axis: 'x' | 'z',
  fixed: number,
  lo: number,
  hi: number,
  scale: number
): Opening[] {
  const out: Opening[] = [];
  for (const it of items) {
    if (it.floorId !== floorId || (it.type !== 'door' && it.type !== 'window')) continue;
    const alongX = it.side === 'top' || it.side === 'bottom';
    if ((axis === 'x') !== alongX) continue;
    const perp = (alongX ? it.y : it.x) * scale;
    const along = (alongX ? it.x : it.y) * scale;
    if (Math.abs(perp - fixed) > 0.12 || along < lo || along > hi) continue;
    const len = ((it.len ?? TYPES[it.type].len ?? 90) * scale) / 2;
    out.push(
      it.type === 'door'
        ? { c: along, half: len, sill: 0, top: DOOR_TOP }
        : { c: along, half: len, sill: WINDOW_SILL, top: WINDOW_TOP }
    );
  }
  return out;
}

const whiteMat = () => new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.45 });

/** Porte réaliste : dormant, vantail à panneaux, poignée. Axe local x = long du mur. */
export function createDoor3D(lenM: number, wallT: number): THREE.Group {
  const g = new THREE.Group();
  const frameMat = whiteMat();
  const depth = wallT + 0.03;
  const jamb = 0.05;
  const H = DOOR_TOP;
  const left = new THREE.Mesh(new THREE.BoxGeometry(jamb, H, depth), frameMat);
  left.position.set(-lenM / 2 + jamb / 2, H / 2, 0);
  const right = left.clone();
  right.position.x = lenM / 2 - jamb / 2;
  const head = new THREE.Mesh(new THREE.BoxGeometry(lenM, jamb, depth), frameMat);
  head.position.set(0, H - jamb / 2, 0);
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x9a6b43, roughness: 0.5, metalness: 0.02 });
  const leafW = lenM - 2 * jamb - 0.006;
  const leafH = H - jamb - 0.01;
  const leaf = new THREE.Mesh(new THREE.BoxGeometry(leafW, leafH, 0.04), woodMat);
  leaf.position.set(0, leafH / 2 + 0.005, 0);
  g.add(left, right, head, leaf);
  // panneaux moulurés
  const panelMat = new THREE.MeshStandardMaterial({ color: 0x84573a, roughness: 0.6 });
  for (const py of [0.32, 0.72]) {
    const pw = leafW * 0.68;
    const ph = leafH * (py < 0.5 ? 0.3 : 0.36);
    for (const sz of [1, -1]) {
      const pnl = new THREE.Mesh(new THREE.BoxGeometry(pw, ph, 0.006), panelMat);
      pnl.position.set(0, leafH * py, sz * 0.021);
      g.add(pnl);
    }
  }
  const metal = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.85, roughness: 0.25 });
  for (const sz of [1, -1]) {
    const rose = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.01, 16), metal);
    rose.rotation.x = Math.PI / 2;
    rose.position.set(leafW / 2 - 0.07, 1.02, sz * 0.025);
    const lever = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.014, 0.014), metal);
    lever.position.set(leafW / 2 - 0.12, 1.02, sz * 0.04);
    g.add(rose, lever);
  }
  g.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      m.castShadow = true;
      m.receiveShadow = true;
    }
  });
  return g;
}

/** Fenêtre réaliste : cadre alu, vitrage, meneau central, appui. */
export function createWindow3D(lenM: number, wallT: number): THREE.Group {
  const g = new THREE.Group();
  const h = WINDOW_TOP - WINDOW_SILL;
  const fm = new THREE.MeshStandardMaterial({ color: 0xe5e7eb, roughness: 0.35, metalness: 0.5 });
  const f = 0.045;
  const d = wallT + 0.02;
  const bars: [number, number, number, number][] = [
    [lenM, f, 0, h / 2 - f / 2],
    [lenM, f, 0, -h / 2 + f / 2],
    [f, h, -lenM / 2 + f / 2, 0],
    [f, h, lenM / 2 - f / 2, 0],
    [f * 0.8, h, 0, 0],
  ];
  for (const [w, hh, x, y] of bars) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, hh, d * 0.7), fm);
    b.position.set(x, y + WINDOW_SILL + h / 2, 0);
    g.add(b);
  }
  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(lenM - 2 * f, h - 2 * f),
    new THREE.MeshPhysicalMaterial({
      color: 0xbfe6ff,
      roughness: 0.03,
      metalness: 0,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
      depthWrite: false,
      clearcoat: 1,
    })
  );
  glass.position.set(0, WINDOW_SILL + h / 2, 0);
  glass.raycast = () => {};
  g.add(glass);
  const ledge = new THREE.Mesh(
    new THREE.BoxGeometry(lenM + 0.12, 0.03, wallT + 0.1),
    new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.5 })
  );
  ledge.position.set(0, WINDOW_SILL - 0.015, 0);
  g.add(ledge);
  // hitbox invisible pour la sélection
  const hit = new THREE.Mesh(new THREE.BoxGeometry(lenM, h, 0.1), new THREE.MeshBasicMaterial({ visible: false }));
  hit.position.set(0, WINDOW_SILL + h / 2, 0);
  g.add(hit);
  g.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) m.castShadow = true;
  });
  return g;
}
