import * as THREE from 'three';
import { EnvObject, GroundStyle } from '../types/planelec';
import { ENV_DEFS } from '../data/envCatalog';

const SCALE = 0.01; // cm → m

const stdMat = (color: number | string, roughness = 0.8, metalness = 0.02, extra: THREE.MeshStandardMaterialParameters = {}) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });

function mesh(geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0, shadow = true): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = shadow;
  m.receiveShadow = true;
  return m;
}

/* ---------- Textures procédurales du sol ---------- */

function noiseCanvas(base: string, speckles: string[], size = 256, count = 1400): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  g.fillStyle = base;
  g.fillRect(0, 0, size, size);
  for (let i = 0; i < count; i++) {
    g.fillStyle = speckles[i % speckles.length];
    g.globalAlpha = 0.18 + Math.random() * 0.25;
    const s = 1 + Math.random() * 3;
    g.fillRect(Math.random() * size, Math.random() * size, s, s);
  }
  g.globalAlpha = 1;
  return c;
}

export function createGroundTexture(style: GroundStyle, maxAniso: number): THREE.CanvasTexture | null {
  let canvas: HTMLCanvasElement;
  switch (style) {
    case 'herbe':
      canvas = noiseCanvas('#6aa84f', ['#4d8a3a', '#86bf64', '#3f7a30', '#9bcf73']);
      break;
    case 'terre':
      canvas = noiseCanvas('#b5651d', ['#8b4513', '#c97b3a', '#9a5a2a', '#d08a4f']);
      break;
    case 'sable':
      canvas = noiseCanvas('#e5d3a1', ['#d6c28a', '#f0e2b6', '#cdb87b'], 256, 1800);
      break;
    case 'dalles': {
      canvas = noiseCanvas('#cbd5e1', ['#b8c3d1', '#d9e1ea'], 256, 500);
      const g = canvas.getContext('2d')!;
      g.strokeStyle = '#8c99ab';
      g.lineWidth = 3;
      g.strokeRect(1.5, 1.5, 253, 253);
      g.beginPath();
      g.moveTo(128, 0);
      g.lineTo(128, 256);
      g.moveTo(0, 128);
      g.lineTo(256, 128);
      g.stroke();
      break;
    }
    default:
      return null;
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(style === 'dalles' ? 90 : 45, style === 'dalles' ? 90 : 45);
  tex.anisotropy = maxAniso;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const pavingCache = new Map<string, THREE.CanvasTexture>();
function pavingTexture(repeatX: number, repeatY: number): THREE.CanvasTexture {
  const key = `${Math.round(repeatX)}x${Math.round(repeatY)}`;
  let t = pavingCache.get(key);
  if (!t) {
    const c = noiseCanvas('#cfd6df', ['#bcc5d1', '#dde3ea'], 128, 300);
    const g = c.getContext('2d')!;
    g.strokeStyle = '#8a97a8';
    g.lineWidth = 3;
    g.strokeRect(1.5, 1.5, 125, 125);
    t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(Math.max(1, Math.round(repeatX)), Math.max(1, Math.round(repeatY)));
    t.colorSpace = THREE.SRGBColorSpace;
    pavingCache.set(key, t);
  }
  return t;
}

/* ---------- Modèles ---------- */

function buildTree(): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.CylinderGeometry(0.15, 0.24, 2.3, 8), stdMat(0x6b4a2b, 0.9), 0, 1.15, 0));
  const leaf = stdMat(0x3f7d35, 0.85, 0, { flatShading: true });
  const leaf2 = stdMat(0x4f9142, 0.85, 0, { flatShading: true });
  g.add(mesh(new THREE.IcosahedronGeometry(1.55, 1), leaf, 0, 3.4, 0));
  g.add(mesh(new THREE.IcosahedronGeometry(1.15, 1), leaf2, 0.9, 2.95, 0.4));
  g.add(mesh(new THREE.IcosahedronGeometry(1.0, 1), leaf2, -0.85, 3.0, -0.5));
  return g;
}

function buildPalm(): THREE.Group {
  const g = new THREE.Group();
  const trunkMat = stdMat(0x8a6a45, 0.9);
  const segs = 9;
  let ox = 0;
  for (let i = 0; i < segs; i++) {
    const r0 = 0.17 - i * 0.008;
    const seg = mesh(new THREE.CylinderGeometry(r0 - 0.008, r0, 0.52, 8), trunkMat, ox, 0.26 + i * 0.5, 0);
    seg.rotation.z = 0.03;
    ox += 0.02 + i * 0.004;
    g.add(seg);
  }
  const top = new THREE.Group();
  top.position.set(ox, segs * 0.5 + 0.1, 0);
  const frondMat = stdMat(0x2f7d3a, 0.8, 0, { side: THREE.DoubleSide });
  for (let k = 0; k < 9; k++) {
    const pivot = new THREE.Group();
    pivot.rotation.y = (k / 9) * Math.PI * 2;
    const frond = mesh(new THREE.BoxGeometry(1.9, 0.02, 0.34), frondMat, 0.95, 0, 0);
    frond.rotation.z = -0.38;
    pivot.add(frond);
    top.add(pivot);
  }
  top.add(mesh(new THREE.SphereGeometry(0.18, 8, 8), stdMat(0x6b4a2b), 0, 0, 0));
  g.add(top);
  return g;
}

function buildBush(): THREE.Group {
  const g = new THREE.Group();
  const m = mesh(new THREE.IcosahedronGeometry(0.55, 1), stdMat(0x3f8a3a, 0.9, 0, { flatShading: true }), 0, 0.42, 0);
  m.scale.set(1.2, 0.85, 1.1);
  g.add(m);
  return g;
}

function buildHedge(len: number): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.BoxGeometry(len, 0.95, 0.55), stdMat(0x2f7d35, 0.95), 0, 0.475, 0));
  return g;
}

function buildWall(len: number): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.BoxGeometry(len, 2.0, 0.2), stdMat(0xddd6c8, 0.9), 0, 1.0, 0));
  g.add(mesh(new THREE.BoxGeometry(len + 0.05, 0.07, 0.3), stdMat(0xb8ae9c, 0.8), 0, 2.035, 0));
  const pillars = Math.max(2, Math.ceil(len / 4) + 1);
  for (let i = 0; i < pillars; i++) {
    const px = -len / 2 + (len * i) / (pillars - 1);
    g.add(mesh(new THREE.BoxGeometry(0.34, 2.2, 0.34), stdMat(0xcfc7b6, 0.9), px, 1.1, 0));
  }
  return g;
}

function buildFence(len: number): THREE.Group {
  const g = new THREE.Group();
  const metal = stdMat(0x475569, 0.5, 0.6);
  const posts = Math.max(2, Math.ceil(len / 2.5) + 1);
  for (let i = 0; i < posts; i++) {
    const px = -len / 2 + (len * i) / (posts - 1);
    g.add(mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.6, 8), metal, px, 0.8, 0));
  }
  for (const y of [0.25, 0.8, 1.55]) g.add(mesh(new THREE.BoxGeometry(len, 0.03, 0.03), metal, 0, y, 0, false));
  g.add(
    mesh(
      new THREE.BoxGeometry(len, 1.3, 0.01),
      stdMat(0x94a3b8, 0.6, 0.5, { transparent: true, opacity: 0.28 }),
      0,
      0.9,
      0,
      false
    )
  );
  return g;
}

function buildGate(len: number): THREE.Group {
  const g = new THREE.Group();
  const pillarMat = stdMat(0xcfc7b6, 0.9);
  g.add(mesh(new THREE.BoxGeometry(0.4, 2.3, 0.4), pillarMat, -len / 2, 1.15, 0));
  g.add(mesh(new THREE.BoxGeometry(0.4, 2.3, 0.4), pillarMat, len / 2, 1.15, 0));
  const metal = stdMat(0x1f2937, 0.45, 0.55);
  const w = len - 0.5;
  g.add(mesh(new THREE.BoxGeometry(w, 0.08, 0.06), metal, 0, 0.25, 0.05));
  g.add(mesh(new THREE.BoxGeometry(w, 0.08, 0.06), metal, 0, 1.75, 0.05));
  const bars = Math.max(6, Math.floor(w / 0.14));
  const barGeo = new THREE.BoxGeometry(0.03, 1.5, 0.03);
  for (let i = 0; i < bars; i++) {
    g.add(mesh(barGeo, metal, -w / 2 + (w * (i + 0.5)) / bars, 1.0, 0.05, false));
  }
  return g;
}

function buildCar(): THREE.Group {
  const g = new THREE.Group();
  const body = stdMat(0x1e3a8a, 0.35, 0.55);
  g.add(mesh(new THREE.BoxGeometry(4.3, 0.62, 1.78), body, 0, 0.62, 0));
  g.add(mesh(new THREE.BoxGeometry(2.2, 0.58, 1.6), stdMat(0x0f172a, 0.15, 0.5), -0.1, 1.2, 0));
  g.add(mesh(new THREE.BoxGeometry(2.0, 0.5, 1.64), body, -0.1, 1.45, 0));
  const wheelMat = stdMat(0x111827, 0.8);
  for (const [wx, wz] of [
    [1.35, 0.85],
    [1.35, -0.85],
    [-1.35, 0.85],
    [-1.35, -0.85],
  ]) {
    const w = mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.24, 16), wheelMat, wx, 0.34, wz);
    w.rotation.x = Math.PI / 2;
    g.add(w);
  }
  return g;
}

function buildPath(len: number, w: number): THREE.Group {
  const g = new THREE.Group();
  const m = stdMat(0xffffff, 0.9, 0, { map: pavingTexture(len / 0.6, w / 0.6) });
  g.add(mesh(new THREE.BoxGeometry(len, 0.04, w), m, 0, 0.02, 0, false));
  return g;
}

function buildLawn(w: number, h: number): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.BoxGeometry(w, 0.05, h), stdMat(0x5b9a45, 0.97), 0, 0.025, 0, false));
  return g;
}

function buildPool(w: number, h: number): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.BoxGeometry(w + 0.7, 0.06, h + 0.7), stdMat(0xe7e0d2, 0.85), 0, 0.03, 0, false));
  g.add(mesh(new THREE.BoxGeometry(w, 0.1, h), stdMat(0x0e7490, 0.3), 0, 0.09, 0, false));
  g.add(
    mesh(
      new THREE.BoxGeometry(w - 0.04, 0.02, h - 0.04),
      stdMat(0x38bdf8, 0.08, 0.1, { transparent: true, opacity: 0.8, emissive: new THREE.Color(0x0ea5e9), emissiveIntensity: 0.18 }),
      0,
      0.145,
      0,
      false
    )
  );
  return g;
}

function buildGardenLight(night: boolean): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.CylinderGeometry(0.04, 0.06, 3.0, 8), stdMat(0x1f2937, 0.5, 0.6), 0, 1.5, 0));
  g.add(mesh(new THREE.CylinderGeometry(0.2, 0.12, 0.08, 12), stdMat(0x1f2937, 0.5, 0.6), 0, 3.05, 0));
  g.add(
    mesh(
      new THREE.SphereGeometry(0.17, 14, 14),
      stdMat(0xfef3c7, 0.3, 0, { emissive: new THREE.Color(0xfacc15), emissiveIntensity: night ? 2.2 : 0.15 }),
      0,
      3.2,
      0,
      false
    )
  );
  return g;
}

function buildGenerator(): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(new THREE.BoxGeometry(1.1, 0.12, 0.62), stdMat(0x374151, 0.5, 0.5), 0, 0.06, 0));
  g.add(mesh(new THREE.BoxGeometry(1.0, 0.7, 0.55), stdMat(0xf59e0b, 0.45, 0.3), 0, 0.47, 0));
  g.add(mesh(new THREE.BoxGeometry(0.35, 0.3, 0.02), stdMat(0x111827, 0.4), 0.25, 0.55, 0.28, false));
  g.add(mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.5, 8), stdMat(0x6b7280, 0.4, 0.7), -0.4, 0.95, 0.1));
  return g;
}

function buildSolar(len: number): THREE.Group {
  const g = new THREE.Group();
  const panelMat = stdMat(0x1e3a8a, 0.25, 0.6);
  const n = Math.max(1, Math.round(len / 1.7));
  const w = len / n;
  for (let i = 0; i < n; i++) {
    const p = mesh(new THREE.BoxGeometry(w - 0.06, 0.05, 1.05), panelMat, -len / 2 + w * (i + 0.5), 1.1, 0);
    p.rotation.x = -0.55;
    g.add(p);
  }
  const metal = stdMat(0x94a3b8, 0.5, 0.7);
  for (let i = 0; i <= n; i++) {
    const leg = mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.1, 6), metal, -len / 2 + w * i, 0.55, 0.2);
    g.add(leg);
  }
  return g;
}

function buildTank(): THREE.Group {
  const g = new THREE.Group();
  const metal = stdMat(0x64748b, 0.5, 0.6);
  for (const [lx, lz] of [
    [0.45, 0.45],
    [-0.45, 0.45],
    [0.45, -0.45],
    [-0.45, -0.45],
  ]) {
    g.add(mesh(new THREE.CylinderGeometry(0.05, 0.05, 3.0, 8), metal, lx, 1.5, lz));
  }
  g.add(mesh(new THREE.CylinderGeometry(0.75, 0.75, 1.2, 20), stdMat(0x1d4ed8, 0.4, 0.2), 0, 3.6, 0));
  g.add(mesh(new THREE.SphereGeometry(0.75, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), stdMat(0x1d4ed8, 0.4, 0.2), 0, 4.2, 0));
  return g;
}

/** Construit l'objet 3D d'un élément d'environnement (origine = centre de l'empreinte, au sol). */
export function createEnvObject(o: EnvObject, nightMode: boolean): THREE.Group {
  const len = (o.len ?? ENV_DEFS[o.kind].defaults.len ?? 300) * SCALE;
  const w = (o.w ?? ENV_DEFS[o.kind].defaults.w ?? 300) * SCALE;
  const h = (o.h ?? ENV_DEFS[o.kind].defaults.h ?? 300) * SCALE;
  let g: THREE.Group;
  switch (o.kind) {
    case 'tree':
      g = buildTree();
      break;
    case 'palm':
      g = buildPalm();
      break;
    case 'bush':
      g = buildBush();
      break;
    case 'hedge':
      g = buildHedge(len);
      break;
    case 'wall':
      g = buildWall(len);
      break;
    case 'fence':
      g = buildFence(len);
      break;
    case 'gate':
      g = buildGate(len);
      break;
    case 'car':
      g = buildCar();
      break;
    case 'path':
      g = buildPath(len, w);
      break;
    case 'lawn':
      g = buildLawn(w, h);
      break;
    case 'pool':
      g = buildPool(w, h);
      break;
    case 'garden_light':
      g = buildGardenLight(nightMode);
      break;
    case 'generator':
      g = buildGenerator();
      break;
    case 'solar':
      g = buildSolar(len);
      break;
    case 'tank':
      g = buildTank();
      break;
  }
  const isLinear = o.kind === 'hedge' || o.kind === 'wall' || o.kind === 'fence' || o.kind === 'gate' || o.kind === 'solar';
  const s = o.scale ?? 1;
  // Pour les éléments linéaires, la longueur est un paramètre : l'échelle ne touche que la hauteur/épaisseur.
  if (isLinear) g.scale.set(1, s, s);
  else if (o.kind !== 'path' && o.kind !== 'lawn' && o.kind !== 'pool') g.scale.setScalar(s);
  g.position.set(o.x * SCALE, 0, o.y * SCALE);
  g.rotation.y = -(o.rot * Math.PI) / 180;
  g.userData.envId = o.id;
  g.userData.label = `${o.name || ENV_DEFS[o.kind].label}${o.locked ? ' · verrouillé' : ''}`;
  return g;
}
