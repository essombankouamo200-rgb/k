import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Banknote,
  Gauge,
  Moon,
  Pause,
  Play,
  Plug,
  RotateCcw,
  ShieldAlert,
  Sun,
  Zap,
} from 'lucide-react';
import { CircuitKind, ComputedCircuit, PlanProjectData } from '../types/planelec';
import { frNum, SimulationOutput } from '../utils/electricalEngine';
import { formatFcfa } from '../utils/formatters';

/* -------------------------------------------------------------------------- */
/*  Modèle de simulation temps réel                                           */
/*  - profils d'usage sur 24 h par type de circuit                            */
/*  - disjoncteurs magnéto-thermiques (courbe C) + disjoncteur de branchement */
/*  - différentiel 30 mA, délestage automatique, tarif HP/HC                  */
/* -------------------------------------------------------------------------- */

type Group = 'light' | 'plug' | 'heat' | 'cook' | 'ev';

const GROUP_OF: Record<CircuitKind, Group> = {
  light: 'light',
  spot: 'light',
  neon: 'light',
  stair_led: 'light',
  socket: 'plug',
  spec: 'plug',
  surveillance: 'plug',
  heat: 'heat',
  hvac: 'heat',
  cook: 'cook',
  irve: 'ev',
};

const GROUP_META: Record<Group, { label: string; color: string }> = {
  light: { label: 'Éclairage', color: '#f59e0b' },
  plug: { label: 'Prises & divers', color: '#0ea5e9' },
  heat: { label: 'Chauffage / clim', color: '#ef4444' },
  cook: { label: 'Cuisson', color: '#8b5cf6' },
  ev: { label: 'Recharge VE', color: '#10b981' },
};
const GROUP_ORDER: Group[] = ['plug', 'light', 'heat', 'cook', 'ev'];

interface Scenario {
  id: string;
  label: string;
  hint: string;
  light: number;
  lightStart: number;
  heat: number;
  ac: number;
  stress: boolean;
}

const SCENARIOS: Scenario[] = [
  { id: 'standard', label: 'Jour de mi-saison', hint: 'Usage courant d’un foyer', light: 1, lightStart: 18.5, heat: 0.35, ac: 0, stress: false },
  { id: 'hiver', label: 'Soirée d’hiver', hint: 'Chauffage soutenu, nuit tôt', light: 1.15, lightStart: 16.8, heat: 1, ac: 0, stress: false },
  { id: 'ete', label: 'Canicule', hint: 'Climatisation l’après-midi', light: 0.8, lightStart: 21, heat: 0, ac: 1, stress: false },
  { id: 'pic', label: 'Test de pic de charge', hint: 'Tout démarre à 18 h', light: 1, lightStart: 17.5, heat: 1, ac: 1, stress: true },
];

const APPLIANCES = [
  { id: 'kettle', label: 'Bouilloire', w: 2200 },
  { id: 'iron', label: 'Fer à repasser', w: 2400 },
  { id: 'dryer', label: 'Sèche-cheveux', w: 2000 },
  { id: 'vac', label: 'Aspirateur', w: 1400 },
  { id: 'oven', label: 'Four posable', w: 3000 },
];

const SPEEDS = [
  { v: 60, label: '1 min/s' },
  { v: 300, label: '5 min/s' },
  { v: 900, label: '15 min/s' },
  { v: 1800, label: '30 min/s' },
];

const VOLT = 230;
// Tarifs indicatifs en FCFA/kWh (à adapter selon votre distributeur : CIE, SENELEC, ENEO, SBEE…)
const HP_PRICE = 137; // heures pleines
const HC_PRICE = 107; // heures creuses
const CO2_G_PER_KWH = 400; // ordre de grandeur d'un mix thermique/hydraulique ouest-africain

const isHC = (h: number) => h >= 22 || h < 6;

const smooth = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
const win = (h: number, a: number, b: number, soft = 0.35) => {
  const raw = (x: number, e: number) => smooth(a - soft, a + soft, x) - smooth(e - soft, e + soft, x);
  if (a <= b) return Math.max(0, raw(h, b));
  return Math.max(0, raw(h, b + 24), raw(h + 24, b + 24));
};

function duty(kind: CircuitKind, h: number, sc: Scenario, evSmart: boolean, idx: number): number {
  const noise = 0.9 + 0.1 * Math.sin(h * 7.3 + idx * 1.7) * Math.sin(h * 2.1 + idx);
  let d = 0;
  switch (kind) {
    case 'light':
    case 'spot':
      d = (Math.max(win(h, 6.3, 8.2), win(h, sc.lightStart, 23.2)) * 0.85 + 0.01) * sc.light;
      break;
    case 'neon':
      d = win(h, 19, 24) * 0.7;
      break;
    case 'stair_led':
      d = Math.max(win(h, 6, 7.4) * 0.4, win(h, 18, 23.5) * 0.35, win(h, 23.5, 6) * 0.08);
      break;
    case 'socket':
      d = 0.1 + 0.4 * win(h, 7, 9) + 0.28 * win(h, 12, 14) + 0.55 * win(h, 18, 22.5);
      break;
    case 'spec':
      d = 0.08 + 0.75 * win(h, 8, 10) + 0.7 * win(h, 19.5, 21.5);
      break;
    case 'surveillance':
      d = 1;
      break;
    case 'heat':
      d = sc.heat * (0.25 + 0.55 * Math.max(win(h, 5.5, 9), win(h, 16.5, 23)));
      break;
    case 'hvac':
      d = sc.ac * 0.85 * win(h, 11, 20);
      break;
    case 'cook':
      d = 0.9 * win(h, 11.7, 12.9) + 0.95 * win(h, 18.8, 20);
      break;
    case 'irve':
      d = evSmart ? win(h, 23, 6) : win(h, 19, 23.5);
      break;
  }
  if (sc.stress) d = Math.max(d, win(h, 18, 21, 0.2));
  return Math.min(1, Math.max(0, d * (kind === 'surveillance' ? 1 : noise)));
}

interface SimEvent {
  id: number;
  t: number;
  tone: 'trip' | 'warn' | 'ok' | 'info';
  text: string;
}

interface ExtraLoad {
  circuitId: string;
  w: number;
  until: number;
  label: string;
}

interface Snapshot {
  t: number;
  totalW: number;
  totalA: number;
  maxA: number;
  mainHeat: number;
  blackout: boolean;
  powers: Record<string, number>;
  heats: Record<string, number>;
  shed: string[];
  energyWh: number;
  cost: number;
  peakW: number;
  groupW: Record<Group, number>;
  events: SimEvent[];
  extras: ExtraLoad[];
  history: { t: number; w: number }[];
}

const fmtClock = (t: number, withSec = true) => {
  const s = Math.floor(((t % 86400) + 86400) % 86400);
  const hh = String(Math.floor(s / 3600)).padStart(2, '0');
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return withSec ? `${hh}:${mm}:${ss}` : `${hh}:${mm}`;
};

/* ------------------------------- Ciel animé ------------------------------- */

const SKY_STOPS: [number, [number, number, number]][] = [
  [0, [11, 16, 38]],
  [5, [30, 42, 90]],
  [6.5, [245, 158, 114]],
  [8, [126, 200, 245]],
  [13, [90, 176, 240]],
  [18, [247, 163, 92]],
  [19.5, [107, 74, 143]],
  [21, [26, 31, 74]],
  [24, [11, 16, 38]],
];

function skyColor(h: number): string {
  for (let i = 0; i < SKY_STOPS.length - 1; i++) {
    const [h0, c0] = SKY_STOPS[i];
    const [h1, c1] = SKY_STOPS[i + 1];
    if (h >= h0 && h <= h1) {
      const f = (h - h0) / (h1 - h0);
      return `rgb(${c0.map((v, k) => Math.round(v + (c1[k] - v) * f)).join(',')})`;
    }
  }
  return 'rgb(11,16,38)';
}

function SkyBanner({ hour, lightLoad, blackout }: { hour: number; lightLoad: number; blackout: boolean }) {
  const top = skyColor(hour);
  const bottom = skyColor((hour + 1.2) % 24);
  const sunP = (hour - 6) / 12; // 6h → 18h
  const arc = (p: number) => ({ x: 40 + p * 640, y: 150 - Math.sin(Math.PI * p) * 120 });
  const sunVisible = sunP > -0.05 && sunP < 1.05;
  const moonPhase = ((hour + 12) % 24) / 12 - 1;
  const moonVisible = moonPhase > -0.05 && moonPhase < 1.05;
  const sun = arc(sunP);
  const moon = arc(moonPhase);
  const night = hour < 6 || hour >= 19.5;
  const glow = blackout ? 0 : Math.min(1, lightLoad * 1.4 + 0.05);
  return (
    <svg viewBox="0 0 720 180" className="block h-full w-full" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      <defs>
        <linearGradient id="sim-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={top} />
          <stop offset="1" stopColor={bottom} />
        </linearGradient>
        <radialGradient id="sim-sun">
          <stop offset="0" stopColor="#fff7d6" />
          <stop offset="0.35" stopColor="#fde047" />
          <stop offset="1" stopColor="#fde047" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="sim-win">
          <stop offset="0" stopColor="#fde68a" />
          <stop offset="1" stopColor="#f59e0b" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="720" height="180" fill="url(#sim-sky)" />
      {night &&
        Array.from({ length: 34 }).map((_, i) => (
          <circle
            key={i}
            cx={(i * 97) % 720}
            cy={(i * 53) % 110}
            r={i % 5 === 0 ? 1.6 : 0.9}
            fill="#fff"
            opacity={0.35 + 0.4 * Math.abs(Math.sin(hour * 3 + i))}
          />
        ))}
      {sunVisible && (
        <g>
          <circle cx={sun.x} cy={sun.y} r="46" fill="url(#sim-sun)" opacity="0.85" />
          <circle cx={sun.x} cy={sun.y} r="13" fill="#fff7d6" />
        </g>
      )}
      {moonVisible && (
        <g opacity="0.95">
          <circle cx={moon.x} cy={moon.y} r="12" fill="#e2e8f0" />
          <circle cx={moon.x + 5} cy={moon.y - 3} r="10" fill={top} />
        </g>
      )}
      {/* colline + maison */}
      <path d="M0 180 L0 150 Q180 128 360 148 T720 140 L720 180 Z" fill={night ? '#0b1220' : '#1f3a2e'} opacity="0.92" />
      <g transform="translate(300 96)">
        <rect x="0" y="34" width="120" height="50" fill={night ? '#1e293b' : '#e2e8f0'} />
        <path d="M-10 36 L60 -2 L130 36 Z" fill={night ? '#334155' : '#64748b'} />
        <rect x="14" y="48" width="26" height="22" fill="#0f172a" />
        <rect x="80" y="48" width="26" height="22" fill="#0f172a" />
        <rect x="14" y="48" width="26" height="22" fill="#fde68a" opacity={glow} />
        <rect x="80" y="48" width="26" height="22" fill="#fde68a" opacity={glow * 0.9} />
        <circle cx="27" cy="59" r="34" fill="url(#sim-win)" opacity={glow * 0.5} />
        <circle cx="93" cy="59" r="34" fill="url(#sim-win)" opacity={glow * 0.5} />
        <rect x="52" y="56" width="16" height="28" fill="#475569" />
      </g>
    </svg>
  );
}

/* -------------------------------- Jauge ----------------------------------- */

function CurrentGauge({ ratio, amps, maxA }: { ratio: number; amps: number; maxA: number }) {
  const R = 84;
  const cx = 110;
  const cy = 100;
  const toXY = (r: number, a: number) => [cx + r * Math.cos(a), cy - r * Math.sin(a)];
  const scale = 1.2;
  const arcPath = (from: number, to: number) => {
    const a0 = Math.PI - (from / scale) * Math.PI;
    const a1 = Math.PI - (to / scale) * Math.PI;
    const [x0, y0] = toXY(R, a0);
    const [x1, y1] = toXY(R, a1);
    return `M${x0} ${y0} A${R} ${R} 0 0 1 ${x1} ${y1}`;
  };
  const needle = Math.PI - (Math.min(ratio, scale) / scale) * Math.PI;
  const [nx, ny] = toXY(R - 10, needle);
  const col = ratio > 1 ? '#ef4444' : ratio > 0.85 ? '#f59e0b' : '#10b981';
  return (
    <svg viewBox="0 0 220 128" className="mx-auto w-full max-w-[260px]" role="img" aria-label={`Intensité ${frNum(amps, 1)} ampères sur ${frNum(maxA, 0)}`}>
      <path d={arcPath(0, scale)} stroke="currentColor" strokeOpacity="0.12" strokeWidth="14" fill="none" strokeLinecap="round" />
      <path d={arcPath(0, 0.7)} stroke="#10b981" strokeWidth="14" fill="none" strokeLinecap="round" opacity="0.85" />
      <path d={arcPath(0.7, 1)} stroke="#f59e0b" strokeWidth="14" fill="none" opacity="0.85" />
      <path d={arcPath(1, scale)} stroke="#ef4444" strokeWidth="14" fill="none" strokeLinecap="round" opacity="0.85" />
      <line
        x1={cx}
        y1={cy}
        x2={nx}
        y2={ny}
        stroke={col}
        strokeWidth="3.5"
        strokeLinecap="round"
        style={{ transition: 'all 180ms cubic-bezier(.3,1.4,.5,1)' }}
      />
      <circle cx={cx} cy={cy} r="7" fill={col} style={{ transition: 'fill 200ms' }} />
      <text x={cx} y={cy + 22} textAnchor="middle" className="fill-current font-mono" fontSize="18" fontWeight="700">
        {frNum(amps, 1)} A
      </text>
      <text x="26" y="118" textAnchor="middle" className="fill-current" fontSize="8" opacity="0.5">0</text>
      <text x="194" y="118" textAnchor="middle" className="fill-current" fontSize="8" opacity="0.5">{frNum(maxA * scale, 0)}</text>
    </svg>
  );
}

/* ------------------------------ Graphique 24 h ----------------------------- */

function DayChart({
  curve,
  limitW,
  nowT,
  history,
  onScrub,
}: {
  curve: { t: number; g: Record<Group, number> }[];
  limitW: number;
  nowT: number;
  history: { t: number; w: number }[];
  onScrub: (t: number) => void;
}) {
  const W = 720;
  const H = 230;
  const L = 44;
  const B = 26;
  const T = 10;
  const maxP = Math.max(limitW * 1.08, ...curve.map((p) => GROUP_ORDER.reduce((s, g) => s + p.g[g], 0))) || 1;
  const x = (t: number) => L + (t / 86400) * (W - L - 8);
  const y = (p: number) => T + (1 - p / maxP) * (H - T - B);
  const stacks = useMemo(() => {
    const paths: { g: Group; d: string }[] = [];
    const cum = curve.map(() => 0);
    GROUP_ORDER.forEach((g) => {
      const top = curve.map((p, i) => {
        cum[i] += p.g[g];
        return cum[i];
      });
      const bottom = top.map((v, i) => v - curve[i].g[g]);
      const up = curve.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(p.t).toFixed(1)} ${y(top[i]).toFixed(1)}`).join(' ');
      const down = [...curve]
        .map((p, i) => `L${x(p.t).toFixed(1)} ${y(bottom[i]).toFixed(1)}`)
        .reverse()
        .join(' ');
      paths.push({ g, d: `${up} ${down} Z` });
    });
    return paths;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [curve, maxP]);

  const ticks = [0, 3, 6, 9, 12, 15, 18, 21, 24];
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((f) => f * maxP);
  const hist = history.length > 1 ? history.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(p.t).toFixed(1)} ${y(p.w).toFixed(1)}`).join(' ') : '';

  const handle = (e: React.PointerEvent<SVGSVGElement>) => {
    if (e.type === 'pointermove' && e.buttons !== 1) return;
    const r = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    onScrub(Math.min(86399, Math.max(0, ((px - L) / (W - L - 8)) * 86400)));
  };

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="w-full cursor-col-resize touch-none select-none"
      onPointerDown={handle}
      onPointerMove={handle}
      role="img"
      aria-label="Puissance prévue sur 24 heures par famille d’usage"
    >
      {/* nuit / HC */}
      <rect x={x(0)} y={T} width={x(6 * 3600) - x(0)} height={H - T - B} fill="currentColor" opacity="0.05" />
      <rect x={x(22 * 3600)} y={T} width={x(86400) - x(22 * 3600)} height={H - T - B} fill="currentColor" opacity="0.05" />
      {yTicks.map((v) => (
        <g key={v}>
          <line x1={L} x2={W - 8} y1={y(v)} y2={y(v)} stroke="currentColor" opacity="0.1" />
          <text x={L - 6} y={y(v) + 3} textAnchor="end" fontSize="9" className="fill-current font-mono" opacity="0.55">
            {frNum(v / 1000, 1)}
          </text>
        </g>
      ))}
      {ticks.map((h) => (
        <text key={h} x={x(h * 3600)} y={H - 8} textAnchor="middle" fontSize="9" className="fill-current font-mono" opacity="0.55">
          {h}h
        </text>
      ))}
      {stacks.map((s) => (
        <path key={s.g} d={s.d} fill={GROUP_META[s.g].color} opacity="0.78" />
      ))}
      <line x1={L} x2={W - 8} y1={y(limitW)} y2={y(limitW)} stroke="#ef4444" strokeWidth="1.5" strokeDasharray="5 4" />
      <text x={L + 6} y={y(limitW) - 4} textAnchor="start" fontSize="9" fill="#ef4444" fontWeight="600">
        Limite abonnement
      </text>
      {hist && <path d={hist} fill="none" stroke="currentColor" strokeWidth="1.8" />}
      <line x1={x(nowT)} x2={x(nowT)} y1={T} y2={H - B} stroke="currentColor" strokeWidth="1.5" />
      <circle cx={x(nowT)} cy={T + 2} r="4" className="fill-current" />
      
    </svg>
  );
}

/* ------------------------------ Composant -------------------------------- */

interface LiveSimulationViewProps {
  project: PlanProjectData;
  sim: SimulationOutput;
  trippedCircuitIds: Set<string>;
  onSetTripped: (ids: string[], tripped: boolean) => void;
  onClockChange?: (hour: number) => void;
}

export function LiveSimulationView({
  project,
  sim,
  trippedCircuitIds,
  onSetTripped,
  onClockChange,
}: LiveSimulationViewProps) {
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(300);
  const [scenarioId, setScenarioId] = useState('standard');
  const [autoShed, setAutoShed] = useState(true);
  const [evSmart, setEvSmart] = useState(false);
  const [applianceCircuit, setApplianceCircuit] = useState<string>('');
  const [snap, setSnap] = useState<Snapshot | null>(null);

  const scenario = SCENARIOS.find((s) => s.id === scenarioId) ?? SCENARIOS[0];
  const maxA = (project.subscriptionKva * 1000) / VOLT;

  const circuits = sim.circuits;
  const groupOfCircuit = useMemo(() => {
    const m = new Map<string, string>();
    sim.panel.rows.forEach((row) => row.circuits.forEach((c) => m.set(c.id, row.id)));
    return m;
  }, [sim.panel.rows]);

  const socketCircuits = useMemo(() => circuits.filter((c) => c.kind === 'socket'), [circuits]);
  useEffect(() => {
    if (!socketCircuits.some((c) => c.id === applianceCircuit)) {
      setApplianceCircuit(socketCircuits[0]?.id ?? '');
    }
  }, [socketCircuits, applianceCircuit]);

  /* Refs lus par la boucle d'animation */
  const circuitsRef = useRef(circuits);
  const trippedRef = useRef(trippedCircuitIds);
  const scenarioRef = useRef(scenario);
  const evSmartRef = useRef(evSmart);
  const autoShedRef = useRef(autoShed);
  const maxARef = useRef(maxA);
  const groupMapRef = useRef(groupOfCircuit);
  const onSetTrippedRef = useRef(onSetTripped);
  const onClockRef = useRef(onClockChange);
  circuitsRef.current = circuits;
  trippedRef.current = trippedCircuitIds;
  scenarioRef.current = scenario;
  evSmartRef.current = evSmart;
  autoShedRef.current = autoShed;
  maxARef.current = maxA;
  groupMapRef.current = groupOfCircuit;
  onSetTrippedRef.current = onSetTripped;
  onClockRef.current = onClockChange;

  /* Courbe prévisionnelle 24 h (sans déclenchement) */
  const curve = useMemo(() => {
    const pts: { t: number; g: Record<Group, number> }[] = [];
    for (let i = 0; i <= 288; i++) {
      const t = i * 300;
      const h = t / 3600;
      const g: Record<Group, number> = { light: 0, plug: 0, heat: 0, cook: 0, ev: 0 };
      circuits.forEach((c, idx) => {
        g[GROUP_OF[c.kind]] += c.watts * duty(c.kind, h, scenario, evSmart, idx);
      });
      pts.push({ t, g });
    }
    return pts;
  }, [circuits, scenario, evSmart]);
  const curveRef = useRef(curve);
  curveRef.current = curve;

  /* Moteur (mutable) */
  const engine = useRef({
    t: 17.4 * 3600,
    heat: {} as Record<string, number>,
    mainHeat: 0,
    shed: new Set<string>(),
    calm: 0,
    energyWh: 0,
    cost: 0,
    peakW: 0,
    blackout: false,
    events: [] as SimEvent[],
    extras: [] as ExtraLoad[],
    evId: 1,
    history: [] as { t: number; w: number }[],
    lastHist: -1,
    lastHC: isHC(17.4),
    powers: {} as Record<string, number>,
    totalW: 0,
    groupW: { light: 0, plug: 0, heat: 0, cook: 0, ev: 0 } as Record<Group, number>,
    pendingFaults: [] as string[],
  }).current;

  const log = useCallback(
    (tone: SimEvent['tone'], text: string) => {
      engine.events.unshift({ id: engine.evId++, t: engine.t, tone, text });
      if (engine.events.length > 40) engine.events.pop();
    },
    [engine]
  );

  const integrateTo = useCallback(
    (t: number) => {
      let wh = 0;
      let eur = 0;
      const c = curveRef.current;
      for (let i = 0; i < c.length - 1 && c[i].t < t; i++) {
        const p = GROUP_ORDER.reduce((s, g) => s + c[i].g[g], 0);
        const dt = Math.min(300, t - c[i].t);
        const e = (p * dt) / 3600;
        wh += e;
        eur += (e / 1000) * (isHC(c[i].t / 3600) ? HC_PRICE : HP_PRICE);
      }
      engine.energyWh = wh;
      engine.cost = eur;
    },
    [engine]
  );

  const scrubTo = useCallback(
    (t: number) => {
      engine.t = t;
      engine.history = [];
      engine.lastHist = -1;
      engine.peakW = 0;
      integrateTo(t);
      engine.lastHC = isHC(t / 3600);
      onClockRef.current?.(t / 3600);
    },
    [engine, integrateTo]
  );

  useEffect(() => {
    integrateTo(engine.t);
  }, [integrateTo, engine]);

  const substep = useCallback(
    (dt: number) => {
      const cs = circuitsRef.current;
      const sc = scenarioRef.current;
      const evS = evSmartRef.current;
      const Imax = maxARef.current;
      const hour = engine.t / 3600;
      const tripped = trippedRef.current;
      const newTrips: string[] = [];

      // expiration des charges ponctuelles
      engine.extras = engine.extras.filter((e) => e.until > engine.t);

      // défauts d'isolement -> différentiel
      while (engine.pendingFaults.length) {
        const fid = engine.pendingFaults.pop()!;
        const c = cs.find((x) => x.id === fid);
        const gid = groupMapRef.current.get(fid);
        if (!c || !gid) continue;
        const ids = cs.filter((x) => groupMapRef.current.get(x.id) === gid).map((x) => x.id);
        log('trip', `Différentiel 30 mA ouvert (fuite de 45 mA sur « ${c.name} ») — ${ids.length} circuit(s) coupé(s)`);
        newTrips.push(...ids);
      }

      let total = 0;
      const gW: Record<Group, number> = { light: 0, plug: 0, heat: 0, cook: 0, ev: 0 };
      const wanted: Record<string, number> = {};

      cs.forEach((c, idx) => {
        const want = c.watts * duty(c.kind, hour, sc, evS, idx);
        wanted[c.id] = want;
        const isOff = tripped.has(c.id) || newTrips.includes(c.id) || engine.blackout || engine.shed.has(c.id);
        const extraW = engine.extras.filter((e) => e.circuitId === c.id).reduce((s, e) => s + e.w, 0);
        const P = isOff ? 0 : want + extraW;
        engine.powers[c.id] = P;
        total += P;
        gW[GROUP_OF[c.kind]] += P;

        // magnéto-thermique courbe C
        const I = P / VOLT;
        const r = I / c.breakerA;
        let h = engine.heat[c.id] ?? 0;
        if (r >= 6) {
          h = 1;
        } else if (r > 1.13) {
          h += ((r * r - 1) / 3960) * dt;
        } else {
          h = Math.max(0, h - (h * dt) / 900);
        }
        engine.heat[c.id] = Math.min(1, h);
        if (h >= 1 && !isOff) {
          log('trip', `Disjoncteur ${c.breakerA} A déclenché sur « ${c.name} » (${r >= 6 ? 'court-circuit' : 'surcharge'} ${frNum(I, 1)} A)`);
          newTrips.push(c.id);
          engine.heat[c.id] = 0;
        }
      });

      const Itot = total / VOLT;
      const rm = Itot / Imax;

      // délestage automatique
      if (autoShedRef.current) {
        if (rm > 0.92) {
          const prio: CircuitKind[] = ['hvac', 'heat', 'irve', 'spec'];
          const cand = cs
            .filter((c) => !engine.shed.has(c.id) && !tripped.has(c.id) && (engine.powers[c.id] ?? 0) > 50 && prio.includes(c.kind))
            .sort((a, b) => prio.indexOf(a.kind) - prio.indexOf(b.kind) || (engine.powers[b.id] ?? 0) - (engine.powers[a.id] ?? 0))[0];
          if (cand) {
            engine.shed.add(cand.id);
            engine.calm = 0;
            log('warn', `Délestage : « ${cand.name} » coupé pour éviter le dépassement (${frNum(Itot, 1)} A / ${frNum(Imax, 0)} A)`);
          }
        } else if (engine.shed.size > 0) {
          engine.calm += dt;
          if (engine.calm > 240) {
            const id = [...engine.shed][0];
            const c = cs.find((x) => x.id === id);
            if (!c || (total + (wanted[id] ?? 0)) / VOLT < Imax * 0.8) {
              engine.shed.delete(id);
              engine.calm = 0;
              if (c) log('ok', `Délestage levé : « ${c.name} » est rétabli`);
            }
          }
        }
      } else if (engine.shed.size) {
        engine.shed.clear();
      }

      // disjoncteur de branchement
      if (rm > 1.0 && !engine.blackout) {
        engine.mainHeat += ((rm * rm - 1) / 1500) * dt;
        if (rm > 2.2) engine.mainHeat = 1;
      } else {
        engine.mainHeat = Math.max(0, engine.mainHeat - (engine.mainHeat * dt) / 600);
      }
      if (engine.mainHeat >= 1 && !engine.blackout) {
        engine.blackout = true;
        engine.mainHeat = 0;
        log('trip', `PANNE GÉNÉRALE — disjoncteur de branchement ouvert (${frNum(Itot, 1)} A > ${frNum(Imax, 0)} A souscrits)`);
        newTrips.push(...cs.map((c) => c.id));
      }

      if (newTrips.length) onSetTrippedRef.current([...new Set(newTrips)], true);

      // énergie et coût
      const kwh = (total * dt) / 3600 / 1000;
      engine.energyWh += kwh * 1000;
      engine.cost += kwh * (isHC(hour) ? HC_PRICE : HP_PRICE);
      engine.peakW = Math.max(engine.peakW, total);
      engine.totalW = total;
      engine.groupW = gW;

      const hc = isHC(hour);
      if (hc !== engine.lastHC) {
        engine.lastHC = hc;
        log('info', hc ? 'Début des heures creuses (22 h – 6 h)' : 'Retour aux heures pleines');
      }

      if (engine.lastHist < 0 || engine.t - engine.lastHist >= 300) {
        engine.history.push({ t: engine.t, w: total });
        engine.lastHist = engine.t;
      }
    },
    [engine, log]
  );

  /* Boucle d'animation */
  const playingRef = useRef(playing);
  const speedRef = useRef(speed);
  playingRef.current = playing;
  speedRef.current = speed;

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    let clockAcc = 0;
    const tick = (now: number) => {
      const real = Math.min(0.1, (now - last) / 1000);
      last = now;
      if (playingRef.current) {
        let simDt = real * speedRef.current;
        while (simDt > 0) {
          const d = Math.min(simDt, 20);
          engine.t += d;
          if (engine.t >= 86400) {
            engine.t -= 86400;
            engine.energyWh = 0;
            engine.cost = 0;
            engine.peakW = 0;
            engine.history = [];
            engine.lastHist = -1;
            log('info', 'Nouvelle journée — compteurs remis à zéro');
          }
          substep(d);
          simDt -= d;
        }
        clockAcc += real;
        if (clockAcc > 0.5) {
          clockAcc = 0;
          onClockRef.current?.(engine.t / 3600);
        }
      } else {
        substep(0.001);
      }
      acc += real;
      if (acc > 1 / 14) {
        acc = 0;
        setSnap({
          t: engine.t,
          totalW: engine.totalW,
          totalA: engine.totalW / VOLT,
          maxA: maxARef.current,
          mainHeat: engine.mainHeat,
          blackout: engine.blackout,
          powers: { ...engine.powers },
          heats: { ...engine.heat },
          shed: [...engine.shed],
          energyWh: engine.energyWh,
          cost: engine.cost,
          peakW: engine.peakW,
          groupW: { ...engine.groupW },
          events: [...engine.events],
          extras: [...engine.extras],
          history: [...engine.history],
        });
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [engine, substep, log]);

  /* Actions */
  const addAppliance = (a: (typeof APPLIANCES)[number]) => {
    const c = circuits.find((x) => x.id === applianceCircuit);
    if (!c) return;
    engine.extras.push({ circuitId: c.id, w: a.w, until: engine.t + 20 * 60, label: a.label });
    log('info', `${a.label} (${a.w} W) branché sur « ${c.name} » pour 20 min`);
  };

  const rearmCircuit = (c: ComputedCircuit) => {
    engine.heat[c.id] = 0;
    onSetTripped([c.id], false);
    log('ok', `Disjoncteur de « ${c.name} » réarmé`);
  };

  const rearmAll = () => {
    engine.blackout = false;
    engine.mainHeat = 0;
    engine.shed.clear();
    engine.extras = [];
    circuits.forEach((c) => (engine.heat[c.id] = 0));
    onSetTripped(circuits.map((c) => c.id), false);
    log('ok', 'Tout le tableau est réarmé');
  };

  const s: Snapshot = snap ?? {
    t: engine.t,
    totalW: 0,
    totalA: 0,
    maxA,
    mainHeat: 0,
    blackout: false,
    powers: {},
    heats: {},
    shed: [],
    energyWh: 0,
    cost: 0,
    peakW: 0,
    groupW: { light: 0, plug: 0, heat: 0, cook: 0, ev: 0 },
    events: [],
    extras: [],
    history: [],
  };

  const hour = s.t / 3600;
  const ratio = s.totalA / maxA;
  const hc = isHC(hour);
  const lightLoad = (() => {
    const lw = circuits.filter((c) => GROUP_OF[c.kind] === 'light').reduce((a, c) => a + c.watts, 0) || 1;
    return Math.min(1, s.groupW.light / lw);
  })();
  const trippedCount = circuits.filter((c) => trippedCircuitIds.has(c.id)).length;

  if (circuits.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
        Aucun circuit à simuler. Placez des équipements sur le plan 2D, puis revenez ici pour lancer la journée.
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Ciel + horloge */}
      <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="relative h-40 sm:h-48">
          <SkyBanner hour={hour} lightLoad={lightLoad} blackout={s.blackout} />
          <div className="absolute inset-0 flex items-start justify-between p-4 text-white">
            <div>
              <div className="font-mono text-4xl font-semibold tabular-nums drop-shadow sm:text-5xl">{fmtClock(s.t)}</div>
              <div className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-black/35 px-2.5 py-1 text-xs font-medium backdrop-blur">
                {hour >= 6 && hour < 19.5 ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
                {hc ? 'Heures creuses' : 'Heures pleines'} · {frNum(hc ? HC_PRICE : HP_PRICE, 0)} FCFA/kWh
              </div>
            </div>
            {s.blackout && (
              <div className="animate-pulse rounded-lg bg-red-600/90 px-3 py-2 text-sm font-semibold shadow-lg">
                <ShieldAlert className="mr-1.5 inline h-4 w-4" />
                Panne générale
              </div>
            )}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 border-t border-slate-200 px-4 py-3 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-slate-900 text-white transition hover:scale-105 active:scale-95 dark:bg-white dark:text-slate-900"
            aria-label={playing ? 'Pause' : 'Lecture'}
          >
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </button>
          <input
            type="range"
            min={0}
            max={86399}
            step={60}
            value={Math.floor(s.t)}
            onChange={(e) => scrubTo(Number(e.target.value))}
            className="min-w-[160px] flex-1 accent-blue-700 dark:accent-sky-400"
            aria-label="Heure de la journée"
          />
          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-0.5 dark:bg-slate-800">
            {SPEEDS.map((sp) => (
              <button
                key={sp.v}
                type="button"
                onClick={() => setSpeed(sp.v)}
                className={`rounded-md px-2 py-1 text-[11px] font-medium transition ${
                  speed === sp.v
                    ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-600 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                {sp.label}
              </button>
            ))}
          </div>
          <select
            value={scenarioId}
            onChange={(e) => setScenarioId(e.target.value)}
            title={scenario.hint}
            aria-label="Scénario"
            className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium dark:border-slate-700 dark:bg-slate-950"
          >
            {SCENARIOS.map((sc) => (
              <option key={sc.id} value={sc.id}>
                {sc.label}
              </option>
            ))}
          </select>
          <label className="inline-flex cursor-pointer items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-200">
            <input type="checkbox" checked={autoShed} onChange={(e) => setAutoShed(e.target.checked)} className="accent-blue-700" />
            Délestage auto
          </label>
          <label className="inline-flex cursor-pointer items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-200">
            <input type="checkbox" checked={evSmart} onChange={(e) => setEvSmart(e.target.checked)} className="accent-blue-700" />
            Recharge VE en heures creuses
          </label>
        </div>
      </section>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Kpi icon={<Zap className="h-4 w-4" />} label="Puissance" value={`${frNum(s.totalW / 1000, 2)} kW`} sub={`pic ${frNum(s.peakW / 1000, 2)} kW`} tone={ratio > 1 ? 'bad' : ratio > 0.85 ? 'warn' : 'ok'} />
        <Kpi icon={<Activity className="h-4 w-4" />} label="Énergie du jour" value={`${frNum(s.energyWh / 1000, 1)} kWh`} sub={`${frNum((s.energyWh / 1000) * CO2_G_PER_KWH, 0)} g CO₂`} />
        <Kpi icon={<Banknote className="h-4 w-4" />} label="Coût du jour" value={formatFcfa(s.cost)} sub={`≈ ${formatFcfa(s.cost * 30)}/mois`} />
        <Kpi icon={<Gauge className="h-4 w-4" />} label="Tension" value={`${frNum(VOLT - s.totalA * 0.045, 1)} V`} sub="chute en ligne incluse" />
        <Kpi
          icon={<AlertTriangle className="h-4 w-4" />}
          label="Protections"
          value={s.blackout ? 'Panne' : trippedCount > 0 ? `${trippedCount} ouvert(s)` : 'Normal'}
          sub={s.shed.length ? `${s.shed.length} délesté(s)` : 'aucun délestage'}
          tone={s.blackout || trippedCount ? 'bad' : s.shed.length ? 'warn' : 'ok'}
        />
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-5">
          {/* Graphique */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-sm font-semibold">Journée type · puissance par usage (kW)</h2>
              <div className="flex flex-wrap gap-3 text-[11px] text-slate-600 dark:text-slate-300">
                {GROUP_ORDER.map((g) => (
                  <span key={g} className="inline-flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-sm" style={{ background: GROUP_META[g].color }} />
                    {GROUP_META[g].label}
                  </span>
                ))}
                <span className="inline-flex items-center gap-1.5">
                  <span className="h-0.5 w-3 bg-current" /> Mesuré
                </span>
              </div>
            </div>
            <DayChart curve={curve} limitW={maxA * VOLT} nowT={s.t} history={s.history} onScrub={scrubTo} />
            <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
              Cliquez ou glissez sur le graphique pour sauter à une heure. Zones grisées : heures creuses.
            </p>
          </section>

          {/* Circuits */}
          <section className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 dark:border-slate-800">
              <h2 className="font-display text-sm font-semibold">Circuits en direct</h2>
              <button
                type="button"
                onClick={rearmAll}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <RotateCcw className="h-3.5 w-3.5" /> Tout réarmer
              </button>
            </div>
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">
              {circuits.map((c) => {
                const P = s.powers[c.id] ?? 0;
                const I = P / VOLT;
                const r = I / c.breakerA;
                const heat = s.heats[c.id] ?? 0;
                const isTrip = trippedCircuitIds.has(c.id);
                const isShed = s.shed.includes(c.id);
                const status = isTrip ? 'Déclenché' : isShed ? 'Délesté' : P > 5 ? 'En charge' : 'Veille';
                const barColor = r > 1 ? '#ef4444' : r > 0.8 ? '#f59e0b' : c.color;
                return (
                  <li key={c.id} className="px-4 py-2.5">
                    <div className="flex items-center gap-3">
                      <span className="h-3 w-3 shrink-0 rounded-full" style={{ background: c.color }} />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate text-sm font-medium">{c.name}</span>
                          <span
                            className={`rounded-full px-1.5 py-0.5 text-[10px] font-semibold ${
                              isTrip
                                ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                                : isShed
                                  ? 'bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300'
                                  : P > 5
                                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                    : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                            }`}
                          >
                            {status}
                          </span>
                        </div>
                        <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                          <div
                            className="relative h-full rounded-full"
                            style={{
                              width: `${Math.min(100, r * 100)}%`,
                              background: barColor,
                              transition: 'width 220ms ease-out, background 200ms',
                            }}
                          >
                            {P > 5 && <div className="sim-flow absolute inset-0 rounded-full" />}
                          </div>
                        </div>
                        <div className="mt-1 h-0.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800" title="Échauffement du bilame">
                          <div className="h-full bg-orange-500" style={{ width: `${heat * 100}%`, transition: 'width 220ms' }} />
                        </div>
                      </div>
                      <div className="w-28 shrink-0 text-right font-mono text-[11px] tabular-nums text-slate-600 dark:text-slate-300">
                        <div className="text-sm font-semibold text-slate-900 dark:text-white">{frNum(P, 0)} W</div>
                        {frNum(I, 1)} / {c.breakerA} A
                      </div>
                      <div className="flex shrink-0 gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            engine.pendingFaults.push(c.id);
                          }}
                          title="Simuler un défaut d’isolement (fuite 45 mA)"
                          className="rounded-md border border-slate-200 p-1.5 text-amber-600 hover:bg-amber-50 dark:border-slate-700 dark:hover:bg-slate-800"
                        >
                          <Zap className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => (isTrip ? rearmCircuit(c) : onSetTripped([c.id], true))}
                          title={isTrip ? 'Réarmer' : 'Ouvrir le disjoncteur'}
                          className={`rounded-md border p-1.5 ${
                            isTrip
                              ? 'border-red-300 bg-red-50 text-red-700 hover:bg-red-100 dark:border-red-900 dark:bg-red-950 dark:text-red-300'
                              : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800'
                          }`}
                        >
                          {isTrip ? <RotateCcw className="h-3.5 w-3.5" /> : <ShieldAlert className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>
        </div>

        <aside className="space-y-5">
          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-1 font-display text-sm font-semibold">Disjoncteur de branchement</h2>
            <CurrentGauge ratio={ratio} amps={s.totalA} maxA={maxA} />
            <div className="mt-2">
              <div className="mb-1 flex justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span>Échauffement</span>
                <span>
                  {project.subscriptionKva} kVA · {frNum(maxA, 0)} A
                </span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                <div className="h-full bg-orange-500" style={{ width: `${s.mainHeat * 100}%`, transition: 'width 200ms' }} />
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="mb-2 flex items-center gap-1.5 font-display text-sm font-semibold">
              <Plug className="h-4 w-4" /> Brancher un appareil
            </h2>
            {socketCircuits.length === 0 ? (
              <p className="text-xs text-slate-500">Aucun circuit prises dans ce projet.</p>
            ) : (
              <>
                <select
                  value={applianceCircuit}
                  onChange={(e) => setApplianceCircuit(e.target.value)}
                  className="mb-2 w-full rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-950"
                >
                  {socketCircuits.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} · {c.breakerA} A
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-1.5">
                  {APPLIANCES.map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => addAppliance(a)}
                      className="rounded-lg border border-slate-200 px-2 py-1.5 text-left text-xs transition hover:-translate-y-0.5 hover:border-slate-400 hover:shadow-sm active:translate-y-0 dark:border-slate-700 dark:hover:border-slate-500"
                    >
                      <div className="font-medium">{a.label}</div>
                      <div className="font-mono text-[10px] text-slate-500 dark:text-slate-400">{a.w} W · 20 min</div>
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
                  Branchez-en plusieurs sur le même circuit : le bilame chauffe, puis le disjoncteur déclenche.
                </p>
              </>
            )}
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <h2 className="border-b border-slate-200 px-4 py-3 font-display text-sm font-semibold dark:border-slate-800">Journal</h2>
            <ul className="max-h-72 space-y-1 overflow-y-auto p-3 text-xs">
              {s.events.length === 0 && <li className="text-slate-500">Aucun événement pour l’instant.</li>}
              {s.events.map((e) => (
                <li
                  key={e.id}
                  className={`rounded-md px-2 py-1.5 ${
                    e.tone === 'trip'
                      ? 'bg-red-50 text-red-800 dark:bg-red-950/60 dark:text-red-200'
                      : e.tone === 'warn'
                        ? 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-200'
                        : e.tone === 'ok'
                          ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-200'
                          : 'bg-slate-50 text-slate-700 dark:bg-slate-800/60 dark:text-slate-200'
                  }`}
                >
                  <span className="mr-1.5 font-mono font-semibold">{fmtClock(e.t, false)}</span>
                  {e.text}
                </li>
              ))}
            </ul>
          </section>
        </aside>
      </div>
      <style>{`
        .sim-flow{background:repeating-linear-gradient(90deg,rgba(255,255,255,.55) 0 6px,transparent 6px 16px);background-size:16px 100%;animation:simflow .7s linear infinite;mix-blend-mode:overlay}
        @keyframes simflow{to{background-position:16px 0}}
      `}</style>
    </div>
  );
}

function Kpi({
  icon,
  label,
  value,
  sub,
  tone = 'ok',
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  tone?: 'ok' | 'warn' | 'bad';
}) {
  const ring =
    tone === 'bad'
      ? 'border-red-300 dark:border-red-900'
      : tone === 'warn'
        ? 'border-amber-300 dark:border-amber-900'
        : 'border-slate-200 dark:border-slate-800';
  return (
    <div className={`rounded-xl border bg-white px-4 py-3 transition-colors dark:bg-slate-900 ${ring}`}>
      <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
        {icon}
        {label}
      </div>
      <div className="mt-1 font-display text-xl font-bold tabular-nums">{value}</div>
      {sub && <div className="text-[11px] text-slate-500 dark:text-slate-400">{sub}</div>}
    </div>
  );
}

