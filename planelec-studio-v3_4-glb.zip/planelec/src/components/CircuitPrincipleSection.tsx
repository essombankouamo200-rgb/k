import { useEffect, useState } from 'react';
import { Power, ShieldCheck, Zap } from 'lucide-react';
import { ComputedCircuit } from '../types/planelec';
import { TYPES } from '../data/catalog';
import { frNum, SimulationOutput, wattsOf } from '../utils/electricalEngine';

interface CircuitPrincipleSectionProps {
  sim: SimulationOutput;
  selectedCircuitId: string | null;
  trippedCircuitIds: Set<string>;
  onSelectCircuit: (id: string) => void;
  onToggleCircuitTrip: (id: string) => void;
}

export function CircuitPrincipleSection({
  sim,
  selectedCircuitId,
  trippedCircuitIds,
  onSelectCircuit,
  onToggleCircuitTrip,
}: CircuitPrincipleSectionProps) {
  const [testSwitchOn, setTestSwitchOn] = useState(true);

  const circuit: ComputedCircuit | undefined =
    sim.circuits.find((c) => c.id === selectedCircuitId) ?? sim.circuits[0];

  useEffect(() => {
    setTestSwitchOn(true);
  }, [circuit?.id]);

  if (!circuit) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
        Ajoutez au moins un équipement électrique sur le Plan 2D pour inspecter son principe de câblage détaillé.
      </div>
    );
  }

  const isTripped = trippedCircuitIds.has(circuit.id);
  const isEnergized = !isTripped && testSwitchOn;

  const hasPushbutton = circuit.items.some((i) => i.type === 'pushbutton');
  const hasSwitch = circuit.items.some((i) =>
    ['switch', 'dimmer', 'motion'].includes(i.type)
  );
  const isLightKind =
    circuit.kind === 'light' || circuit.kind === 'spot' || circuit.kind === 'neon';
  const isStairLed = circuit.kind === 'stair_led';
  const isChauffeEau =
    circuit.kind === 'spec' &&
    circuit.items.some((i) => /chauffe[-\s]?eau|cumulus|ballon/i.test(i.name));
  const isHeat = circuit.kind === 'heat';
  const isHvac = circuit.kind === 'hvac';
  const isSurveillance = circuit.kind === 'surveillance';

  const loadItems = circuit.items.filter(
    (i) => !['switch', 'pushbutton', 'dimmer', 'motion', 'thermostat'].includes(i.type)
  );
  const cmdItems = circuit.items.filter((i) =>
    ['switch', 'pushbutton', 'dimmer', 'motion', 'thermostat'].includes(i.type)
  );

  const ictaDiameter =
    circuit.sectionMm2 >= 6 ? 'ICTA Ø25 mm' : circuit.sectionMm2 >= 2.5 ? 'ICTA Ø20 mm' : 'ICTA Ø16 mm';

  const conductorLegend = [
    { name: 'Phase (L)', color: '#dc2626', spec: `${frNum(circuit.sectionMm2, 1)} mm² · Rouge` },
    { name: 'Neutre (N)', color: '#2563eb', spec: `${frNum(circuit.sectionMm2, 1)} mm² · Bleu` },
    { name: 'Terre (PE)', color: '#16a34a', spec: `${frNum(circuit.sectionMm2, 1)} mm² · Vert/Jaune` },
  ];
  if (isLightKind || isStairLed || isChauffeEau) {
    conductorLegend.push({
      name: hasPushbutton ? 'Retour BP / Lampe' : isChauffeEau ? 'Asservissement C1/C2' : 'Retour Lampe',
      color: '#ea580c',
      spec: '1,5 mm² · Orange / Violet',
    });
  }
  if (isHeat) {
    conductorLegend.push({
      name: 'Fil Pilote (6 ordres)',
      color: '#334155',
      spec: '1,5 mm² · Noir',
    });
  }
  if (isSurveillance) {
    conductorLegend.push({
      name: 'Bus PoE / Signal',
      color: '#0891b2',
      spec: 'Cat. 6 / Blindé',
    });
  }
  if (isHvac) {
    conductorLegend.push({
      name: 'Bus Clim / Liaison 4G',
      color: '#0891b2',
      spec: '1,5 mm² · Signal + Com',
    });
  }

  const displayedLoads = loadItems.slice(0, 5);
  const extraLoadCount = Math.max(0, loadItems.length - displayedLoads.length);

  return (
    <div className="grid grid-cols-1 items-start gap-5 lg:grid-cols-[300px_minmax(0,1fr)]">
      {/* LEFT: Circuit Picker */}
      <aside className="rounded-xl border border-slate-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900">
        <h3 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
          Circuits de l’installation ({sim.circuits.length})
        </h3>
        <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
          Sélectionnez un circuit pour voir son schéma de branchement complet.
        </p>

        <div className="mt-3 max-h-[540px] space-y-1.5 overflow-y-auto pr-1">
          {sim.circuits.map((c) => {
            const active = c.id === circuit.id;
            const cut = trippedCircuitIds.has(c.id);
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => onSelectCircuit(c.id)}
                className={`flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition-colors ${
                  active
                    ? 'border-slate-900 bg-slate-900 text-white dark:border-white dark:bg-white dark:text-slate-950'
                    : 'border-slate-200 bg-slate-50/70 text-slate-800 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-200 dark:hover:bg-slate-800'
                }`}
              >
                <span
                  className="h-7 w-1.5 shrink-0 rounded-full"
                  style={{ backgroundColor: c.color }}
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-semibold">{c.name}</div>
                  <div
                    className={`font-mono text-[10px] tabular-nums ${
                      active
                        ? 'text-slate-300 dark:text-slate-700'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    C{c.breakerA} · {frNum(c.sectionMm2, 1)} mm² · {frNum(c.watts)} W
                    {cut ? ' · COUPÉ' : ''}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </aside>

      {/* RIGHT: Detailed Multifilar Wiring Principle */}
      <div className="space-y-4">
        {/* Circuit Header & Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <span
              className="h-8 w-2 rounded-full"
              style={{ backgroundColor: circuit.color }}
            />
            <div>
              <h3 className="font-display text-base font-semibold text-slate-950 dark:text-white">
                Principe de câblage : {circuit.name}
              </h3>
              <div className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                ID 30 mA Type {circuit.diffType} → Disj. {circuit.breakerA} A → {ictaDiameter} ({frNum(circuit.sectionMm2, 1)} mm²)
                {circuit.lengthM !== null ? ` · ≈ ${frNum(circuit.lengthM)} m` : ''}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(isLightKind || isStairLed || isChauffeEau) && (
              <button
                type="button"
                onClick={() => setTestSwitchOn((p) => !p)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium ${
                  testSwitchOn
                    ? 'border-amber-400 bg-amber-50 text-amber-900 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-200'
                    : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                <Zap className="h-3.5 w-3.5" />
                <span>
                  {hasPushbutton
                    ? testSwitchOn
                      ? 'Relais télérupteur : FERMÉ'
                      : 'Relais télérupteur : OUVERT'
                    : isChauffeEau
                    ? testSwitchOn
                      ? 'Heures Creuses / Marche : ON'
                      : 'Contacteur J/N : VEILLE'
                    : testSwitchOn
                    ? 'Commande : ALLUMÉE'
                    : 'Commande : ÉTEINTE'}
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={() => onToggleCircuitTrip(circuit.id)}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium ${
                isTripped
                  ? 'border-red-300 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950/50 dark:text-red-300'
                  : 'border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-300'
              }`}
            >
              <Power className="h-3.5 w-3.5" />
              <span>{isTripped ? 'Disjoncteur COUPÉ' : 'Disjoncteur ARMÉ'}</span>
            </button>
          </div>
        </div>

        {/* Detailed Step-by-Step Multifilar Diagram SVG */}
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <svg
            viewBox="0 0 920 380"
            className="w-full min-w-[760px] select-none"
            role="img"
            aria-label={`Principe de câblage détaillé du circuit ${circuit.name}`}
          >
            <rect width="920" height="380" rx="8" fill="#ffffff" />

            {/* Zone dividers */}
            <rect x="16" y="16" width="230" height="348" rx="8" fill="#f8fafc" stroke="#e2e8f0" />
            <text x="28" y="36" fontSize="10.5" fontWeight="700" fill="#475569">
              1. PROTECTION TABLEAU
            </text>

            <rect x="260" y="16" width="265" height="348" rx="8" fill="#f8fafc" stroke="#e2e8f0" />
            <text x="272" y="36" fontSize="10.5" fontWeight="700" fill="#475569">
              2. COMMANDE / AUTOMATISME
            </text>

            <rect x="539" y="16" width="365" height="348" rx="8" fill="#f8fafc" stroke="#e2e8f0" />
            <text x="551" y="36" fontSize="10.5" fontWeight="700" fill="#475569">
              3. DISTRIBUTION & APPAREILS ({loadItems.length})
            </text>

            {/* 1A: Interrupteur Différentiel */}
            <g transform="translate(32, 62)">
              <rect
                x="0"
                y="0"
                width="82"
                height="112"
                rx="5"
                fill={circuit.diffType === 'A' ? '#fff7ed' : '#ffffff'}
                stroke={circuit.diffType === 'A' ? '#c2410c' : '#334155'}
                strokeWidth="2"
              />
              <rect
                x="6"
                y="6"
                width="70"
                height="18"
                rx="3"
                fill={circuit.diffType === 'A' ? '#fed7aa' : '#e2e8f0'}
              />
              <text x="41" y="18.5" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#0f172a">
                ID 30 mA
              </text>
              <text x="41" y="42" textAnchor="middle" fontSize="10" fontWeight="700" fill="#1e293b">
                Type {circuit.diffType}
              </text>
              <rect x="20" y="56" width="42" height="18" rx="3" fill="#16a34a" />
              <text x="41" y="68" textAnchor="middle" fontSize="9" fontWeight="700" fill="#ffffff">
                ON
              </text>
              <text x="41" y="98" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#475569">
                N        L
              </text>
            </g>

            {/* 1B: Disjoncteur Divisionnaire */}
            <g
              transform="translate(148, 62)"
              onClick={() => onToggleCircuitTrip(circuit.id)}
              className="cursor-pointer"
            >
              <rect
                x="0"
                y="0"
                width="76"
                height="112"
                rx="5"
                fill={isTripped ? '#fef2f2' : '#ffffff'}
                stroke={isTripped ? '#dc2626' : '#0f172a'}
                strokeWidth="2.2"
              />
              <rect x="4" y="4" width="68" height="6" rx="2" fill={circuit.color} />
              <text x="38" y="26" textAnchor="middle" fontSize="12" fontWeight="700" fill="#0f172a">
                C{circuit.breakerA}
              </text>
              <text x="38" y="40" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#475569">
                {frNum(circuit.sectionMm2, 1)} mm²
              </text>
              <rect
                x="17"
                y="56"
                width="42"
                height="18"
                rx="3"
                fill={isTripped ? '#dc2626' : '#16a34a'}
              />
              <text x="38" y="68" textAnchor="middle" fontSize="9" fontWeight="700" fill="#ffffff">
                {isTripped ? 'OFF' : 'ON'}
              </text>
              <text x="38" y="98" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#475569">
                N        L
              </text>
            </g>

            {/* Busbars ID -> Breaker */}
            <path d="M52 174 V192 H166 V174" fill="none" stroke="#2563eb" strokeWidth="2.8" />
            <path d="M94 174 V202 H204 V174" fill="none" stroke="#dc2626" strokeWidth="2.8" />

            {/* Terre PE Busbar */}
            <g transform="translate(32, 294)">
              <rect x="0" y="0" width="192" height="20" rx="4" fill="#16a34a" />
              <text x="96" y="13.5" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#ffffff">
                Bornier Terre (PE) · Vert/Jaune
              </text>
              <path d="M222 10 H878" fill="none" stroke="#16a34a" strokeWidth="2.2" strokeDasharray="6 3" />
              <path d="M192 10 H222" fill="none" stroke="#16a34a" strokeWidth="2.2" />
            </g>

            {/* Outgoing Neutral & Phase from Breaker into Section 2 */}
            <path
              d="M166 174 V238 H565"
              fill="none"
              stroke="#2563eb"
              strokeWidth="2.8"
              opacity={isTripped ? 0.3 : 1}
            />
            <path
              d="M204 174 V216 H290"
              fill="none"
              stroke="#dc2626"
              strokeWidth="2.8"
              opacity={isTripped ? 0.3 : 1}
            />

            {/* SECTION 2: COMMAND / RELAY / DIRECT */}
            {hasPushbutton ? (
              <g>
                {/* Télérupteur */}
                <g transform="translate(290, 74)">
                  <rect x="0" y="0" width="118" height="96" rx="6" fill="#f3e8ff" stroke="#7c3aed" strokeWidth="2" />
                  <text x="59" y="18" textAnchor="middle" fontSize="10" fontWeight="700" fill="#5b21b6">
                    Télérupteur 16 A
                  </text>
                  <text x="59" y="34" textAnchor="middle" fontSize="8.5" fill="#6d28d9">
                    Bobine A1 / A2
                  </text>
                  <rect
                    x="22"
                    y="46"
                    width="74"
                    height="22"
                    rx="4"
                    fill={isEnergized ? '#7c3aed' : '#ffffff'}
                    stroke="#7c3aed"
                  />
                  <text
                    x="59"
                    y="60"
                    textAnchor="middle"
                    fontSize="9"
                    fontWeight="700"
                    fill={isEnergized ? '#ffffff' : '#5b21b6'}
                  >
                    {isEnergized ? 'Contact 1-2 FERMÉ' : 'Contact 1-2 OUVERT'}
                  </text>
                  <text x="59" y="86" textAnchor="middle" fontSize="8" fontFamily="JetBrains Mono, monospace" fill="#475569">
                    1(L)   A1   A2   2(Ret)
                  </text>
                </g>
                {/* Phase into 1(L) and BP */}
                <path d="M290 216 H308 V170" fill="none" stroke="#dc2626" strokeWidth="2.5" opacity={isTripped ? 0.3 : 1} />
                {/* Neutral tap into A2 */}
                <path d="M372 238 V170" fill="none" stroke="#2563eb" strokeWidth="2.2" opacity={isTripped ? 0.3 : 1} />
                {/* Pushbutton block */}
                <g
                  transform="translate(425, 198)"
                  onClick={() => setTestSwitchOn((p) => !p)}
                  className="cursor-pointer"
                >
                  <rect x="0" y="0" width="88" height="62" rx="6" fill="#fff7ed" stroke="#ea580c" strokeWidth="1.8" />
                  <text x="44" y="20" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#9a3412">
                    {cmdItems.length} Poussoir(s)
                  </text>
                  <text x="44" y="34" textAnchor="middle" fontSize="8.5" fill="#c2410c">
                    en parallèle
                  </text>
                  <text x="44" y="50" textAnchor="middle" fontSize="8" fontWeight="700" fill="#ea580c">
                    Cliquer pour tester
                  </text>
                </g>
                {/* Phase to BP & Retour Orange BP -> A1 */}
                <path d="M308 216 H425" fill="none" stroke="#dc2626" strokeWidth="2.2" opacity={isTripped ? 0.3 : 1} />
                <path d="M469 198 V182 H346 V170" fill="none" stroke="#ea580c" strokeWidth="2.2" strokeDasharray="4 3" opacity={isTripped ? 0.3 : 1} />
                {/* Output 2(Ret) -> Loads */}
                <path
                  d="M396 170 V188 H565"
                  fill="none"
                  stroke="#ea580c"
                  strokeWidth="3"
                  opacity={isEnergized ? 1 : 0.3}
                />
              </g>
            ) : isStairLed ? (
              <g>
                <g transform="translate(288, 70)">
                  <rect x="0" y="0" width="212" height="104" rx="6" fill="#fef9c3" stroke="#ca8a04" strokeWidth="2" />
                  <text x="106" y="20" textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#854d0e">
                    Contrôleur Escalier LED 24 V
                  </text>
                  <text x="106" y="36" textAnchor="middle" fontSize="8.5" fill="#a16207">
                    Alim. 230V AC → Sorties marches séquentielles
                  </text>
                  <rect x="16" y="48" width="84" height="24" rx="4" fill="#0891b2" />
                  <text x="58" y="63" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">
                    Capteur PIR Bas
                  </text>
                  <rect x="112" y="48" width="84" height="24" rx="4" fill="#0891b2" />
                  <text x="154" y="63" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">
                    Capteur PIR Haut
                  </text>
                  <text x="106" y="92" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#713f12">
                    Bus 1..14 marches + Retour commun
                  </text>
                </g>
                <path d="M290 216 H320 V174" fill="none" stroke="#dc2626" strokeWidth="2.5" opacity={isTripped ? 0.3 : 1} />
                <path d="M360 238 V174" fill="none" stroke="#2563eb" strokeWidth="2.2" opacity={isTripped ? 0.3 : 1} />
                <path
                  d="M500 124 H565 V188"
                  fill="none"
                  stroke="#ea580c"
                  strokeWidth="3"
                  opacity={isEnergized ? 1 : 0.3}
                />
              </g>
            ) : isChauffeEau ? (
              <g>
                <g transform="translate(284, 68)">
                  <rect x="0" y="0" width="124" height="106" rx="6" fill="#eff6ff" stroke="#2563eb" strokeWidth="2" />
                  <text x="62" y="20" textAnchor="middle" fontSize="10" fontWeight="700" fill="#1e40af">
                    Contacteur J / N
                  </text>
                  <text x="62" y="34" textAnchor="middle" fontSize="8.5" fill="#1e3a8a">
                    Bobine A1/A2 (Disj. 2 A)
                  </text>
                  <rect x="18" y="46" width="88" height="24" rx="4" fill={isEnergized ? '#2563eb' : '#94a3b8'} />
                  <text x="62" y="61" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">
                    {isEnergized ? 'AUTO (HC Actif)' : 'VEILLE (HP)'}
                  </text>
                  <text x="62" y="94" textAnchor="middle" fontSize="8" fontFamily="JetBrains Mono, monospace" fill="#334155">
                    1-3 Entrée → 2-4 Ballon
                  </text>
                </g>
                <g transform="translate(422, 68)">
                  <rect x="0" y="0" width="90" height="72" rx="6" fill="#ecfdf5" stroke="#059669" strokeWidth="1.8" />
                  <text x="45" y="20" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#065f46">
                    Compteur HP/HC
                  </text>
                  <text x="45" y="36" textAnchor="middle" fontSize="8" fill="#047857">
                    Contact sec C1/C2
                  </text>
                  <text x="45" y="54" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fontWeight="700" fill="#065f46">
                    22h30 – 06h30
                  </text>
                </g>
                <path d="M422 108 H408" fill="none" stroke="#ea580c" strokeWidth="2.4" strokeDasharray="4 2" />
                <path d="M290 216 H312 V174" fill="none" stroke="#dc2626" strokeWidth="2.5" opacity={isTripped ? 0.3 : 1} />
                <path d="M360 174 V188 H565" fill="none" stroke="#dc2626" strokeWidth="2.8" opacity={isEnergized ? 1 : 0.3} />
              </g>
            ) : isLightKind || hasSwitch ? (
              <g>
                <g
                  transform="translate(310, 102)"
                  onClick={() => setTestSwitchOn((p) => !p)}
                  className="cursor-pointer"
                >
                  <rect x="0" y="0" width="160" height="86" rx="6" fill="#fff7ed" stroke="#ea580c" strokeWidth="2" />
                  <text x="80" y="22" textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#9a3412">
                    {cmdItems[0]?.type === 'dimmer'
                      ? 'Variateur rotatif'
                      : cmdItems[0]?.type === 'motion'
                      ? 'Détecteur présence PIR'
                      : 'Interrupteur / Va-et-vient'}
                  </text>
                  <text x="80" y="38" textAnchor="middle" fontSize="8.5" fill="#c2410c">
                    Coupure de Phase uniquement (L)
                  </text>
                  <rect
                    x="32"
                    y="48"
                    width="96"
                    height="22"
                    rx="4"
                    fill={isEnergized ? '#16a34a' : '#64748b'}
                  />
                  <text x="80" y="62.5" textAnchor="middle" fontSize="9" fontWeight="700" fill="#ffffff">
                    {isEnergized ? 'FERMÉ (Cliquer)' : 'OUVERT (Cliquer)'}
                  </text>
                </g>
                <path d="M290 216 H340 V188" fill="none" stroke="#dc2626" strokeWidth="2.8" opacity={isTripped ? 0.3 : 1} />
                <path
                  d="M470 145 H525 V188 H565"
                  fill="none"
                  stroke="#ea580c"
                  strokeWidth="2.8"
                  opacity={isEnergized ? 1 : 0.3}
                />
                <text x="515" y="138" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ea580c">
                  Retour
                </text>
              </g>
            ) : isHvac ? (
              <g>
                <g transform="translate(284, 72)">
                  <rect x="0" y="0" width="128" height="102" rx="6" fill="#ecfeff" stroke="#0891b2" strokeWidth="2" />
                  <text x="64" y="20" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#164e63">
                    Sectionneur IP65
                  </text>
                  <text x="64" y="34" textAnchor="middle" fontSize="8" fill="#0e7490">
                    Proximité groupe ext.
                  </text>
                  <rect x="20" y="48" width="88" height="22" rx="4" fill={isEnergized ? '#0891b2' : '#94a3b8'} />
                  <text x="64" y="62.5" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">
                    {isEnergized ? 'ON · Courbe D 20A' : 'COUPÉ'}
                  </text>
                  <text x="64" y="92" textAnchor="middle" fontSize="8" fontFamily="JetBrains Mono, monospace" fill="#334155">
                    3G 2,5 mm² + 4G 1,5
                  </text>
                </g>
                <g transform="translate(424, 72)">
                  <rect x="0" y="0" width="88" height="72" rx="6" fill="#f0f9ff" stroke="#0284c7" strokeWidth="1.8" />
                  <text x="44" y="20" textAnchor="middle" fontSize="9.5" fontWeight="700" fill="#0369a1">
                    Thermostat
                  </text>
                  <text x="44" y="36" textAnchor="middle" fontSize="8" fill="#0284c7">
                    Consigne 21 °C
                  </text>
                  <text x="44" y="54" textAnchor="middle" fontSize="8" fontFamily="JetBrains Mono, monospace" fill="#0c4a6e">
                    Bus Com
                  </text>
                </g>
                <path d="M290 216 H312 V174" fill="none" stroke="#dc2626" strokeWidth="2.8" opacity={isTripped ? 0.3 : 1} />
                <path d="M360 174 V188 H565" fill="none" stroke="#dc2626" strokeWidth="2.8" opacity={isEnergized ? 1 : 0.3} />
                <path d="M468 144 V264 H875" fill="none" stroke="#0891b2" strokeWidth="2" strokeDasharray="4 3" />
              </g>
            ) : (
              <g>
                <g transform="translate(295, 112)">
                  <rect x="0" y="0" width="194" height="72" rx="6" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.8" />
                  <text x="97" y="24" textAnchor="middle" fontSize="10" fontWeight="700" fill="#0f172a">
                    Boîte de dérivation / Raccordement
                  </text>
                  <text x="97" y="42" textAnchor="middle" fontSize="8.5" fill="#475569">
                    {isSurveillance
                      ? 'Alimentation 230V + Bus PoE / Alarme'
                      : isHeat
                      ? 'Sortie de câble + Fil pilote 6 ordres'
                      : `Tirage direct 3G ${frNum(circuit.sectionMm2, 1)} mm² (${ictaDiameter})`}
                  </text>
                  <text x="97" y="58" textAnchor="middle" fontSize="8.5" fontFamily="JetBrains Mono, monospace" fill="#64748b">
                    Wago / Bornes automatiques
                  </text>
                </g>
                <path
                  d="M290 216 H320 V184 M460 184 V188 H565"
                  fill="none"
                  stroke="#dc2626"
                  strokeWidth="2.8"
                  opacity={isEnergized ? 1 : 0.3}
                />
                {isHeat && (
                  <path
                    d="M392 184 V264 H875"
                    fill="none"
                    stroke="#334155"
                    strokeWidth="2"
                    strokeDasharray="5 3"
                  />
                )}
              </g>
            )}

            {/* SECTION 3: ACTUAL LOADS IN PARALLEL */}
            <path
              d={`M565 188 H${565 + Math.max(0, displayedLoads.length - 1) * 68 + 30}`}
              fill="none"
              stroke={isLightKind || isStairLed ? '#ea580c' : '#dc2626'}
              strokeWidth="2.8"
              opacity={isEnergized ? 1 : 0.3}
            />
            <path
              d={`M565 238 H${565 + Math.max(0, displayedLoads.length - 1) * 68 + 42}`}
              fill="none"
              stroke="#2563eb"
              strokeWidth="2.8"
              opacity={isTripped ? 0.3 : 1}
            />

            {displayedLoads.map((it, idx) => {
              const lx = 562 + idx * 68;
              const T = TYPES[it.type];
              const label = (it.name || T.short).slice(0, 10);
              return (
                <g key={it.id} transform={`translate(${lx}, 92)`}>
                  {/* Taps down from busbars */}
                  <line
                    x1="22"
                    y1="96"
                    x2="22"
                    y2="68"
                    stroke={isLightKind || isStairLed ? '#ea580c' : '#dc2626'}
                    strokeWidth="2.2"
                    opacity={isEnergized ? 1 : 0.3}
                  />
                  <line
                    x1="34"
                    y1="146"
                    x2="34"
                    y2="68"
                    stroke="#2563eb"
                    strokeWidth="2.2"
                    opacity={isTripped ? 0.3 : 1}
                  />
                  <line
                    x1="46"
                    y1="212"
                    x2="46"
                    y2="68"
                    stroke="#16a34a"
                    strokeWidth="1.8"
                    strokeDasharray="4 2"
                  />

                  <rect
                    x="0"
                    y="0"
                    width="60"
                    height="68"
                    rx="6"
                    fill={isEnergized ? '#ffffff' : '#f1f5f9'}
                    stroke={isEnergized ? circuit.color : '#94a3b8'}
                    strokeWidth="1.8"
                  />
                  {isEnergized && (isLightKind || isStairLed) && (
                    <circle cx="30" cy="22" r="11" fill="#fde047" opacity="0.55" />
                  )}
                  <circle
                    cx="30"
                    cy="22"
                    r="7"
                    fill={isEnergized ? '#fef08a' : '#e2e8f0'}
                    stroke="#334155"
                    strokeWidth="1.5"
                  />
                  <text x="30" y="44" textAnchor="middle" fontSize="8" fontWeight="700" fill="#0f172a">
                    {label}
                  </text>
                  <text x="30" y="57" textAnchor="middle" fontSize="7.5" fontFamily="JetBrains Mono, monospace" fill="#475569">
                    {frNum(wattsOf(it))} W
                  </text>
                </g>
              );
            })}

            {extraLoadCount > 0 && (
              <text x="720" y="348" textAnchor="middle" fontSize="9.5" fontWeight="600" fill="#475569">
                + {extraLoadCount} autre(s) point(s) repiqué(s) en parallèle sur le même circuit
              </text>
            )}
          </svg>
        </div>

        {/* Conductor Color & Gauge Legend */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {conductorLegend.map((cond) => (
            <div
              key={cond.name}
              className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs dark:border-slate-800 dark:bg-slate-900"
            >
              <span
                className="h-3 w-6 shrink-0 rounded-sm"
                style={{ backgroundColor: cond.color }}
              />
              <div className="min-w-0">
                <div className="font-semibold text-slate-900 dark:text-white">
                  {cond.name}
                </div>
                <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                  {cond.spec}
                </div>
              </div>
            </div>
          ))}
          <div className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs dark:border-slate-800 dark:bg-slate-900">
            <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600" />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">
                Chute U : {circuit.dropPct !== null ? `${frNum(circuit.dropPct, 1)} %` : '—'}
              </div>
              <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                Max norme : {circuit.dropMaxPct} % · {ictaDiameter}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
