import { useEffect, useRef, useState } from 'react';
import {
  Copy,
  Footprints,
  Layers,
  Lightbulb,
  Lock,
  Maximize2,
  Minus,
  MousePointer,
  Pause,
  Play,
  Plus,
  RotateCw,
  Square,
  Trash2,
  Unlock,
} from 'lucide-react';
import {
  FinishStyle,
  FloorFinishId,
  FloorLevel,
  ItemType,
  PlanItem,
  PlanProjectData,
  Room,
  RoomType,
  SelectionTarget,
  ToolId,
  ToolTabId,
  WallFinishId,
} from '../types/planelec';
import {
  APPLIANCE_PRESETS,
  FINISH_STYLES,
  FLOOR_FINISHES,
  ROOM_TYPES,
  TOOL_TABS,
  TYPES,
  WALL_FINISHES,
} from '../data/catalog';
import {
  clamp,
  fitItemInRoom,
  frNum,
  halfOf,
  moveItemToPoint,
  nearestEdge,
  roomAt,
  SimulationOutput,
  snap,
  wallPos,
  wattsOf,
} from '../utils/electricalEngine';
import {
  getItemBounds,
  SvgFurniture,
  SvgSymbol,
  TOOLBAR_ICON_TRANSFORMS,
} from './SvgIcons';

const WALL_ANGLES: Record<string, number> = {
  top: 0,
  right: 90,
  bottom: 180,
  left: -90,
};

interface Plan2DEditorProps {
  project: PlanProjectData;
  sim: SimulationOutput;
  selected: SelectionTarget | null;
  highlightedCircuitId: string | null;
  trippedCircuitIds: Set<string>;
  showCables: boolean;
  showFurn: boolean;
  showNames: boolean;
  showDimensions: boolean;
  showSafetyZones: boolean;
  simulateLighting: boolean;
  activeStairStep: number | null;
  stairWalkMode: 'up' | 'down' | null;
  requestedTool?: ItemType | null;
  onClearRequestedTool?: () => void;
  onToggleCables: (v: boolean) => void;
  onToggleFurn: (v: boolean) => void;
  onToggleNames: (v: boolean) => void;
  onToggleDimensions: (v: boolean) => void;
  onToggleSafetyZones: (v: boolean) => void;
  onToggleSimulateLighting: (v: boolean) => void;
  onChangeStairStep: (step: number | null) => void;
  onSetStairWalkMode: (mode: 'up' | 'down' | null) => void;
  onSelect: (sel: SelectionTarget | null) => void;
  onCommitProject: (next: PlanProjectData, recordHistory?: boolean) => void;
  svgRefExternal: React.RefObject<SVGSVGElement | null>;
}

export function Plan2DEditor({
  project,
  sim,
  selected,
  highlightedCircuitId,
  trippedCircuitIds,
  showCables,
  showFurn,
  showNames,
  showDimensions,
  showSafetyZones,
  simulateLighting,
  activeStairStep,
  stairWalkMode,
  requestedTool,
  onClearRequestedTool,
  onToggleCables,
  onToggleFurn,
  onToggleNames,
  onToggleDimensions,
  onToggleSafetyZones,
  onToggleSimulateLighting,
  onChangeStairStep,
  onSetStairWalkMode,
  onSelect,
  onCommitProject,
  svgRefExternal,
}: Plan2DEditorProps) {
  const [activeTab, setActiveTab] = useState<ToolTabId>('pieces');
  const [activeTool, setActiveTool] = useState<ToolId>('select');
  const [view, setView] = useState<{ auto: boolean; cx: number; cy: number; zoom: number }>({
    auto: true,
    cx: 0,
    cy: 0,
    zoom: 1,
  });
  const [litRoomIds, setLitRoomIds] = useState<Set<number>>(() => new Set());
  const [showCameraFov, setShowCameraFov] = useState(true);
  const [drawBox, setDrawBox] = useState<{
    x0: number;
    y0: number;
    x1: number;
    y1: number;
  } | null>(null);
  const [viewportSize, setViewportSize] = useState({ w: 800, h: 520 });

  const dragRef = useRef<
    | { kind: 'item'; id: number; dx: number; dy: number; snapshot: PlanProjectData; moved: boolean }
    | { kind: 'room'; id: number; sx: number; sy: number; ax: number; ay: number; snapshot: PlanProjectData; moved: boolean }
    | { kind: 'pan'; sx: number; sy: number; cx: number; cy: number; u: number }
    | null
  >(null);

  // Sync external tool jump (e.g. from Library "Poser en 2D")
  useEffect(() => {
    if (!requestedTool) return;
    const ownerTab = TOOL_TABS.find((t) => t.tools.includes(requestedTool));
    if (ownerTab) setActiveTab(ownerTab.id);
    setActiveTool(requestedTool);
    onClearRequestedTool?.();
  }, [requestedTool, onClearRequestedTool]);

  // Track SVG pixel aspect ratio for crisp auto-fit viewBox
  useEffect(() => {
    const el = svgRefExternal.current;
    if (!el) return;
    const updateSize = () => {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        setViewportSize({ w: rect.width, h: rect.height });
      }
    };
    updateSize();
    const ro = new ResizeObserver(updateSize);
    ro.observe(el);
    return () => ro.disconnect();
  }, [svgRefExternal]);

  const sortedFloors = [...project.floors].sort(
    (a, b) => a.elevationIndex - b.elevationIndex
  );
  const floorRooms = project.rooms.filter((r) => r.floorId === project.activeFloorId);
  const floorItems = project.items.filter((i) => i.floorId === project.activeFloorId);
  const allStaircases = project.items.filter((i) => i.type === 'staircase');
  const floorStaircases = floorItems.filter((i) => i.type === 'staircase');
  const maxStairSteps = Math.max(
    14,
    ...allStaircases.map((s) => s.stepCount ?? 14)
  );

  const computeBbox = () => {
    const pool = floorRooms.length ? floorRooms : project.rooms;
    if (!pool.length) return { x: -100, y: -100, w: 700, h: 500 };
    const x0 = Math.min(...pool.map((r) => r.x));
    const y0 = Math.min(...pool.map((r) => r.y));
    const x1 = Math.max(...pool.map((r) => r.x + r.w));
    const y1 = Math.max(...pool.map((r) => r.y + r.h));
    return { x: x0 - 90, y: y0 - 90, w: x1 - x0 + 180, h: y1 - y0 + 180 };
  };

  const b = computeBbox();
  const asp = viewportSize.w / viewportSize.h;
  const fw = Math.max(b.w, b.h * asp);
  const fh = fw / asp;
  const z = view.auto ? 1 : view.zoom;
  const cx = view.auto ? b.x + b.w / 2 : view.cx;
  const cy = view.auto ? b.y + b.h / 2 : view.cy;
  const viewBoxStr = `${cx - fw / z / 2} ${cy - fh / z / 2} ${fw / z} ${fh / z}`;

  const freezeView = () => {
    if (view.auto) return { cx: b.x + b.w / 2, cy: b.y + b.h / 2, zoom: 1 };
    return view;
  };

  const zoomBy = (factor: number, about?: { x: number; y: number }) => {
    const base = freezeView();
    const z0 = base.zoom;
    const z1 = clamp(z0 * factor, 0.3, 6);
    let ncx = base.cx;
    let ncy = base.cy;
    if (about) {
      ncx = about.x - ((about.x - base.cx) * z0) / z1;
      ncy = about.y - ((about.y - base.cy) * z0) / z1;
    }
    setView({ auto: false, cx: ncx, cy: ncy, zoom: z1 });
  };

  const svgPoint = (clientX: number, clientY: number) => {
    const svg = svgRefExternal.current;
    if (!svg) return { x: 0, y: 0 };
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const res = pt.matrixTransform(ctm.inverse());
    return { x: res.x, y: res.y };
  };

  const handleAddFloor = () => {
    const maxElev = Math.max(...project.floors.map((f) => f.elevationIndex), 0);
    const nextElev = maxElev + 1;
    const newId = project.nextId;
    const name = nextElev === 1 ? '1er Étage' : `${nextElev}e Étage`;
    const newFloor: FloorLevel = { id: newId, name, elevationIndex: nextElev };

    // Copy corridor/stairwell footprint from previous top floor as starter palier if available
    const prevTopFloor = sortedFloors[sortedFloors.length - 1];
    const starterCorridor = prevTopFloor
      ? project.rooms.find(
          (r) => r.floorId === prevTopFloor.id && r.type === 'couloir'
        )
      : undefined;

    let nextId = newId + 1;
    const addedRooms: Room[] = [];
    const addedItems: PlanItem[] = [];

    if (starterCorridor) {
      const palier: Room = {
        id: nextId++,
        floorId: newId,
        x: starterCorridor.x,
        y: starterCorridor.y,
        w: starterCorridor.w,
        h: starterCorridor.h,
        type: 'couloir',
        name: `Palier ${name}`,
      };
      addedRooms.push(palier);
      const prevStair = project.items.find(
        (i) => i.floorId === prevTopFloor.id && i.type === 'staircase'
      );
      if (prevStair) {
        addedItems.push({
          ...prevStair,
          id: nextId++,
          floorId: newId,
          roomId: palier.id,
          name: `Arrivée Escalier`,
        });
      }
    }

    onCommitProject(
      {
        ...project,
        floors: [...project.floors, newFloor],
        activeFloorId: newId,
        rooms: [...project.rooms, ...addedRooms],
        items: [...project.items, ...addedItems],
        nextId,
      },
      true
    );
    setView({ auto: true, cx: 0, cy: 0, zoom: 1 });
  };

  const handleDeleteActiveFloor = () => {
    if (project.floors.length <= 1) return;
    const targetId = project.activeFloorId;
    const remainingFloors = project.floors.filter((f) => f.id !== targetId);
    onCommitProject(
      {
        ...project,
        floors: remainingFloors,
        activeFloorId: remainingFloors[0].id,
        rooms: project.rooms.filter((r) => r.floorId !== targetId),
        items: project.items.filter((i) => i.floorId !== targetId),
      },
      true
    );
    onSelect(null);
  };

  const placeItemAt = (type: ItemType, p: { x: number; y: number }) => {
    const T = TYPES[type];
    let nextId = project.nextId;
    let nextItems = [...project.items];

    if (T.place === 'wall') {
      const edge = nearestEdge(floorRooms, p, 100);
      if (!edge) return;
      if (type === 'panel') {
        nextItems = nextItems.filter((i) => i.type !== 'panel');
      }
      const draft: PlanItem = {
        id: nextId++,
        floorId: project.activeFloorId,
        type,
        x: 0,
        y: 0,
        roomId: edge.room.id,
        side: edge.side,
        rot: 0,
        name: '',
        watts: T.watts,
        ...(T.len ? { len: T.len } : {}),
        ...(type === 'camera'
          ? { camPlacement: 'interior', camAngle: 0, camFov: 90, camRange: 450 }
          : {}),
      };
      const pos = wallPos(edge.room, edge.side, p, halfOf(draft));
      draft.x = pos.x;
      draft.y = pos.y;
      nextItems.push(draft);
      onCommitProject({ ...project, items: nextItems, nextId }, true);
      onSelect({ kind: 'item', id: draft.id });
    } else {
      const r = roomAt(floorRooms, p);
      if (!r) return;
      const draft: PlanItem = {
        id: nextId++,
        floorId: project.activeFloorId,
        type,
        x: clamp(snap(p.x, 5), r.x + 10, r.x + r.w - 10),
        y: clamp(snap(p.y, 5), r.y + 10, r.y + r.h - 10),
        roomId: r.id,
        side: null,
        rot: 0,
        name: type === 'staircase' ? 'Escalier LED' : '',
        watts: T.watts,
        ...(T.furn || type === 'staircase' ? { w: T.w, h: T.h } : {}),
        ...(type === 'neon' ? { len: 200, wpm: 12, watts: 0 } : {}),
        ...(type === 'spots' ? { count: 4, spacing: 80, watts: 7 } : {}),
        ...(type === 'staircase'
          ? { stepCount: 14, ledColor: 'warm', wattsPerStep: 2 }
          : {}),
      };
      nextItems.push(draft);
      onCommitProject({ ...project, items: nextItems, nextId }, true);
      onSelect({ kind: 'item', id: draft.id });
    }
  };

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    const p = svgPoint(e.clientX, e.clientY);

    if (activeTool === 'select') {
      const target = e.target as Element;
      const itemEl = target.closest('[data-item-id]');
      const roomEl = target.closest('[data-room-id]');

      if (itemEl) {
        const id = Number(itemEl.getAttribute('data-item-id'));
        const it = project.items.find((i) => i.id === id);
        if (!it) return;

        if (
          simulateLighting &&
          ['switch', 'pushbutton', 'dimmer', 'motion'].includes(it.type)
        ) {
          setLitRoomIds((prev) => {
            const next = new Set(prev);
            if (next.has(it.roomId)) next.delete(it.roomId);
            else next.add(it.roomId);
            return next;
          });
        }

        onSelect({ kind: 'item', id });
        if (!it.locked) {
          const free = TYPES[it.type].place !== 'wall';
          dragRef.current = {
            kind: 'item',
            id,
            dx: free ? it.x - p.x : 0,
            dy: free ? it.y - p.y : 0,
            snapshot: project,
            moved: false,
          };
        }
      } else if (roomEl) {
        const id = Number(roomEl.getAttribute('data-room-id'));
        onSelect({ kind: 'room', id });
        dragRef.current = {
          kind: 'room',
          id,
          sx: p.x,
          sy: p.y,
          ax: 0,
          ay: 0,
          snapshot: project,
          moved: false,
        };
      } else {
        onSelect(null);
        const base = freezeView();
        const ctm = svgRefExternal.current?.getScreenCTM();
        dragRef.current = {
          kind: 'pan',
          sx: e.clientX,
          sy: e.clientY,
          cx: base.cx,
          cy: base.cy,
          u: ctm ? 1 / ctm.a : 1,
        };
      }
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Ignore capture errors
      }
      return;
    }

    if (activeTool === 'room') {
      const sx = snap(p.x, 10);
      const sy = snap(p.y, 10);
      setDrawBox({ x0: sx, y0: sy, x1: sx, y1: sy });
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Ignore capture errors
      }
      return;
    }

    placeItemAt(activeTool, p);
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (drawBox) {
      const p = svgPoint(e.clientX, e.clientY);
      setDrawBox((prev) =>
        prev ? { ...prev, x1: snap(p.x, 10), y1: snap(p.y, 10) } : null
      );
      return;
    }

    const drag = dragRef.current;
    if (!drag) return;

    if (drag.kind === 'pan') {
      setView((prev) => ({
        auto: false,
        zoom: prev.auto ? 1 : prev.zoom,
        cx: drag.cx - (e.clientX - drag.sx) * drag.u,
        cy: drag.cy - (e.clientY - drag.sy) * drag.u,
      }));
      return;
    }

    const p = svgPoint(e.clientX, e.clientY);
    if (drag.kind === 'item') {
      const targetItem = project.items.find((i) => i.id === drag.id);
      if (!targetItem) return;
      const movedItem = moveItemToPoint(targetItem, floorRooms, {
        x: p.x + drag.dx,
        y: p.y + drag.dy,
      });
      if (
        movedItem.x !== targetItem.x ||
        movedItem.y !== targetItem.y ||
        movedItem.side !== targetItem.side ||
        movedItem.roomId !== targetItem.roomId
      ) {
        drag.moved = true;
        onCommitProject(
          {
            ...project,
            items: project.items.map((i) => (i.id === drag.id ? movedItem : i)),
          },
          false
        );
      }
    } else if (drag.kind === 'room') {
      const ax = snap(p.x - drag.sx, 10);
      const ay = snap(p.y - drag.sy, 10);
      if (ax !== drag.ax || ay !== drag.ay) {
        const dx = ax - drag.ax;
        const dy = ay - drag.ay;
        drag.ax = ax;
        drag.ay = ay;
        drag.moved = true;
        onCommitProject(
          {
            ...project,
            rooms: project.rooms.map((r) =>
              r.id === drag.id ? { ...r, x: r.x + dx, y: r.y + dy } : r
            ),
            items: project.items.map((i) =>
              i.roomId === drag.id ? { ...i, x: i.x + dx, y: i.y + dy } : i
            ),
          },
          false
        );
      }
    }
  };

  const handlePointerUp = () => {
    if (drawBox) {
      const x = Math.min(drawBox.x0, drawBox.x1);
      const y = Math.min(drawBox.y0, drawBox.y1);
      const w = Math.abs(drawBox.x1 - drawBox.x0);
      const h = Math.abs(drawBox.y1 - drawBox.y0);
      setDrawBox(null);
      if (w >= 100 && h >= 100) {
        const type: RoomType = 'autre';
        const count = floorRooms.filter((r) => r.type === type).length + 1;
        const newR: Room = {
          id: project.nextId,
          floorId: project.activeFloorId,
          x,
          y,
          w,
          h,
          type,
          name:
            count > 1 ? `${ROOM_TYPES[type].label} ${count}` : ROOM_TYPES[type].label,
        };
        onCommitProject(
          {
            ...project,
            rooms: [...project.rooms, newR],
            nextId: project.nextId + 1,
          },
          true
        );
        onSelect({ kind: 'room', id: newR.id });
        setActiveTool('select');
      }
    }

    const drag = dragRef.current;
    if (drag && (drag.kind === 'item' || drag.kind === 'room') && drag.moved) {
      onCommitProject(project, true);
    }
    dragRef.current = null;
  };

  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const p = svgPoint(e.clientX, e.clientY);
    zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15, p);
  };

  const selectedRoom =
    selected?.kind === 'room'
      ? floorRooms.find((r) => r.id === selected.id) ?? null
      : null;
  const selectedItem =
    selected?.kind === 'item'
      ? floorItems.find((i) => i.id === selected.id) ?? null
      : null;

  const updateRoomField = (room: Room, patch: Partial<Room>, fitItems = false) => {
    const updatedRoom = { ...room, ...patch };
    const dx = updatedRoom.x - room.x;
    const dy = updatedRoom.y - room.y;
    const nextItems = project.items.map((it) => {
      if (it.roomId !== room.id) return it;
      const shifted = { ...it, x: it.x + dx, y: it.y + dy };
      return fitItems ? fitItemInRoom(shifted, updatedRoom) : shifted;
    });
    onCommitProject(
      {
        ...project,
        rooms: project.rooms.map((r) => (r.id === room.id ? updatedRoom : r)),
        items: nextItems,
      },
      true
    );
  };

  const deleteRoom = (roomId: number) => {
    onCommitProject(
      {
        ...project,
        rooms: project.rooms.filter((r) => r.id !== roomId),
        items: project.items.filter((i) => i.roomId !== roomId),
      },
      true
    );
    onSelect(null);
  };

  const updateItemField = (it: PlanItem, patch: Partial<PlanItem>, refit = false) => {
    let updated: PlanItem = { ...it, ...patch };
    if (refit) {
      const room = project.rooms.find((r) => r.id === updated.roomId);
      updated = fitItemInRoom(updated, room);
    }
    onCommitProject(
      {
        ...project,
        items: project.items.map((i) => (i.id === it.id ? updated : i)),
      },
      true
    );
  };

  const duplicateItem = (it: PlanItem) => {
    if (it.type === 'panel') return;
    const room = project.rooms.find((r) => r.id === it.roomId);
    const copy = fitItemInRoom(
      {
        ...it,
        id: project.nextId,
        x: it.x + 30,
        y: it.y + 30,
      },
      room
    );
    onCommitProject(
      {
        ...project,
        items: [...project.items, copy],
        nextId: project.nextId + 1,
      },
      true
    );
    onSelect({ kind: 'item', id: copy.id });
  };

  const deleteItem = (itemId: number) => {
    onCommitProject(
      {
        ...project,
        items: project.items.filter((i) => i.id !== itemId),
      },
      true
    );
    onSelect(null);
  };

  const currentTabTools = TOOL_TABS.find((t) => t.id === activeTab)?.tools ?? [];

  const getRoomFloorPattern = (rt: RoomType) => {
    if (rt === 'terrasse') return 'url(#pe-deck)';
    if (rt === 'cuisine' || rt === 'sdb' || rt === 'wc') return 'url(#pe-tile)';
    if (rt === 'garage') return 'url(#pe-grid)';
    return 'url(#pe-parquet)';
  };

  return (
    <div className="space-y-3">
      {/* Multi-Story Floor Switcher & Architectural Finish Selector */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="mr-1 inline-flex items-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400">
            <Layers className="h-3.5 w-3.5" />
            <span>Niveaux :</span>
          </span>
          {sortedFloors.map((fl) => {
            const active = fl.id === project.activeFloorId;
            const count = project.rooms.filter((r) => r.floorId === fl.id).length;
            return (
              <button
                key={fl.id}
                type="button"
                onClick={() => {
                  onCommitProject({ ...project, activeFloorId: fl.id }, false);
                  onSelect(null);
                  setView({ auto: true, cx: 0, cy: 0, zoom: 1 });
                }}
                className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium transition-colors ${
                  active
                    ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                }`}
              >
                <span>{fl.name}</span>
                <span className="font-mono text-[10px] opacity-75">({count})</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={handleAddFloor}
            className="inline-flex items-center gap-1 rounded-md border border-dashed border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-600 hover:border-slate-400 hover:text-slate-950 dark:border-slate-700 dark:text-slate-300 dark:hover:text-white"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Ajouter niveau</span>
          </button>
          {project.floors.length > 1 && (
            <button
              type="button"
              onClick={handleDeleteActiveFloor}
              title="Supprimer le niveau actif"
              className="inline-flex items-center gap-1 rounded-md border border-red-200 px-2 py-1 text-[11px] font-medium text-red-700 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400 dark:hover:bg-red-950/30"
            >
              <Trash2 className="h-3 w-3" />
            </button>
          )}
        </div>

        <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
          <span>Style :</span>
          <select
            value={project.finishStyle}
            onChange={(e) =>
              onCommitProject(
                { ...project, finishStyle: e.target.value as FinishStyle },
                true
              )
            }
            className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-xs font-medium text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
          >
            {(Object.keys(FINISH_STYLES) as FinishStyle[]).map((st) => (
              <option key={st} value={st}>
                {FINISH_STYLES[st].label}
              </option>
            ))}
          </select>
        </label>
      </div>

      {/* Tool Category Tabs & Layer Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div role="tablist" aria-label="Catégories d'outils" className="flex flex-wrap gap-1.5">
          {TOOL_TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                activeTab === tab.id
                  ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={showCables}
              onChange={(e) => onToggleCables(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Câbles</span>
          </label>
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={showFurn}
              onChange={(e) => onToggleFurn(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Mobilier</span>
          </label>
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={showNames}
              onChange={(e) => onToggleNames(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Noms</span>
          </label>
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={showDimensions}
              onChange={(e) => onToggleDimensions(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Cotes</span>
          </label>
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={showSafetyZones}
              onChange={(e) => onToggleSafetyZones(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Zones SDB 60 cm</span>
          </label>
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={showCameraFov}
              onChange={(e) => setShowCameraFov(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Champs caméras</span>
          </label>
          <button
            type="button"
            onClick={() => onToggleSimulateLighting(!simulateLighting)}
            className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              simulateLighting
                ? 'border-amber-500 bg-amber-50 text-amber-800 dark:border-amber-500/60 dark:bg-amber-950/50 dark:text-amber-300'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300'
            }`}
          >
            <Lightbulb className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{simulateLighting ? 'Simulation allumée' : 'Tester éclairage'}</span>
          </button>
        </div>
      </div>

      {/* Tool Palette */}
      <div
        role="toolbar"
        aria-label="Outils de dessin"
        className="flex flex-wrap gap-1.5 rounded-xl border border-slate-200 bg-white p-2 dark:border-slate-800 dark:bg-slate-900"
      >
        <button
          type="button"
          onClick={() => {
            setActiveTool('select');
            setDrawBox(null);
          }}
          aria-pressed={activeTool === 'select'}
          className={`flex w-[74px] flex-col items-center justify-center gap-1 rounded-lg border px-1.5 py-2 text-[11px] font-medium leading-tight transition-colors ${
            activeTool === 'select'
              ? 'border-blue-600 bg-blue-50/70 text-blue-900 dark:border-sky-400 dark:bg-sky-950/40 dark:text-sky-200'
              : 'border-transparent text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
          }`}
        >
          <MousePointer className="h-4 w-4" aria-hidden="true" />
          <span>Sélection</span>
        </button>

        {activeTab === 'pieces' && (
          <button
            type="button"
            onClick={() => {
              setActiveTool('room');
              onSelect(null);
            }}
            aria-pressed={activeTool === 'room'}
            className={`flex w-[74px] flex-col items-center justify-center gap-1 rounded-lg border px-1.5 py-2 text-[11px] font-medium leading-tight transition-colors ${
              activeTool === 'room'
                ? 'border-blue-600 bg-blue-50/70 text-blue-900 dark:border-sky-400 dark:bg-sky-950/40 dark:text-sky-200'
                : 'border-transparent text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
            }`}
          >
            <Square className="h-4 w-4" aria-hidden="true" />
            <span>Pièce</span>
          </button>
        )}

        {currentTabTools.map((toolKey) => {
          const T = TYPES[toolKey];
          const isPressed = activeTool === toolKey;
          return (
            <button
              key={toolKey}
              type="button"
              onClick={() => {
                setActiveTool(toolKey);
                onSelect(null);
                setDrawBox(null);
              }}
              aria-pressed={isPressed}
              className={`flex w-[74px] flex-col items-center justify-center gap-1 rounded-lg border px-1 py-1.5 text-[11px] font-medium leading-tight transition-colors ${
                isPressed
                  ? 'border-blue-600 bg-blue-50/70 text-blue-900 dark:border-sky-400 dark:bg-sky-950/40 dark:text-sky-200'
                  : 'border-transparent text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              <svg viewBox="-40 -26 80 52" width="44" height="28" aria-hidden="true">
                {T.furn ? (
                  <g transform={`scale(${36 / Math.max(T.w ?? 80, T.h ?? 80)})`}>
                    <SvgFurniture
                      item={{ type: toolKey, w: T.w, h: T.h }}
                      strokeWidth={2.2 / (36 / Math.max(T.w ?? 80, T.h ?? 80))}
                    />
                  </g>
                ) : (
                  <g transform={TOOLBAR_ICON_TRANSFORMS[toolKey] || ''}>
                    <SvgSymbol
                      item={{
                        type: toolKey,
                        len: toolKey === 'neon' ? 64 : T.len,
                        count: 3,
                        spacing: 28,
                        w: T.w,
                        h: T.h,
                        stepCount: 8,
                      }}
                      finishStyle={project.finishStyle}
                      showCameraFov={false}
                    />
                  </g>
                )}
              </svg>
              <span className="truncate max-w-full">{T.short}</span>
            </button>
          );
        })}
      </div>

      {/* Sequential Luminous Staircase Simulator Bar */}
      {(floorStaircases.length > 0 || allStaircases.length > 0) && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50/60 px-3.5 py-2 text-xs dark:border-amber-900/50 dark:bg-amber-950/30">
          <div className="flex items-center gap-2 font-medium text-amber-950 dark:text-amber-200">
            <Footprints className="h-4 w-4 text-amber-600" />
            <span>Escalier lumineux progressif :</span>
            <strong className="font-mono tabular-nums">
              {activeStairStep === null || activeStairStep === 0
                ? 'Éteint'
                : `Marche ${activeStairStep} / ${maxStairSteps}`}
            </strong>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="range"
              min={0}
              max={maxStairSteps}
              value={activeStairStep ?? 0}
              onChange={(e) => {
                const v = Number(e.target.value);
                onSetStairWalkMode(null);
                onChangeStairStep(v === 0 ? null : v);
              }}
              aria-label="Position sur l'escalier"
              className="w-32 accent-amber-600"
            />
            <button
              type="button"
              onClick={() =>
                onSetStairWalkMode(stairWalkMode === 'up' ? null : 'up')
              }
              className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1 text-[11px] font-medium ${
                stairWalkMode === 'up'
                  ? 'border-amber-600 bg-amber-600 text-white'
                  : 'border-amber-300 bg-white text-amber-900 hover:bg-amber-100 dark:border-amber-800 dark:bg-slate-900 dark:text-amber-200'
              }`}
            >
              {stairWalkMode === 'up' ? (
                <Pause className="h-3 w-3" />
              ) : (
                <Play className="h-3 w-3" />
              )}
              <span>Monter</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onSetStairWalkMode(stairWalkMode === 'down' ? null : 'down')
              }
              className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1 text-[11px] font-medium ${
                stairWalkMode === 'down'
                  ? 'border-amber-600 bg-amber-600 text-white'
                  : 'border-amber-300 bg-white text-amber-900 hover:bg-amber-100 dark:border-amber-800 dark:bg-slate-900 dark:text-amber-200'
              }`}
            >
              {stairWalkMode === 'down' ? (
                <Pause className="h-3 w-3" />
              ) : (
                <Play className="h-3 w-3" />
              )}
              <span>Descendre</span>
            </button>
            {activeStairStep !== null && (
              <button
                type="button"
                onClick={() => {
                  onSetStairWalkMode(null);
                  onChangeStairStep(null);
                }}
                className="rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
              >
                Éteindre
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main SVG Interactive Canvas */}
      <div className="relative overflow-hidden rounded-xl border border-slate-200 bg-[var(--pe-paper)] dark:border-slate-800">
        <svg
          ref={svgRefExternal}
          viewBox={viewBoxStr}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onWheel={handleWheel}
          role="img"
          aria-label="Plan électrique interactif 2D"
          className={`block h-[clamp(360px,62vh,680px)] w-full touch-none select-none ${
            activeTool !== 'select' ? 'cursor-crosshair' : 'cursor-default'
          }`}
        >
          <defs>
            <pattern id="pe-grid" width="50" height="50" patternUnits="userSpaceOnUse">
              <path d="M50 0H0V50" fill="none" stroke="var(--pe-grid)" strokeWidth="1" />
            </pattern>
            <pattern id="pe-parquet" width="80" height="24" patternUnits="userSpaceOnUse">
              <path
                d="M0 0H80 M0 12H80 M40 0V12 M0 12V24"
                fill="none"
                stroke="var(--pe-grid)"
                strokeWidth="0.9"
                opacity="0.7"
              />
            </pattern>
            <pattern id="pe-tile" width="35" height="35" patternUnits="userSpaceOnUse">
              <path
                d="M35 0H0V35"
                fill="none"
                stroke="var(--pe-grid)"
                strokeWidth="1.05"
                opacity="0.85"
              />
            </pattern>
            <pattern id="pe-deck" width="22" height="60" patternUnits="userSpaceOnUse">
              <path
                d="M0 0V60 M0 30H22"
                fill="none"
                stroke="var(--pe-grid)"
                strokeWidth="1"
                opacity="0.8"
              />
            </pattern>
            <pattern
              id="pe-hatch"
              width="12"
              height="12"
              patternUnits="userSpaceOnUse"
              patternTransform="rotate(45)"
            >
              <line
                x1="0"
                y1="0"
                x2="0"
                y2="12"
                stroke="#0284c7"
                strokeWidth="1.5"
                strokeOpacity="0.28"
              />
            </pattern>
          </defs>

          {/* Room floors */}
          {floorRooms.map((r) => (
            <g key={`floor-${r.id}`}>
              <rect
                data-room-id={r.id}
                x={r.x}
                y={r.y}
                width={r.w}
                height={r.h}
                fill={r.type === 'terrasse' ? 'var(--pe-terrace)' : 'var(--pe-floor)'}
                className={activeTool === 'select' ? 'cursor-grab' : 'pointer-events-none'}
              />
              <rect
                x={r.x}
                y={r.y}
                width={r.w}
                height={r.h}
                fill={getRoomFloorPattern(r.type)}
                pointerEvents="none"
              />
            </g>
          ))}

          {/* Bathroom 60 cm Volume 2 safety zones */}
          {showSafetyZones &&
            floorItems
              .filter((i) => i.type === 'bath' || i.type === 'shower')
              .map((fix) => {
                const fW = (fix.rot % 180 === 0 ? fix.w : fix.h) ?? 90;
                const fH = (fix.rot % 180 === 0 ? fix.h : fix.w) ?? 90;
                return (
                  <g key={`zone-${fix.id}`} pointerEvents="none">
                    <rect
                      x={fix.x - fW / 2 - 60}
                      y={fix.y - fH / 2 - 60}
                      width={fW + 120}
                      height={fH + 120}
                      rx="18"
                      fill="url(#pe-hatch)"
                      stroke="#0284c7"
                      strokeWidth="1.5"
                      strokeDasharray="6 4"
                      opacity="0.85"
                    />
                    <text
                      x={fix.x}
                      y={fix.y - fH / 2 - 66}
                      textAnchor="middle"
                      fontSize="11"
                      fontWeight="600"
                      fill="#0284c7"
                    >
                      Vol. 2 (60 cm)
                    </text>
                  </g>
                );
              })}

          {/* Furniture layer */}
          {showFurn &&
            floorItems
              .filter((i) => TYPES[i.type].furn)
              .map((it) => {
                const T = TYPES[it.type];
                const bd = getItemBounds(it);
                const isSel = selected?.kind === 'item' && selected.id === it.id;
                return (
                  <g
                    key={it.id}
                    data-item-id={it.id}
                    transform={`translate(${it.x} ${it.y}) rotate(${it.rot || 0})`}
                    className={activeTool === 'select' ? 'cursor-grab' : 'pointer-events-none'}
                  >
                    <title>{T.label}</title>
                    {bd.r && (
                      <rect
                        x={bd.r[0]}
                        y={bd.r[1]}
                        width={bd.r[2]}
                        height={bd.r[3]}
                        rx="8"
                        fill="transparent"
                      />
                    )}
                    {isSel && bd.r && (
                      <rect
                        x={bd.r[0]}
                        y={bd.r[1]}
                        width={bd.r[2]}
                        height={bd.r[3]}
                        rx="8"
                        fill="none"
                        stroke="var(--pe-accent)"
                        strokeWidth="2.5"
                        strokeDasharray="6 5"
                      />
                    )}
                    <SvgFurniture item={it} />
                  </g>
                );
              })}

          {/* Room walls */}
          {floorRooms.map((r) =>
            r.type === 'terrasse' ? (
              <rect
                key={`wall-${r.id}`}
                x={r.x}
                y={r.y}
                width={r.w}
                height={r.h}
                fill="none"
                stroke="var(--pe-muted)"
                strokeWidth="6"
                strokeDasharray="14 8"
                pointerEvents="none"
              />
            ) : (
              <rect
                key={`wall-${r.id}`}
                x={r.x}
                y={r.y}
                width={r.w}
                height={r.h}
                fill="none"
                stroke="var(--pe-wall)"
                strokeWidth="16"
                pointerEvents="none"
              />
            )
          )}

          {/* Room labels & dimensions */}
          {showNames &&
            floorRooms.map((r) => (
              <g key={`label-${r.id}`} pointerEvents="none">
                <text
                  x={r.x + 16}
                  y={r.y + 30}
                  fontSize="19"
                  fontWeight="600"
                  fill="var(--pe-muted)"
                >
                  {r.name}
                </text>
                <text
                  x={r.x + 16}
                  y={r.y + 48}
                  fontSize="13"
                  fill="var(--pe-muted)"
                  opacity="0.85"
                >
                  {frNum((r.w * r.h) / 10000, 1)} m²
                </text>
              </g>
            ))}

          {showDimensions &&
            floorRooms.map((r) => (
              <g key={`dim-${r.id}`} pointerEvents="none" opacity="0.78">
                <text
                  x={r.x + r.w / 2}
                  y={r.y + 20}
                  textAnchor="middle"
                  fontSize="11"
                  fontFamily="JetBrains Mono, monospace"
                  fill="var(--pe-muted)"
                >
                  {frNum(r.w / 100, 2)} m
                </text>
                <text
                  x={r.x + 20}
                  y={r.y + r.h / 2}
                  textAnchor="middle"
                  fontSize="11"
                  fontFamily="JetBrains Mono, monospace"
                  fill="var(--pe-muted)"
                  transform={`rotate(-90 ${r.x + 20} ${r.y + r.h / 2})`}
                >
                  {frNum(r.h / 100, 2)} m
                </text>
              </g>
            ))}

          {/* Orthogonal Cable Routing on Active Floor */}
          {showCables && (
            <g pointerEvents="none">
              {sim.circuits.map((c, ci) => {
                const floorNodes = c.chain.filter(
                  (pt) => (pt.floorId ?? 0) === project.activeFloorId
                );
                if (floorNodes.length === 0) return null;

                const isDimmed =
                  (highlightedCircuitId && highlightedCircuitId !== c.id) ||
                  trippedCircuitIds.has(c.id);
                const isLightCircuit =
                  c.kind === 'light' ||
                  c.kind === 'spot' ||
                  c.kind === 'neon' ||
                  c.kind === 'stair_led';

                let d = '';
                for (let i = 1; i < c.chain.length; i++) {
                  const a = c.chain[i - 1];
                  const bb = c.chain[i];
                  if (
                    (a.floorId ?? 0) === project.activeFloorId &&
                    (bb.floorId ?? 0) === project.activeFloorId
                  ) {
                    d += `M${a.x} ${a.y}`;
                    d +=
                      ci % 2 === 0
                        ? ` L${bb.x} ${a.y} L${bb.x} ${bb.y}`
                        : ` L${a.x} ${bb.y} L${bb.x} ${bb.y}`;
                  }
                }
                // Connect local floor nodes if first segment jumped from another floor
                if (!d && floorNodes.length >= 2) {
                  d = `M${floorNodes[0].x} ${floorNodes[0].y}`;
                  for (let i = 1; i < floorNodes.length; i++) {
                    const a = floorNodes[i - 1];
                    const bb = floorNodes[i];
                    d +=
                      ci % 2 === 0
                        ? ` L${bb.x} ${a.y} L${bb.x} ${bb.y}`
                        : ` L${a.x} ${bb.y} L${bb.x} ${bb.y}`;
                  }
                }

                return (
                  <g key={c.id} opacity={isDimmed ? 0.2 : 0.88}>
                    {d && (
                      <path
                        d={d}
                        fill="none"
                        stroke={c.color}
                        strokeWidth={highlightedCircuitId === c.id ? 5 : 3.5}
                        strokeLinejoin="round"
                        strokeDasharray={isLightCircuit ? '10 6' : undefined}
                      />
                    )}
                    {c.chain[0].floorId !== project.activeFloorId && (
                      <circle
                        cx={floorNodes[0].x}
                        cy={floorNodes[0].y}
                        r={8}
                        fill="none"
                        stroke={c.color}
                        strokeWidth={2.5}
                        strokeDasharray="3 2"
                      />
                    )}
                  </g>
                );
              })}

              {showFurn &&
                sim.applianceLinks
                  .filter(
                    ({ appliance }) =>
                      (appliance.floorId ?? 0) === project.activeFloorId
                  )
                  .map(({ appliance, socket }) => (
                    <path
                      key={`link-${appliance.id}`}
                      d={`M${appliance.x} ${appliance.y}L${socket.x} ${socket.y}`}
                      stroke="var(--pe-muted)"
                      strokeWidth="2"
                      strokeDasharray="3 5"
                    />
                  ))}
            </g>
          )}

          {/* Electrical items (including Staircases) */}
          {floorItems
            .filter((i) => !TYPES[i.type].furn && !TYPES[i.type].struct)
            .map((it) => {
              const T = TYPES[it.type];
              const ang = it.side ? WALL_ANGLES[it.side] : it.rot || 0;
              const bd = getItemBounds(it);
              const isSel = selected?.kind === 'item' && selected.id === it.id;
              const cId = sim.itemCircuitId[it.id];
              const isTripped = cId ? trippedCircuitIds.has(cId) : false;
              const isLightItem = ['light', 'sconce', 'spots', 'neon'].includes(it.type);
              const isLit =
                isLightItem &&
                !isTripped &&
                (simulateLighting || litRoomIds.has(it.roomId));
              const wallOff = Boolean(it.side && !T.struct);
              const itemOpacity =
                highlightedCircuitId && cId && highlightedCircuitId !== cId ? 0.3 : 1;

              return (
                <g
                  key={it.id}
                  data-item-id={it.id}
                  transform={`translate(${it.x} ${it.y}) rotate(${ang})`}
                  opacity={isTripped ? 0.45 : itemOpacity}
                  className={activeTool === 'select' ? 'cursor-grab' : 'pointer-events-none'}
                >
                  <title>
                    {T.label}
                    {it.name ? ` : ${it.name}` : ''}
                    {T.power ? ` · ${frNum(wattsOf(it))} W` : ''}
                  </title>
                  <g transform={wallOff ? 'translate(0 8)' : undefined}>
                    {bd.c ? (
                      <circle cx={bd.c[0]} cy={bd.c[1]} r={bd.c[2]} fill="transparent" />
                    ) : bd.r ? (
                      <rect
                        x={bd.r[0]}
                        y={bd.r[1]}
                        width={bd.r[2]}
                        height={bd.r[3]}
                        rx="8"
                        fill="transparent"
                      />
                    ) : null}
                    {isSel &&
                      (bd.c ? (
                        <circle
                          cx={bd.c[0]}
                          cy={bd.c[1]}
                          r={bd.c[2]}
                          fill="none"
                          stroke="var(--pe-accent)"
                          strokeWidth="2.5"
                          strokeDasharray="6 5"
                        />
                      ) : bd.r ? (
                        <rect
                          x={bd.r[0]}
                          y={bd.r[1]}
                          width={bd.r[2]}
                          height={bd.r[3]}
                          rx="8"
                          fill="none"
                          stroke="var(--pe-accent)"
                          strokeWidth="2.5"
                          strokeDasharray="6 5"
                        />
                      ) : null)}
                    <SvgSymbol
                      item={it}
                      color={sim.itemCircuitColor[it.id]}
                      isLit={isLit || (it.type === 'staircase' && simulateLighting)}
                      finishStyle={project.finishStyle}
                      activeStairStep={isTripped ? null : activeStairStep}
                      showCameraFov={showCameraFov}
                    />
                  </g>
                </g>
              );
            })}

          {/* Structural openings (doors/windows) */}
          {floorItems
            .filter((i) => TYPES[i.type].struct)
            .map((it) => {
              const ang = it.side ? WALL_ANGLES[it.side] : it.rot || 0;
              const bd = getItemBounds(it);
              const isSel = selected?.kind === 'item' && selected.id === it.id;
              return (
                <g
                  key={it.id}
                  data-item-id={it.id}
                  transform={`translate(${it.x} ${it.y}) rotate(${ang})`}
                  className={activeTool === 'select' ? 'cursor-grab' : 'pointer-events-none'}
                >
                  {bd.c && (
                    <circle cx={bd.c[0]} cy={bd.c[1]} r={bd.c[2]} fill="transparent" />
                  )}
                  {isSel && bd.c && (
                    <circle
                      cx={bd.c[0]}
                      cy={bd.c[1]}
                      r={bd.c[2]}
                      fill="none"
                      stroke="var(--pe-accent)"
                      strokeWidth="2.5"
                      strokeDasharray="6 5"
                    />
                  )}
                  <SvgSymbol item={it} finishStyle={project.finishStyle} />
                </g>
              );
            })}

          {/* Item custom labels */}
          {showNames &&
            floorItems.map((it) => {
              const T = TYPES[it.type];
              if (T.furn && !showFurn) return null;
              const label = T.furn ? it.name || T.short : it.name;
              if (!label) return null;
              let tx = it.x;
              let ty = it.y;
              if (!T.furn) {
                const bd = getItemBounds(it);
                const ext = bd.c ? bd.c[1] + bd.c[2] : bd.r ? bd.r[1] + bd.r[3] : 20;
                const vec = it.side
                  ? { top: [0, 1], right: [-1, 0], bottom: [0, -1], left: [1, 0] }[it.side]
                  : [0, 1];
                const dist = (it.side ? ext + 8 : Math.max(ext, 20)) + 12;
                tx += vec[0] * dist;
                ty += vec[1] * dist;
              }
              return (
                <text
                  key={`name-${it.id}`}
                  x={tx}
                  y={ty + 4}
                  textAnchor="middle"
                  fontSize="12"
                  fill="var(--pe-ink)"
                  stroke="var(--pe-floor)"
                  strokeWidth="3.5"
                  paintOrder="stroke"
                  pointerEvents="none"
                >
                  {label}
                </text>
              );
            })}

          {/* Selected room outline */}
          {selectedRoom && (
            <rect
              x={selectedRoom.x}
              y={selectedRoom.y}
              width={selectedRoom.w}
              height={selectedRoom.h}
              fill="none"
              stroke="var(--pe-accent)"
              strokeWidth="4"
              strokeDasharray="14 8"
              pointerEvents="none"
            />
          )}

          {/* Room drawing rubberband */}
          {drawBox && (
            <g pointerEvents="none">
              <rect
                x={Math.min(drawBox.x0, drawBox.x1)}
                y={Math.min(drawBox.y0, drawBox.y1)}
                width={Math.abs(drawBox.x1 - drawBox.x0)}
                height={Math.abs(drawBox.y1 - drawBox.y0)}
                fill="var(--pe-accent)"
                fillOpacity="0.12"
                stroke="var(--pe-accent)"
                strokeWidth="3"
                strokeDasharray="8 6"
              />
              <text
                x={(drawBox.x0 + drawBox.x1) / 2}
                y={(drawBox.y0 + drawBox.y1) / 2}
                textAnchor="middle"
                fontSize="18"
                fontWeight="600"
                fill="var(--pe-accent)"
              >
                {frNum(Math.abs(drawBox.x1 - drawBox.x0) / 100, 1)} ×{' '}
                {frNum(Math.abs(drawBox.y1 - drawBox.y0) / 100, 1)} m
              </text>
            </g>
          )}

          {floorRooms.length === 0 && !drawBox && (
            <text
              x="250"
              y="200"
              textAnchor="middle"
              fontSize="20"
              fill="var(--pe-muted)"
            >
              Choisissez « Pièce » puis faites glisser sur le plan pour dessiner ce niveau.
            </text>
          )}
        </svg>

        {/* Zoom Controls */}
        <div className="absolute top-3 right-3 flex flex-col gap-1.5">
          <button
            type="button"
            onClick={() => zoomBy(1.25)}
            aria-label="Zoom avant"
            title="Zoom avant"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <Plus className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => zoomBy(1 / 1.25)}
            aria-label="Zoom arrière"
            title="Zoom arrière"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <Minus className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setView({ auto: true, cx: 0, cy: 0, zoom: 1 })}
            aria-label="Recentrer le plan"
            title="Recentrer le plan"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Inline Selection Inspector */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        {selectedRoom ? (
          <div className="flex flex-wrap items-end gap-3">
            <div className="w-full flex items-center justify-between border-b border-slate-100 pb-2 dark:border-slate-800">
              <span className="font-display text-sm font-semibold text-slate-900 dark:text-white">
                Pièce · {frNum((selectedRoom.w * selectedRoom.h) / 10000, 1)} m²
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => deleteRoom(selectedRoom.id)}
                  className="inline-flex items-center gap-1 rounded-md border border-red-200 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-900/60 dark:text-red-400 dark:hover:bg-red-950/40"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>Supprimer</span>
                </button>
                <button
                  type="button"
                  onClick={() => onSelect(null)}
                  className="rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  Terminé
                </button>
              </div>
            </div>

            <label className="flex min-w-[140px] flex-1 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Nom</span>
              <input
                type="text"
                maxLength={30}
                value={selectedRoom.name}
                onChange={(e) => updateRoomField(selectedRoom, { name: e.target.value })}
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </label>

            <label className="flex min-w-[140px] flex-1 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Type</span>
              <select
                value={selectedRoom.type}
                onChange={(e) =>
                  updateRoomField(selectedRoom, { type: e.target.value as RoomType })
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                {(Object.keys(ROOM_TYPES) as RoomType[]).map((rt) => (
                  <option key={rt} value={rt}>
                    {ROOM_TYPES[rt].label}
                  </option>
                ))}
              </select>
            </label>

            <label className="flex w-24 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
              <span>X (m)</span>
              <input
                type="number"
                step={0.1}
                value={selectedRoom.x / 100}
                onChange={(e) =>
                  updateRoomField(
                    selectedRoom,
                    { x: snap((parseFloat(e.target.value) || 0) * 100, 10) },
                    true
                  )
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </label>

            <label className="flex w-24 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Y (m)</span>
              <input
                type="number"
                step={0.1}
                value={selectedRoom.y / 100}
                onChange={(e) =>
                  updateRoomField(
                    selectedRoom,
                    { y: snap((parseFloat(e.target.value) || 0) * 100, 10) },
                    true
                  )
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </label>

            <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Largeur (m)</span>
              <input
                type="number"
                min={1}
                max={40}
                step={0.1}
                value={selectedRoom.w / 100}
                onChange={(e) =>
                  updateRoomField(
                    selectedRoom,
                    {
                      w: clamp(
                        snap((parseFloat(e.target.value) || 1) * 100, 10),
                        100,
                        4000
                      ),
                    },
                    true
                  )
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </label>

            <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Longueur (m)</span>
              <input
                type="number"
                min={1}
                max={40}
                step={0.1}
                value={selectedRoom.h / 100}
                onChange={(e) =>
                  updateRoomField(
                    selectedRoom,
                    {
                      h: clamp(
                        snap((parseFloat(e.target.value) || 1) * 100, 10),
                        100,
                        4000
                      ),
                    },
                    true
                  )
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </label>

            <div className="w-full border-t border-slate-100 pt-2.5 dark:border-slate-800">
              <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Habillage Murs (Peinture & Carrelage) · Sols
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  {WALL_FINISHES.map((wf) => {
                    const active = (selectedRoom.wallFinish ?? 'peinture_blanche') === wf.id;
                    return (
                      <button
                        key={wf.id}
                        type="button"
                        onClick={() =>
                          updateRoomField(
                            selectedRoom,
                            { wallFinish: wf.id as WallFinishId },
                            true
                          )
                        }
                        title={wf.label}
                        className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-[11px] font-medium ${
                          active
                            ? 'border-blue-600 bg-blue-50 text-blue-900 dark:border-sky-400 dark:bg-sky-950/60 dark:text-sky-200'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                        }`}
                      >
                        <span
                          className="h-3.5 w-3.5 rounded-sm border border-slate-300 dark:border-slate-600"
                          style={{
                            backgroundColor: wf.hex,
                            backgroundImage: wf.groutHex
                              ? `linear-gradient(to right, ${wf.groutHex} 1px, transparent 1px), linear-gradient(to bottom, ${wf.groutHex} 1px, transparent 1px)`
                              : undefined,
                            backgroundSize: wf.groutHex ? '5px 5px' : undefined,
                          }}
                        />
                        <span>{wf.label.replace(/^(Peinture|Carrelage|Parement)\s+/i, '')}</span>
                      </button>
                    );
                  })}
                </div>

                <label className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                  <span>Sol :</span>
                  <select
                    value={selectedRoom.floorFinish ?? 'auto'}
                    onChange={(e) =>
                      updateRoomField(
                        selectedRoom,
                        { floorFinish: e.target.value as FloorFinishId },
                        true
                      )
                    }
                    className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                  >
                    {FLOOR_FINISHES.map((ff) => (
                      <option key={ff.id} value={ff.id}>
                        {ff.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            </div>
          </div>
        ) : selectedItem ? (
          (() => {
            const T = TYPES[selectedItem.type];
            const room = project.rooms.find((r) => r.id === selectedItem.roomId);
            const canRotate =
              selectedItem.type === 'spots' ||
              selectedItem.type === 'neon' ||
              selectedItem.type === 'staircase' ||
              Boolean(T.furn);
            const presetIdx =
              selectedItem.type === 'spec'
                ? Math.max(
                    0,
                    APPLIANCE_PRESETS.findIndex(
                      (p) => p[0] && p[0] === selectedItem.name
                    )
                  )
                : 0;

            return (
              <div className="flex flex-wrap items-end gap-3">
                <div className="w-full flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 dark:border-slate-800">
                  <span className="font-display text-sm font-semibold text-slate-900 dark:text-white">
                    {T.label}
                    {room ? ` · ${room.name}` : ''}
                    {(T.power || T.appl) && (
                      <span className="ml-2 font-mono text-xs font-normal text-slate-500 dark:text-slate-400">
                        {frNum(wattsOf(selectedItem))} W
                      </span>
                    )}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        updateItemField(selectedItem, {
                          locked: !selectedItem.locked,
                        })
                      }
                      className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1 text-xs font-medium ${
                        selectedItem.locked
                          ? 'border-amber-500 bg-amber-500 text-white hover:bg-amber-600'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800'
                      }`}
                    >
                      {selectedItem.locked ? (
                        <>
                          <Unlock className="h-3.5 w-3.5" />
                          <span>Déverrouiller</span>
                        </>
                      ) : (
                        <>
                          <Lock className="h-3.5 w-3.5" />
                          <span>Verrouiller</span>
                        </>
                      )}
                    </button>
                    {canRotate && !selectedItem.locked && (
                      <button
                        type="button"
                        onClick={() =>
                          updateItemField(selectedItem, {
                            rot: ((selectedItem.rot || 0) + 90) % 360,
                          })
                        }
                        className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <RotateCw className="h-3.5 w-3.5" />
                        <span>Pivoter</span>
                      </button>
                    )}
                    {selectedItem.type !== 'panel' && (
                      <button
                        type="button"
                        onClick={() => duplicateItem(selectedItem)}
                        className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <Copy className="h-3.5 w-3.5" />
                        <span>Dupliquer</span>
                      </button>
                    )}
                    {!selectedItem.locked && (
                      <button
                        type="button"
                        onClick={() => deleteItem(selectedItem.id)}
                        className="inline-flex items-center gap-1 rounded-md border border-red-200 px-2.5 py-1 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-900/60 dark:text-red-400 dark:hover:bg-red-950/40"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Supprimer</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onSelect(null)}
                      className="rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                    >
                      Terminé
                    </button>
                  </div>
                </div>

                {selectedItem.type === 'spec' && (
                  <label className="flex min-w-[160px] flex-1 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                    <span>Appareil prédéfini</span>
                    <select
                      value={presetIdx}
                      onChange={(e) => {
                        const preset = APPLIANCE_PRESETS[Number(e.target.value)];
                        if (preset) {
                          updateItemField(selectedItem, {
                            name: preset[0],
                            watts: preset[2],
                          });
                        }
                      }}
                      className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                    >
                      {APPLIANCE_PRESETS.map((p, idx) => (
                        <option key={p[1]} value={idx}>
                          {p[1]}
                        </option>
                      ))}
                    </select>
                  </label>
                )}

                {((T.power &&
                  !['neon', 'spots', 'staircase'].includes(selectedItem.type)) ||
                  T.appl) && (
                  <label className="flex w-32 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                    <span>Puissance (W)</span>
                    <input
                      type="number"
                      min={0}
                      max={20000}
                      step={50}
                      value={selectedItem.watts}
                      onChange={(e) =>
                        updateItemField(selectedItem, {
                          watts: clamp(parseFloat(e.target.value) || 0, 0, 20000),
                        })
                      }
                      className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                    />
                  </label>
                )}

                {selectedItem.type === 'staircase' && (
                  <>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Nb marches</span>
                      <input
                        type="number"
                        min={6}
                        max={24}
                        value={selectedItem.stepCount ?? 14}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            stepCount: clamp(
                              parseInt(e.target.value, 10) || 14,
                              6,
                              24
                            ),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>W / marche</span>
                      <input
                        type="number"
                        min={1}
                        max={12}
                        value={selectedItem.wattsPerStep ?? 2}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            wattsPerStep: clamp(
                              parseInt(e.target.value, 10) || 2,
                              1,
                              12
                            ),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                    <label className="flex w-36 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Couleur LED</span>
                      <select
                        value={selectedItem.ledColor ?? 'warm'}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            ledColor: e.target.value as 'warm' | 'amber' | 'neutral',
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      >
                        <option value="warm">Blanc chaud 3000K</option>
                        <option value="amber">Ambre 2200K</option>
                        <option value="neutral">Blanc neutre 4000K</option>
                      </select>
                    </label>
                  </>
                )}

                {selectedItem.type === 'camera' && (
                  <>
                    <div className="flex flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Orientation caméra</span>
                      <div className="inline-flex overflow-hidden rounded-md border border-slate-200 dark:border-slate-700">
                        <button
                          type="button"
                          onClick={() =>
                            updateItemField(selectedItem, { camPlacement: 'interior' })
                          }
                          className={`px-2.5 py-1.5 text-xs font-medium ${
                            (selectedItem.camPlacement ?? 'interior') === 'interior'
                              ? 'bg-teal-600 text-white'
                              : 'bg-slate-50 text-slate-700 dark:bg-slate-950 dark:text-slate-300'
                          }`}
                        >
                          Intérieur
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            updateItemField(selectedItem, { camPlacement: 'exterior' })
                          }
                          className={`px-2.5 py-1.5 text-xs font-medium ${
                            selectedItem.camPlacement === 'exterior'
                              ? 'bg-sky-600 text-white'
                              : 'bg-slate-50 text-slate-700 dark:bg-slate-950 dark:text-slate-300'
                          }`}
                        >
                          Extérieur
                        </button>
                      </div>
                    </div>

                    <label className="flex w-36 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>
                        Direction ({selectedItem.camAngle ?? 0}°)
                      </span>
                      <input
                        type="range"
                        min={-75}
                        max={75}
                        step={5}
                        value={selectedItem.camAngle ?? 0}
                        onChange={(e) =>
                          updateItemField(
                            selectedItem,
                            { camAngle: parseInt(e.target.value, 10) },
                            false
                          )
                        }
                        className="accent-teal-600"
                      />
                    </label>

                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Champ (FOV)</span>
                      <select
                        value={selectedItem.camFov ?? 90}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            camFov: parseInt(e.target.value, 10),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      >
                        <option value={60}>60°</option>
                        <option value={90}>90°</option>
                        <option value={110}>110°</option>
                        <option value={130}>130°</option>
                      </select>
                    </label>

                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Portée (m)</span>
                      <input
                        type="number"
                        min={2}
                        max={15}
                        step={0.5}
                        value={(selectedItem.camRange ?? 450) / 100}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            camRange: clamp(
                              Math.round((parseFloat(e.target.value) || 4.5) * 100),
                              200,
                              1500
                            ),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                  </>
                )}

                {selectedItem.type === 'spots' && (
                  <>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Nb de spots</span>
                      <input
                        type="number"
                        min={1}
                        max={40}
                        value={selectedItem.count ?? 4}
                        onChange={(e) =>
                          updateItemField(
                            selectedItem,
                            { count: clamp(parseInt(e.target.value, 10) || 1, 1, 40) },
                            true
                          )
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                    <label className="flex w-32 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Espacement (cm)</span>
                      <input
                        type="number"
                        min={20}
                        max={300}
                        step={10}
                        value={selectedItem.spacing ?? 80}
                        onChange={(e) =>
                          updateItemField(
                            selectedItem,
                            {
                              spacing: clamp(
                                parseInt(e.target.value, 10) || 80,
                                20,
                                300
                              ),
                            },
                            true
                          )
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>W / spot</span>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={selectedItem.watts}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            watts: clamp(parseInt(e.target.value, 10) || 7, 1, 100),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                  </>
                )}

                {selectedItem.type === 'neon' && (
                  <>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Longueur (cm)</span>
                      <input
                        type="number"
                        min={20}
                        max={3000}
                        step={10}
                        value={selectedItem.len ?? 200}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            len: clamp(parseInt(e.target.value, 10) || 200, 20, 3000),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>W / mètre</span>
                      <input
                        type="number"
                        min={1}
                        max={60}
                        value={selectedItem.wpm ?? 12}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            wpm: clamp(parseInt(e.target.value, 10) || 12, 1, 60),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                  </>
                )}

                {(T.furn || selectedItem.type === 'staircase') && (
                  <>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Largeur (cm)</span>
                      <input
                        type="number"
                        min={20}
                        max={600}
                        step={5}
                        value={selectedItem.w ?? T.w ?? 100}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            w: clamp(parseInt(e.target.value, 10) || 100, 20, 600),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                    <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                      <span>Longueur (cm)</span>
                      <input
                        type="number"
                        min={5}
                        max={600}
                        step={5}
                        value={selectedItem.h ?? T.h ?? 220}
                        onChange={(e) =>
                          updateItemField(selectedItem, {
                            h: clamp(parseInt(e.target.value, 10) || 220, 5, 600),
                          })
                        }
                        className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                      />
                    </label>
                  </>
                )}

                {T.struct && (
                  <label className="flex w-28 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                    <span>Largeur (cm)</span>
                    <input
                      type="number"
                      min={40}
                      max={400}
                      step={10}
                      value={selectedItem.len ?? T.len ?? 90}
                      onChange={(e) =>
                        updateItemField(
                          selectedItem,
                          { len: clamp(parseInt(e.target.value, 10) || 90, 40, 400) },
                          true
                        )
                      }
                      className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-sm tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                    />
                  </label>
                )}

                {([
                  'heater',
                  'ac_split',
                  'ac_outdoor',
                  'thermostat',
                  'spec',
                  'cooktop',
                  'irve',
                  'staircase',
                  'camera',
                  'nvr_screen',
                  'alarm_panel',
                  'siren',
                  'intercom',
                  'usb_socket',
                  'pushbutton',
                ].includes(selectedItem.type) ||
                  (T.furn && T.appl) ||
                  ['socket', 'socket2'].includes(selectedItem.type)) && (
                  <label className="flex min-w-[140px] flex-1 flex-col gap-1 text-xs text-slate-500 dark:text-slate-400">
                    <span>Libellé sur le plan</span>
                    <input
                      type="text"
                      maxLength={30}
                      value={selectedItem.name}
                      placeholder={T.short}
                      onChange={(e) =>
                        updateItemField(selectedItem, { name: e.target.value })
                      }
                      className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                    />
                  </label>
                )}
              </div>
            );
          })()
        ) : (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {activeTool === 'select'
              ? 'Cliquez sur une pièce ou un équipement pour le déplacer, le dupliquer ou ajuster sa puissance. Changez d’étage en haut du plan pour modéliser un bâtiment multi-niveaux.'
              : activeTool === 'room'
              ? 'Faites glisser sur la grille pour tracer une nouvelle pièce sur le niveau actif (minimum 1 × 1 m).'
              : `Mode pose actif : ${TYPES[activeTool].label}. ${
                  TYPES[activeTool].place === 'wall'
                    ? 'Cliquez près d’un mur pour l’aimanter automatiquement.'
                    : 'Cliquez à l’intérieur d’une pièce pour le poser.'
                }`}
          </p>
        )}
      </div>
    </div>
  );
}
