import { useState } from 'react';
import { ArrowUpDown, Trash2, CheckCircle2, Plus } from 'lucide-react';
import {
  Task,
  TaskStatus,
  TeamMember,
  SortField,
  SortDirection,
} from '../types/project';
import { PRIORITY_CONFIG, STATUS_CONFIG } from '../data/seedData';
import { formatShortDateFr, isOverdue } from '../utils/formatters';
import { Avatar } from './Avatar';
import { PriorityIndicator } from './PriorityIndicator';

interface TaskTableViewProps {
  tasks: Task[];
  members: TeamMember[];
  onSelectTask: (taskId: string) => void;
  onMoveTask: (taskId: string, nextStatus: TaskStatus) => void;
  onBatchComplete: (taskIds: string[]) => void;
  onBatchDelete: (taskIds: string[]) => void;
  onOpenCreateTask: () => void;
}

export function TaskTableView({
  tasks,
  members,
  onSelectTask,
  onMoveTask,
  onBatchComplete,
  onBatchDelete,
  onOpenCreateTask,
}: TaskTableViewProps) {
  const [sortField, setSortField] = useState<SortField>('echeance');
  const [sortDir, setSortDir] = useState<SortDirection>('asc');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const memberById = new Map(members.map((m) => [m.id, m]));

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    let cmp = 0;
    if (sortField === 'code') cmp = a.code.localeCompare(b.code);
    else if (sortField === 'titre') cmp = a.titre.localeCompare(b.titre);
    else if (sortField === 'statut')
      cmp = STATUS_CONFIG[a.statut].order - STATUS_CONFIG[b.statut].order;
    else if (sortField === 'priorite')
      cmp = PRIORITY_CONFIG[a.priorite].order - PRIORITY_CONFIG[b.priorite].order;
    else if (sortField === 'echeance') cmp = a.echeance.localeCompare(b.echeance);
    else if (sortField === 'heuresEstimees')
      cmp = a.heuresEstimees - b.heuresEstimees;

    return sortDir === 'asc' ? cmp : -cmp;
  });

  const visibleSelectedIds = selectedIds.filter((id) =>
    sortedTasks.some((t) => t.id === id)
  );
  const allSelected =
    sortedTasks.length > 0 && visibleSelectedIds.length === sortedTasks.length;

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(sortedTasks.map((t) => t.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  if (tasks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-slate-200 bg-white px-6 py-16 text-center dark:border-slate-800 dark:bg-slate-900">
        <p className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Aucune tâche ne correspond aux critères
        </p>
        <p className="mt-1.5 max-w-md text-sm text-slate-500 dark:text-slate-400">
          Ajustez vos filtres ou ajoutez une nouvelle tâche pour alimenter la feuille de route de ce projet.
        </p>
        <button
          type="button"
          onClick={onOpenCreateTask}
          className="mt-5 inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>Créer une tâche</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {visibleSelectedIds.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-white px-4 py-2.5 dark:border-slate-800 dark:bg-slate-900">
          <span className="font-mono text-xs font-medium tabular-nums text-slate-700 dark:text-slate-200">
            {visibleSelectedIds.length} tâche(s) sélectionnée(s)
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onBatchComplete(visibleSelectedIds);
                setSelectedIds([]);
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100 whitespace-nowrap shrink-0 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Marquer terminé</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onBatchDelete(visibleSelectedIds);
                setSelectedIds([]);
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-100 whitespace-nowrap shrink-0 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-400 dark:hover:bg-red-950"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Supprimer</span>
            </button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <table className="w-full min-w-[820px] border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-xs font-medium text-slate-500 dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-400">
              <th className="w-10 px-4 py-3">
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={toggleSelectAll}
                  aria-label="Tout sélectionner"
                  className="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-indigo-600 dark:border-slate-700 dark:bg-slate-800"
                />
              </th>
              <th className="px-3 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort('code')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap dark:hover:text-white"
                >
                  <span>Réf.</span>
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </th>
              <th className="px-3 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort('titre')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap dark:hover:text-white"
                >
                  <span>Tâche & domaine</span>
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </th>
              <th className="px-3 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort('statut')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap dark:hover:text-white"
                >
                  <span>Statut</span>
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </th>
              <th className="px-3 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort('priorite')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap dark:hover:text-white"
                >
                  <span>Priorité</span>
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </th>
              <th className="px-3 py-3">Responsable</th>
              <th className="px-3 py-3">
                <button
                  type="button"
                  onClick={() => toggleSort('echeance')}
                  className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap dark:hover:text-white"
                >
                  <span>Échéance</span>
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </th>
              <th className="px-4 py-3 text-right">
                <button
                  type="button"
                  onClick={() => toggleSort('heuresEstimees')}
                  className="inline-flex items-center justify-end gap-1 hover:text-slate-900 whitespace-nowrap dark:hover:text-white"
                >
                  <span>Charge</span>
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {sortedTasks.map((task) => {
              const member = memberById.get(task.assigneeId);
              const overdue = isOverdue(task.echeance, task.statut === 'termine');
              const isChecked = visibleSelectedIds.includes(task.id);

              return (
                <tr
                  key={task.id}
                  className={`transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                    isChecked ? 'bg-slate-50 dark:bg-slate-800/50' : ''
                  }`}
                >
                  <td className="px-4 py-2.5">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleSelectOne(task.id)}
                      aria-label={`Sélectionner ${task.code}`}
                      className="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-indigo-600 dark:border-slate-700 dark:bg-slate-800"
                    />
                  </td>
                  <td className="px-3 py-2.5 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    {task.code}
                  </td>
                  <td className="max-w-md px-3 py-2.5">
                    <button
                      type="button"
                      onClick={() => onSelectTask(task.id)}
                      className="block truncate text-left font-medium text-slate-900 hover:text-indigo-700 dark:text-slate-100 dark:hover:text-indigo-400"
                    >
                      {task.titre}
                    </button>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {task.categorie}
                      {task.sousTaches.length > 0 && (
                        <>
                          {' · '}
                          <span className="font-mono tabular-nums">
                            {task.sousTaches.filter((s) => s.terminee).length}/{task.sousTaches.length} sous-tâches
                          </span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    <select
                      aria-label={`Statut de ${task.code}`}
                      value={task.statut}
                      onChange={(e) =>
                        onMoveTask(task.id, e.target.value as TaskStatus)
                      }
                      className="rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-800 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                    >
                      {(Object.keys(STATUS_CONFIG) as TaskStatus[]).map((key) => (
                        <option key={key} value={key}>
                          {STATUS_CONFIG[key].label}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    <PriorityIndicator priority={task.priorite} />
                  </td>
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    {member ? (
                      <div className="flex items-center gap-2">
                        <Avatar member={member} size="sm" />
                        <span className="text-xs text-slate-700 dark:text-slate-300">
                          {member.nom}
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-400">Non assigné</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 whitespace-nowrap">
                    <span
                      className={`font-mono text-xs tabular-nums ${
                        overdue
                          ? 'font-semibold text-red-700 dark:text-red-400'
                          : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {formatShortDateFr(task.echeance)}
                      {overdue ? ' (retard)' : ''}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300 whitespace-nowrap">
                    {task.heuresPassees}h / {task.heuresEstimees}h
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
