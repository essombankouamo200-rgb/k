import { ItemType, PlanItem } from '../types/planelec';

/** Appareils de commande : un clic en 3D les fait basculer ON / OFF. */
export const CONTROLLER_TYPES: ReadonlySet<ItemType> = new Set<ItemType>([
  'switch',
  'pushbutton',
  'dimmer',
  'motion',
]);

/** Luminaires pilotés par un appareil de commande. */
export const LIGHT_TYPES: ReadonlySet<ItemType> = new Set<ItemType>([
  'light',
  'spots',
  'neon',
  'sconce',
]);

export function isController(it: PlanItem): boolean {
  return CONTROLLER_TYPES.has(it.type);
}

export function isLight(it: PlanItem): boolean {
  return LIGHT_TYPES.has(it.type);
}

/**
 * Appareil qui commande un luminaire :
 *  - celui choisi explicitement (switchId), s'il existe encore ;
 *  - sinon l'appareil de commande le plus proche dans la même pièce ;
 *  - sinon null (le luminaire suit alors le bouton général de la pièce).
 */
export function resolveController(light: PlanItem, items: PlanItem[]): PlanItem | null {
  if (typeof light.switchId === 'number') {
    const chosen = items.find((i) => i.id === light.switchId && isController(i));
    if (chosen) return chosen;
  }
  let best: PlanItem | null = null;
  let bestD = Infinity;
  for (const c of items) {
    if (!isController(c) || c.roomId !== light.roomId || c.floorId !== light.floorId) continue;
    const d = Math.hypot(c.x - light.x, c.y - light.y);
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return best;
}

/** Luminaires effectivement commandés par un appareil de commande donné. */
export function lightsControlledBy(controller: PlanItem, items: PlanItem[]): PlanItem[] {
  return items.filter(
    (i) => isLight(i) && resolveController(i, items)?.id === controller.id
  );
}
