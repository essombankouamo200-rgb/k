import * as THREE from 'three';
import { ItemType, PlanItem, Room, WallSide } from '../types/planelec';
import { TYPES } from '../data/catalog';
import { clamp, halfOf, snap, wallPos } from './electricalEngine';

export const SCALE_3D = 0.01;
export const WALL_HEIGHT_M = 2.45;
export const WALL_THICK_M = 0.14;

export const WALL_BASE_YAW: Record<WallSide, number> = {
  top: 0,
  right: -Math.PI / 2,
  bottom: Math.PI,
  left: Math.PI / 2,
};

/** Un équipement est-il fixé sur la face extérieure de son mur ? (caméras « extérieur » héritées incluses) */
export function isOutFace(it: Pick<PlanItem, 'face' | 'type' | 'camPlacement'>): boolean {
  return it.face === 'out' || (it.type === 'camera' && it.camPlacement === 'exterior');
}

/** Rotation (rad) d'un équipement mural : +z local pointe vers l'intérieur, ou vers l'extérieur si face 'out'. */
export function wallYawOf(side: WallSide, out: boolean): number {
  return WALL_BASE_YAW[side] + (out ? Math.PI : 0);
}

export const WALL_ROT_DEG: Record<WallSide, number> = {
  top: 0,
  right: 90,
  bottom: 180,
  left: -90,
};

export const SUPPORT_HOST_HEIGHT_CM: Partial<Record<ItemType, number>> = {
  table: 74,
  desk: 74,
  counter: 90,
};

export const TABLETOP_COMPATIBLE_TYPES = new Set<ItemType>([
  'pc',
  'tv',
  'nvr_screen',
  'thermostat',
  'alarm_panel',
  'intercom',
  'light',
  'socket',
  'socket2',
  'usb_socket',
  'rj45',
  'camera',
  'cooktop',
]);

export const CEILING_TYPES = new Set<ItemType>(['light', 'spots', 'neon', 'smoke']);

export function defaultWallElevationCm(type: ItemType): number {
  switch (type) {
    case 'camera':
      return 222;
    case 'ac_split':
    case 'siren':
      return 210;
    case 'sconce':
      return 185;
    case 'panel':
      return 155;
    case 'nvr_screen':
      return 148;
    case 'alarm_panel':
    case 'intercom':
    case 'thermostat':
    case 'window':
      return 145;
    case 'tv':
      return 140;
    case 'irve':
      return 125;
    case 'switch':
    case 'pushbutton':
    case 'dimmer':
    case 'motion':
      return 115;
    case 'door':
      return 102;
    case 'cooktop':
      return 90;
    case 'heater':
    case 'ac_outdoor':
      return 55;
    case 'socket':
    case 'socket2':
    case 'usb_socket':
    case 'spec':
    case 'rj45':
      return 35;
    default:
      return 110;
  }
}

export function isPointOverHost(
  pxCm: number,
  pyCm: number,
  host: PlanItem,
  marginCm = 0
): boolean {
  const T = TYPES[host.type];
  const hw = ((host.w ?? T.w ?? 100) / 2) + marginCm;
  const hd = ((host.h ?? T.h ?? 70) / 2) + marginCm;
  const rad = ((host.rot || 0) * Math.PI) / 180;
  const dx = pxCm - host.x;
  const dy = pyCm - host.y;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  const lx = dx * cos + dy * sin;
  const ly = -dx * sin + dy * cos;
  return Math.abs(lx) <= hw && Math.abs(ly) <= hd;
}

export function resolveItemElevationCm(it: PlanItem, allItems: PlanItem[]): number {
  if (typeof it.elevationCm === 'number') {
    return it.elevationCm;
  }
  const T = TYPES[it.type];
  if (it.type === 'pc') {
    const host = allItems.find(
      (h) =>
        h.id !== it.id &&
        h.floorId === it.floorId &&
        SUPPORT_HOST_HEIGHT_CM[h.type] !== undefined &&
        isPointOverHost(it.x, it.y, h, 8)
    );
    if (host) return SUPPORT_HOST_HEIGHT_CM[host.type] ?? 74;
    return 0;
  }
  if (CEILING_TYPES.has(it.type)) {
    return it.mountSurface === 'furniture' ? 74 : 239;
  }
  if (T.place === 'wall' || it.mountSurface === 'wall') {
    return defaultWallElevationCm(it.type);
  }
  return 0;
}

export function computeWallFlushFurniturePos(
  room: Room,
  side: WallSide,
  targetXCm: number,
  targetYCm: number,
  item: Pick<PlanItem, 'type' | 'w' | 'h'>
): { x: number; y: number; rot: number } {
  const T = TYPES[item.type];
  const fw = item.w ?? T.w ?? 100;
  const fd = item.h ?? T.h ?? 80;
  const wallClearance = 8; // half wall (7cm) + 1cm gap
  const minAlongX = room.x + fw / 2 + wallClearance;
  const maxAlongX = room.x + room.w - fw / 2 - wallClearance;
  const minAlongY = room.y + fw / 2 + wallClearance;
  const maxAlongY = room.y + room.h - fw / 2 - wallClearance;

  switch (side) {
    case 'top':
      return {
        x: clamp(snap(targetXCm, 5), minAlongX, maxAlongX),
        y: clamp(room.y + fd / 2 + wallClearance, room.y + 10, room.y + room.h - 10),
        rot: WALL_ROT_DEG.top,
      };
    case 'bottom':
      return {
        x: clamp(snap(targetXCm, 5), minAlongX, maxAlongX),
        y: clamp(room.y + room.h - fd / 2 - wallClearance, room.y + 10, room.y + room.h - 10),
        rot: WALL_ROT_DEG.bottom,
      };
    case 'left':
      return {
        x: clamp(room.x + fd / 2 + wallClearance, room.x + 10, room.x + room.w - 10),
        y: clamp(snap(targetYCm, 5), minAlongY, maxAlongY),
        rot: WALL_ROT_DEG.left,
      };
    case 'right':
      return {
        x: clamp(room.x + room.w - fd / 2 - wallClearance, room.x + 10, room.x + room.w - 10),
        y: clamp(snap(targetYCm, 5), minAlongY, maxAlongY),
        rot: WALL_ROT_DEG.right,
      };
  }
}

export interface SnapAnchor {
  id: string;
  kind: 'wall' | 'tabletop' | 'floor' | 'ceiling' | 'exterior';
  label: string;
  roomId: number;
  floorId: number;
  x: number; // cm
  y: number; // cm
  elevationCm: number;
  side: WallSide | null;
  rot: number;
  mountSurface: 'floor' | 'wall' | 'ceiling' | 'furniture';
  mountHostId: number | null;
  face?: 'in' | 'out';
  // Marker world coordinates relative to floorY = fy (meters):
  markerX: number;
  markerY: number;
  markerZ: number;
}

const WALL_FRENCH: Record<WallSide, string> = {
  top: 'Mur Nord',
  right: 'Mur Est',
  bottom: 'Mur Sud',
  left: 'Mur Ouest',
};

const INWARD_NORM: Record<WallSide, { x: number; z: number }> = {
  top: { x: 0, z: 1 },
  right: { x: -1, z: 0 },
  bottom: { x: 0, z: -1 },
  left: { x: 1, z: 0 },
};

export function generateRoomSnapAnchors(
  room: Room,
  item: PlanItem,
  roomItems: PlanItem[]
): SnapAnchor[] {
  const anchors: SnapAnchor[] = [];
  const T = TYPES[item.type];
  const canTabletop = TABLETOP_COMPATIBLE_TYPES.has(item.type);
  const canCeiling = CEILING_TYPES.has(item.type);
  const isWallDev = T.place === 'wall';
  const isFurn = Boolean(T.furn);

  // 1. Tabletop / Furniture Top Accrocheurs (Tables, Desks, Kitchen Counters)
  if (canTabletop) {
    const hosts = roomItems.filter(
      (h) => h.id !== item.id && SUPPORT_HOST_HEIGHT_CM[h.type] !== undefined
    );
    for (const host of hosts) {
      const hT = TYPES[host.type];
      const hw = host.w ?? hT.w ?? 100;
      const topCm = SUPPORT_HOST_HEIGHT_CM[host.type] ?? 74;
      const rad = ((host.rot || 0) * Math.PI) / 180;
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);
      const offsets =
        hw >= 110
          ? [
              { frac: -0.3, tag: 'Gauche' },
              { frac: 0, tag: 'Centre' },
              { frac: 0.3, tag: 'Droite' },
            ]
          : [{ frac: 0, tag: 'Centre' }];

      for (const off of offsets) {
        const lx = hw * off.frac;
        const ax = Math.round(host.x + lx * cos);
        const ay = Math.round(host.y + lx * sin);
        anchors.push({
          id: `tbl-${host.id}-${off.tag}`,
          kind: 'tabletop',
          label: `Sur ${hT.short} (${off.tag})`,
          roomId: room.id,
          floorId: room.floorId,
          x: ax,
          y: ay,
          elevationCm: topCm,
          side: null,
          rot: host.rot || 0,
          mountSurface: 'furniture',
          mountHostId: host.id,
          markerX: ax * SCALE_3D,
          markerY: 0.05 + topCm * SCALE_3D + 0.06,
          markerZ: ay * SCALE_3D,
        });
      }
    }
  }

  // 2. Wall Accrocheurs (all 4 walls, 3 positions per wall)
  if (isWallDev || isFurn || item.type === 'tv') {
    const sides: WallSide[] = ['top', 'right', 'bottom', 'left'];
    const fracs = [0.25, 0.5, 0.75];
    const wallElevCm = defaultWallElevationCm(item.type);

    for (const side of sides) {
      const n = INWARD_NORM[side];
      for (const f of fracs) {
        const targetX =
          side === 'top' || side === 'bottom'
            ? room.x + room.w * f
            : side === 'left'
            ? room.x
            : room.x + room.w;
        const targetY =
          side === 'left' || side === 'right'
            ? room.y + room.h * f
            : side === 'top'
            ? room.y
            : room.y + room.h;

        if (isWallDev || item.type === 'tv') {
          const pos = wallPos(room, side, { x: targetX, y: targetY }, halfOf(item));
          anchors.push({
            id: `wall-${side}-${f}`,
            kind: 'wall',
            label: `${WALL_FRENCH[side]} (${Math.round(f * 100)} %)`,
            roomId: room.id,
            floorId: room.floorId,
            x: pos.x,
            y: pos.y,
            elevationCm: wallElevCm,
            side,
            rot: WALL_ROT_DEG[side],
            mountSurface: 'wall',
            mountHostId: null,
            face: 'in',
            markerX: pos.x * SCALE_3D + n.x * 0.13,
            markerY: wallElevCm * SCALE_3D,
            markerZ: pos.y * SCALE_3D + n.z * 0.13,
          });
          // Face extérieure du même mur (groupe de clim, caméra, sirène, spot de façade…)
          if (item.type !== 'tv' && item.type !== 'door' && item.type !== 'window') {
            anchors.push({
              id: `wallout-${side}-${f}`,
              kind: 'exterior',
              label: `${WALL_FRENCH[side]} · face extérieure (${Math.round(f * 100)} %)`,
              roomId: room.id,
              floorId: room.floorId,
              x: pos.x,
              y: pos.y,
              elevationCm: wallElevCm,
              side,
              rot: WALL_ROT_DEG[side],
              mountSurface: 'wall',
              mountHostId: null,
              face: 'out',
              markerX: pos.x * SCALE_3D - n.x * 0.13,
              markerY: wallElevCm * SCALE_3D,
              markerZ: pos.y * SCALE_3D - n.z * 0.13,
            });
          }
        }

        if (isFurn && item.type !== 'pc') {
          // Furniture flush against the wall (floor level, rotated inward)
          const flush = computeWallFlushFurniturePos(room, side, targetX, targetY, item);
          const wallLineX =
            side === 'left' ? room.x : side === 'right' ? room.x + room.w : flush.x;
          const wallLineY =
            side === 'top' ? room.y : side === 'bottom' ? room.y + room.h : flush.y;

          anchors.push({
            id: `wflush-${side}-${f}`,
            kind: 'wall',
            label: `Contre ${WALL_FRENCH[side]}`,
            roomId: room.id,
            floorId: room.floorId,
            x: flush.x,
            y: flush.y,
            elevationCm: 0,
            side: null,
            rot: flush.rot,
            mountSurface: 'floor',
            mountHostId: null,
            markerX: wallLineX * SCALE_3D + n.x * 0.24,
            markerY: 0.28,
            markerZ: wallLineY * SCALE_3D + n.z * 0.24,
          });
        }
      }
    }
  }

  // 3. Ceiling Accrocheurs (Lights, Spots, Smoke)
  if (canCeiling) {
    const pts = [0.28, 0.5, 0.72];
    for (const fx of pts) {
      for (const fz of pts) {
        const ax = Math.round(snap(room.x + room.w * fx, 5));
        const ay = Math.round(snap(room.y + room.h * fz, 5));
        anchors.push({
          id: `ceil-${fx}-${fz}`,
          kind: 'ceiling',
          label: fx === 0.5 && fz === 0.5 ? 'Plafond (Centre)' : 'Plafond',
          roomId: room.id,
          floorId: room.floorId,
          x: ax,
          y: ay,
          elevationCm: 239,
          side: null,
          rot: item.rot || 0,
          mountSurface: 'ceiling',
          mountHostId: null,
          markerX: ax * SCALE_3D,
          markerY: WALL_HEIGHT_M - 0.14,
          markerZ: ay * SCALE_3D,
        });
      }
    }
  }

  // 4. Floor Accrocheurs (Furniture & Staircase)
  if (isFurn || item.type === 'staircase') {
    const floorSpots = [
      { fx: 0.5, fz: 0.5, tag: 'Centre pièce' },
      { fx: 0.32, fz: 0.32, tag: 'Zone N-O' },
      { fx: 0.68, fz: 0.32, tag: 'Zone N-E' },
      { fx: 0.32, fz: 0.68, tag: 'Zone S-O' },
      { fx: 0.68, fz: 0.68, tag: 'Zone S-E' },
    ];
    for (const sp of floorSpots) {
      const ax = Math.round(snap(room.x + room.w * sp.fx, 5));
      const ay = Math.round(snap(room.y + room.h * sp.fz, 5));
      anchors.push({
        id: `flr-${sp.fx}-${sp.fz}`,
        kind: 'floor',
        label: `Sol · ${sp.tag}`,
        roomId: room.id,
        floorId: room.floorId,
        x: clamp(ax, room.x + 20, room.x + room.w - 20),
        y: clamp(ay, room.y + 20, room.y + room.h - 20),
        elevationCm: 0,
        side: null,
        rot: item.rot || 0,
        mountSurface: 'floor',
        mountHostId: null,
        markerX: ax * SCALE_3D,
        markerY: 0.1,
        markerZ: ay * SCALE_3D,
      });
    }
  }

  return anchors;
}

export interface MagneticSnapResult {
  x: number;
  y: number;
  side: WallSide | null;
  rot: number;
  elevationCm: number;
  mountSurface: 'floor' | 'wall' | 'ceiling' | 'furniture';
  mountHostId: number | null;
  face?: 'in' | 'out';
  snapLabel: string;
}

const _tmpVec = new THREE.Vector3();

export function computeMagneticDragSnap(
  ray: THREE.Ray,
  item: PlanItem,
  room: Room,
  fy: number,
  roomItems: PlanItem[],
  preserveElevationCm?: number
): MagneticSnapResult | null {
  const T = TYPES[item.type];
  const canTabletop = TABLETOP_COMPATIBLE_TYPES.has(item.type);
  const canCeiling = CEILING_TYPES.has(item.type);
  const isWallOnly = T.place === 'wall';

  // 1. Check tabletop / furniture hosts first (if compatible)
  if (canTabletop) {
    const hosts = roomItems.filter(
      (h) => h.id !== item.id && SUPPORT_HOST_HEIGHT_CM[h.type] !== undefined
    );
    let bestHost: { host: PlanItem; topCm: number; x: number; y: number; dist: number } | null = null;

    for (const host of hosts) {
      const topCm = SUPPORT_HOST_HEIGHT_CM[host.type] ?? 74;
      const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(fy + 0.05 + topCm * SCALE_3D));
      const hit = ray.intersectPlane(plane, _tmpVec);
      if (!hit) continue;
      const hxCm = hit.x / SCALE_3D;
      const hyCm = hit.z / SCALE_3D;
      if (isPointOverHost(hxCm, hyCm, host, 14)) {
        const d = ray.origin.distanceTo(hit);
        if (!bestHost || d < bestHost.dist) {
          bestHost = {
            host,
            topCm,
            x: Math.round(snap(hxCm, 5)),
            y: Math.round(snap(hyCm, 5)),
            dist: d,
          };
        }
      }
    }

    if (bestHost) {
      return {
        x: bestHost.x,
        y: bestHost.y,
        side: null,
        rot: bestHost.host.rot || 0,
        elevationCm: bestHost.topCm,
        mountSurface: 'furniture',
        mountHostId: bestHost.host.id,
        snapLabel: `Accroché sur ${TYPES[bestHost.host.type].short} (${bestHost.topCm} cm)`,
      };
    }
  }

  // 2. Check wall planes for wall devices or wall-mountable TV
  if (isWallOnly || item.type === 'tv') {
    const rx = room.x * SCALE_3D;
    const rz = room.y * SCALE_3D;
    const rw = room.w * SCALE_3D;
    const rd = room.h * SCALE_3D;

    const wallPlanes: { side: WallSide; plane: THREE.Plane }[] = [
      { side: 'top', plane: new THREE.Plane(new THREE.Vector3(0, 0, 1), -rz) },
      { side: 'bottom', plane: new THREE.Plane(new THREE.Vector3(0, 0, -1), rz + rd) },
      { side: 'left', plane: new THREE.Plane(new THREE.Vector3(1, 0, 0), -rx) },
      { side: 'right', plane: new THREE.Plane(new THREE.Vector3(-1, 0, 0), rx + rw) },
    ];

    let bestWall: {
      side: WallSide;
      xCm: number;
      yCm: number;
      elevCm: number;
      dist: number;
      outside: boolean;
    } | null = null;

    for (const wp of wallPlanes) {
      // Only consider wall planes facing the camera ray (or closest valid hit within room bounds)
      const hit = ray.intersectPlane(wp.plane, _tmpVec);
      if (!hit) continue;
      if (hit.y < fy + 0.08 || hit.y > fy + WALL_HEIGHT_M - 0.05) continue;
      const hxCm = hit.x / SCALE_3D;
      const hyCm = hit.z / SCALE_3D;
      const margin = 15;
      if (
        hxCm < room.x - margin ||
        hxCm > room.x + room.w + margin ||
        hyCm < room.y - margin ||
        hyCm > room.y + room.h + margin
      ) {
        continue;
      }
      const d = ray.origin.distanceTo(hit);
      if (!bestWall || d < bestWall.dist) {
        bestWall = {
          side: wp.side,
          xCm: hxCm,
          yCm: hyCm,
          elevCm: Math.round(clamp(((hit.y - fy) / SCALE_3D), 15, 232) / 5) * 5,
          dist: d,
          // Les normales des plans pointent vers l'intérieur : origine du rayon « derrière » = on vise la face extérieure.
          outside: wp.plane.distanceToPoint(ray.origin) < 0,
        };
      }
    }

    if (bestWall && (isWallOnly || item.type === 'tv')) {
      const pos = wallPos(room, bestWall.side, { x: bestWall.xCm, y: bestWall.yCm }, halfOf(item));
      const elevCm =
        item.type === 'door'
          ? 102
          : item.type === 'window'
          ? 145
          : bestWall.elevCm;
      return {
        x: pos.x,
        y: pos.y,
        side: bestWall.side,
        rot: WALL_ROT_DEG[bestWall.side],
        elevationCm: elevCm,
        mountSurface: 'wall',
        mountHostId: null,
        face: item.type === 'door' || item.type === 'window' || item.type === 'tv' ? undefined : bestWall.outside ? 'out' : 'in',
        snapLabel: `Fixé sur ${WALL_FRENCH[bestWall.side]}${
          bestWall.outside && item.type !== 'door' && item.type !== 'window' && item.type !== 'tv'
            ? ' · face extérieure'
            : ''
        } (${elevCm} cm)`,
      };
    }

    // Fallback for wall-only items via floor projection to nearest wall
    if (isWallOnly) {
      const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(fy + 0.05));
      const fHit = ray.intersectPlane(floorPlane, _tmpVec);
      if (!fHit) return null;
      const fxCm = clamp(fHit.x / SCALE_3D, room.x, room.x + room.w);
      const fyCm = clamp(fHit.z / SCALE_3D, room.y, room.y + room.h);
      const dists: { side: WallSide; d: number }[] = [
        { side: 'top', d: Math.abs(fyCm - room.y) },
        { side: 'bottom', d: Math.abs(fyCm - (room.y + room.h)) },
        { side: 'left', d: Math.abs(fxCm - room.x) },
        { side: 'right', d: Math.abs(fxCm - (room.x + room.w)) },
      ];
      dists.sort((a, b) => a.d - b.d);
      const side = dists[0].side;
      const pos = wallPos(room, side, { x: fxCm, y: fyCm }, halfOf(item));
      const elevCm = preserveElevationCm ?? defaultWallElevationCm(item.type);
      return {
        x: pos.x,
        y: pos.y,
        side,
        rot: WALL_ROT_DEG[side],
        elevationCm: elevCm,
        mountSurface: 'wall',
        mountHostId: null,
        face: item.face === 'out' ? 'out' : 'in',
        snapLabel: `Fixé sur ${WALL_FRENCH[side]} (${elevCm} cm)`,
      };
    }
  }

  // 3. Ceiling items (light, spots, neon, smoke)
  if (canCeiling) {
    const ceilPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(fy + WALL_HEIGHT_M - 0.08));
    let hit = ray.intersectPlane(ceilPlane, _tmpVec);
    if (!hit) {
      const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(fy + 0.05));
      hit = ray.intersectPlane(floorPlane, _tmpVec);
    }
    if (!hit) return null;
    const cx = clamp(snap(hit.x / SCALE_3D, 5), room.x + 15, room.x + room.w - 15);
    const cy = clamp(snap(hit.z / SCALE_3D, 5), room.y + 15, room.y + room.h - 15);
    return {
      x: cx,
      y: cy,
      side: null,
      rot: item.rot || 0,
      elevationCm: 239,
      mountSurface: 'ceiling',
      mountHostId: null,
      snapLabel: 'Fixé au plafond',
    };
  }

  // 4. Floor furniture & staircase (with magnetic wall-flush snap!)
  const floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(fy + 0.05));
  const hit = ray.intersectPlane(floorPlane, _tmpVec);
  if (!hit) return null;

  const fxCm = hit.x / SCALE_3D;
  const fyCm = hit.z / SCALE_3D;
  const fw = item.w ?? T.w ?? 80;
  const fd = item.h ?? T.h ?? 80;

  if (T.furn && item.type !== 'pc') {
    const wallMargin = 28;
    const dists: { side: WallSide; d: number }[] = [
      { side: 'top', d: Math.abs(fyCm - (room.y + fd / 2)) },
      { side: 'bottom', d: Math.abs(fyCm - (room.y + room.h - fd / 2)) },
      { side: 'left', d: Math.abs(fxCm - (room.x + fd / 2)) },
      { side: 'right', d: Math.abs(fxCm - (room.x + room.w - fd / 2)) },
    ];
    dists.sort((a, b) => a.d - b.d);
    if (dists[0].d <= wallMargin) {
      const flush = computeWallFlushFurniturePos(room, dists[0].side, fxCm, fyCm, item);
      return {
        x: flush.x,
        y: flush.y,
        side: null,
        rot: flush.rot,
        elevationCm: 0,
        mountSurface: 'floor',
        mountHostId: null,
        snapLabel: `Collé contre ${WALL_FRENCH[dists[0].side]}`,
      };
    }
  }

  const padX = Math.min(room.w * 0.35, Math.max(15, (item.rot % 180 === 0 ? fw : fd) / 2 + 4));
  const padY = Math.min(room.h * 0.35, Math.max(15, (item.rot % 180 === 0 ? fd : fw) / 2 + 4));
  return {
    x: clamp(snap(fxCm, 5), room.x + padX, room.x + room.w - padX),
    y: clamp(snap(fyCm, 5), room.y + padY, room.y + room.h - padY),
    side: null,
    rot: item.rot || 0,
    elevationCm: 0,
    mountSurface: 'floor',
    mountHostId: null,
    snapLabel: 'Posé au sol',
  };
}
