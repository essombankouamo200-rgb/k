export const TODAY_ISO = new Date().toISOString().slice(0, 10);

const MONTHS_FR = [
  'janv.',
  'févr.',
  'mars',
  'avr.',
  'mai',
  'juin',
  'juil.',
  'août',
  'sept.',
  'oct.',
  'nov.',
  'déc.',
];

export function formatShortDateFr(isoDate: string): string {
  if (!isoDate) return '—';
  const parts = isoDate.split('-');
  if (parts.length !== 3) return isoDate;
  const day = Number(parts[2]);
  const monthIdx = Number(parts[1]) - 1;
  const month = MONTHS_FR[monthIdx] ?? parts[1];
  return `${day} ${month}`;
}

export function isOverdue(isoDate: string, isDone: boolean): boolean {
  if (!isoDate || isDone) return false;
  return isoDate < TODAY_ISO;
}

export function daysBetween(startIso: string, endIso: string): number {
  const start = new Date(`${startIso}T00:00:00Z`).getTime();
  const end = new Date(`${endIso}T00:00:00Z`).getTime();
  return Math.round((end - start) / 86400000);
}

export function addDaysIso(baseIso: string, days: number): string {
  const date = new Date(`${baseIso}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

/** Format monétaire FCFA : entiers, séparateur de milliers (espace insécable), ex. « 1 250 000 FCFA ». */
export function formatFcfa(value: number, withUnit = true): string {
  const n = Math.round(Number(value) || 0);
  const txt = n.toLocaleString('fr-FR', { maximumFractionDigits: 0 }).replace(/[  ]/g, ' ');
  return withUnit ? `${txt} FCFA` : txt;
}
