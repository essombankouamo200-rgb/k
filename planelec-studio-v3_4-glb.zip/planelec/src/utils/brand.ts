import logoDataUri from '../assets/brand/falo-logo.png?inline';

/** Logo FALO FINITION BTP (fond transparent, à poser sur fond marine), embarqué en base64. */
export const LOGO_DATA_URI: string = logoDataUri;
export const LOGO_RATIO = 636 / 368;
