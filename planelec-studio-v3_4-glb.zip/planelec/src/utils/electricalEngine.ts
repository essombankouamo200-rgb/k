import {
  CheckMessage,
  ComputedCircuit,
  DifferentialGroup,
  DistributionPanelModel,
  MaterialRow,
  PlanItem,
  PlanProjectData,
  Room,
  RoomReport,
  WallSide,
} from '../types/planelec';
import { CIRCUIT_PALETTE, ROOM_TYPES, TYPES } from '../data/catalog';

const SIDES: WallSide[] = ['top', 'right', 'bottom', 'left'];
const SECTIONS: [number, number, number][] = [
  [3680, 1.5, 16],
  [4600, 2.5, 20],
  [7360, 6, 32],
];

export function frNum(n: number, decimals = 0): string {
  return (Number(n) || 0).toLocaleString('fr-FR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function clamp(v: number, a: number, b: number): number {
  return a > b ? (a + b) / 2 : Math.min(b, Math.max(a, v));
}

export function snap(v: number, grid: number): number {
  return Math.round(v / grid) * grid;
}

export function plural(n: number, singular: string, pluralStr: string): string {
  return n > 1 ? pluralStr : singular;
}

export function wattsOf(it: PlanItem): number {
  if (it.type === 'neon') {
    return Math.round(((it.len ?? 200) / 100) * (it.wpm ?? 12));
  }
  if (it.type === 'spots') {
    return (it.count ?? 4) * (it.watts ?? 7);
  }
  if (it.type === 'staircase') {
    return (it.stepCount ?? 14) * (it.wattsPerStep ?? 2);
  }
  return it.watts || 0;
}

export function spotLen(it: PlanItem): number {
  return Math.max(0, ((it.count ?? 4) - 1) * (it.spacing ?? 80));
}

export function halfOf(it: PlanItem): number {
  const def = TYPES[it.type];
  if (it.len && def.struct) return it.len / 2 + 6;
  return def.half ?? 16;
}

export function inRoom(r: Room, p: { x: number; y: number }): boolean {
  return p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h;
}

export function roomAt(rooms: Room[], p: { x: number; y: number }): Room | null {
  return (
    rooms
      .filter((r) => inRoom(r, p))
      .sort((a, b) => a.w * a.h - b.w * b.h)[0] || null
  );
}

export function edgeDist(r: Room, side: WallSide, p: { x: number; y: number }): number {
  if (side === 'top' || side === 'bottom') {
    const cx = clamp(p.x, r.x, r.x + r.w);
    const cy = side === 'top' ? r.y : r.y + r.h;
    return Math.hypot(p.x - cx, p.y - cy);
  }
  const cx = side === 'left' ? r.x : r.x + r.w;
  const cy = clamp(p.y, r.y, r.y + r.h);
  return Math.hypot(p.x - cx, p.y - cy);
}

export function nearestEdge(
  rooms: Room[],
  p: { x: number; y: number },
  maxD: number
): { room: Room; side: WallSide; d: number } | null {
  const inside = rooms.filter((r) => inRoom(r, p));
  const pool = inside.length ? inside : rooms;
  let best: { room: Room; side: WallSide; d: number } | null = null;
  for (const room of pool) {
    for (const side of SIDES) {
      const d = edgeDist(room, side, p);
      if (!best || d < best.d) best = { room, side, d };
    }
  }
  return best && best.d <= maxD ? best : null;
}

export function wallPos(
  r: Room,
  side: WallSide,
  p: { x: number; y: number },
  half: number
): { x: number; y: number } {
  if (side === 'top' || side === 'bottom') {
    return {
      x: clamp(snap(p.x, 5), r.x + half, r.x + r.w - half),
      y: side === 'top' ? r.y : r.y + r.h,
    };
  }
  return {
    x: side === 'left' ? r.x : r.x + r.w,
    y: clamp(snap(p.y, 5), r.y + half, r.y + r.h - half),
  };
}

export function moveItemToPoint(
  it: PlanItem,
  floorRooms: Room[],
  p: { x: number; y: number }
): PlanItem {
  const T = TYPES[it.type];
  if (T.place === 'wall') {
    const edge = nearestEdge(floorRooms, p, Infinity);
    if (!edge) return it;
    const pos = wallPos(edge.room, edge.side, p, halfOf(it));
    return {
      ...it,
      roomId: edge.room.id,
      floorId: edge.room.floorId,
      side: edge.side,
      x: pos.x,
      y: pos.y,
    };
  }
  const r = roomAt(floorRooms, p) || floorRooms.find((rm) => rm.id === it.roomId);
  if (!r) return it;
  return {
    ...it,
    roomId: r.id,
    floorId: r.floorId,
    x: clamp(snap(p.x, 5), r.x + 10, r.x + r.w - 10),
    y: clamp(snap(p.y, 5), r.y + 10, r.y + r.h - 10),
  };
}

export function fitItemInRoom(it: PlanItem, room: Room | undefined): PlanItem {
  if (!room) return it;
  if (TYPES[it.type].place === 'wall' && it.side) {
    const pos = wallPos(room, it.side, { x: it.x, y: it.y }, halfOf(it));
    return { ...it, x: pos.x, y: pos.y };
  }
  return {
    ...it,
    x: clamp(it.x, room.x + 10, room.x + room.w - 10),
    y: clamp(it.y, room.y + 10, room.y + room.h - 10),
  };
}

function perimRoom(i: PlanItem, roomById: Map<number, Room>): number {
  const r = roomById.get(i.roomId);
  if (!r) return 0;
  switch (i.side) {
    case 'top':
      return i.x - r.x;
    case 'right':
      return r.w + (i.y - r.y);
    case 'bottom':
      return r.w + r.h + (r.w - (i.x - r.x));
    case 'left':
      return 2 * r.w + r.h + (r.h - (i.y - r.y));
    default:
      return (i.y - r.y) * 2 + (i.x - r.x) * 0.001;
  }
}

function pickSection(watts: number, minIdx = 0) {
  for (let i = minIdx; i < SECTIONS.length; i++) {
    if (watts <= SECTIONS[i][0]) {
      return {
        limit: SECTIONS[i][0],
        sectionMm2: SECTIONS[i][1],
        breakerA: SECTIONS[i][2],
        over: false,
      };
    }
  }
  const last = SECTIONS[SECTIONS.length - 1];
  return {
    limit: last[0],
    sectionMm2: last[1],
    breakerA: last[2],
    over: true,
  };
}

function chainFrom(start: PlanItem, items: PlanItem[]): PlanItem[] {
  const rest = [...items];
  const out: PlanItem[] = [];
  let cur: PlanItem = start;
  while (rest.length > 0) {
    let bestIdx = 0;
    let bestDist = Infinity;
    rest.forEach((candidate, idx) => {
      const floorPenalty = candidate.floorId === cur.floorId ? 0 : 400;
      const d =
        Math.abs(candidate.x - cur.x) +
        Math.abs(candidate.y - cur.y) +
        floorPenalty;
      if (d < bestDist) {
        bestDist = d;
        bestIdx = idx;
      }
    });
    cur = rest.splice(bestIdx, 1)[0];
    out.push(cur);
  }
  return out;
}

export interface SimulationOutput {
  circuits: ComputedCircuit[];
  itemCircuitColor: Record<number, string>;
  itemCircuitId: Record<number, string>;
  applianceLinks: { appliance: PlanItem; socket: PlanItem }[];
  unlinkedApplianceIds: Set<number>;
  roomReports: RoomReport[];
  panel: DistributionPanelModel;
  totalInstalledW: number;
  totalActiveW: number;
  totalCurrentA: number;
}

export function runElectricalSimulation(
  project: PlanProjectData,
  unitPrices: Record<string, number>
): { sim: SimulationOutput; materials: MaterialRow[] } {
  const {
    floors,
    rooms,
    items,
    k,
    sockMode,
    includeSurgeProtector,
    subscriptionKva,
  } = project;
  const panelItem = items.find((i) => i.type === 'panel') || null;
  const roomById = new Map(rooms.map((r) => [r.id, r]));
  const roomIndexMap = new Map(rooms.map((r, idx) => [r.id, idx]));
  const floorById = new Map(floors.map((f) => [f.id, f]));

  const orderScore = (it: PlanItem) =>
    (floorById.get(it.floorId)?.elevationIndex ?? 0) * 10000000 +
    (roomIndexMap.get(it.roomId) ?? 99) * 100000 +
    perimRoom(it, roomById);

  const powered = items
    .filter((i) => TYPES[i.type].power)
    .sort((a, b) => orderScore(a) - orderScore(b));

  const circuits: ComputedCircuit[] = [];
  const itemCircuitMap = new Map<number, ComputedCircuit>();

  const addCircuit = (
    kind: ComputedCircuit['kind'],
    initialItems: PlanItem[],
    sectionMm2: number,
    breakerA: number,
    dropMaxPct: number,
    diffType: 'A' | 'AC',
    label?: string
  ): ComputedCircuit => {
    const idx = circuits.length;
    const c: ComputedCircuit = {
      id: `c-${idx + 1}`,
      kind,
      name: label || '',
      items: [...initialItems],
      sectionMm2,
      breakerA,
      dropMaxPct,
      diffType,
      warnings: [],
      extras: [],
      color: CIRCUIT_PALETTE[idx % CIRCUIT_PALETTE.length],
      watts: 0,
      points: 0,
      currentA: 0,
      chain: [],
      lengthM: null,
      dropPct: null,
    };
    circuits.push(c);
    c.items.forEach((it) => itemCircuitMap.set(it.id, c));
    return c;
  };

  // 1. Lights
  const lights = powered.filter((i) => TYPES[i.type].family === 'light');
  for (let i = 0; i < lights.length; i += 8) {
    addCircuit('light', lights.slice(i, i + 8), 1.5, 16, 3, 'AC');
  }

  // 2. Spots
  let curSpotCircuit: ComputedCircuit | null = null;
  for (const s of powered.filter((i) => i.type === 'spots')) {
    const existingCount = curSpotCircuit
      ? curSpotCircuit.items.reduce((sum, it) => sum + (it.count ?? 4), 0)
      : 0;
    if (!curSpotCircuit || existingCount + (s.count ?? 4) > 12) {
      curSpotCircuit = addCircuit('spot', [], 1.5, 16, 3, 'AC');
    }
    curSpotCircuit.items.push(s);
    itemCircuitMap.set(s.id, curSpotCircuit);
  }

  // 3. Neon / LED strips
  let curNeonCircuit: ComputedCircuit | null = null;
  for (const n of powered.filter((i) => i.type === 'neon')) {
    const existingW = curNeonCircuit
      ? curNeonCircuit.items.reduce((sum, it) => sum + wattsOf(it), 0)
      : 0;
    if (!curNeonCircuit || existingW + wattsOf(n) > 500) {
      curNeonCircuit = addCircuit('neon', [], 1.5, 16, 3, 'AC');
    }
    curNeonCircuit.items.push(n);
    itemCircuitMap.set(n.id, curNeonCircuit);
  }

  // 3b. Staircase LED sequential circuits
  const stairs = powered.filter((i) => i.type === 'staircase');
  if (stairs.length > 0) {
    addCircuit('stair_led', stairs, 1.5, 16, 3, 'AC', 'Escalier LED Séquentiel');
  }

  // Link switches/pushbuttons/dimmers/motion to nearest lighting circuit
  const lightEmitters = powered.filter((i) =>
    ['light', 'spot', 'neon'].includes(TYPES[i.type].family || '')
  );
  for (const sw of items.filter((i) =>
    ['switch', 'pushbutton', 'dimmer', 'motion'].includes(i.type)
  )) {
    let bestLight: PlanItem | null = null;
    let bestD = Infinity;
    for (const l of lightEmitters) {
      const floorPenalty = l.floorId === sw.floorId ? 0 : 1200;
      const roomPenalty = l.roomId === sw.roomId ? 0 : 300;
      const d =
        Math.abs(l.x - sw.x) +
        Math.abs(l.y - sw.y) +
        roomPenalty +
        floorPenalty;
      if (d < bestD) {
        bestD = d;
        bestLight = l;
      }
    }
    if (bestLight) {
      const c = itemCircuitMap.get(bestLight.id);
      if (c) {
        c.items.push(sw);
        itemCircuitMap.set(sw.id, c);
      }
    }
  }

  // 4. Sockets 16A (single, double, USB-C)
  const socketItems = powered.filter((i) =>
    ['socket', 'socket2', 'usb_socket'].includes(i.type)
  );
  const sockSec = sockMode === 8 ? [1.5, 16] : [2.5, 20];
  let curSockCircuit: ComputedCircuit | null = null;
  let curOutlets = 0;
  for (const sk of socketItems) {
    const count = TYPES[sk.type].outlets ?? 1;
    if (!curSockCircuit || curOutlets + count > sockMode) {
      curSockCircuit = addCircuit('socket', [], sockSec[0], sockSec[1], 5, 'AC');
      curOutlets = 0;
    }
    curSockCircuit.items.push(sk);
    itemCircuitMap.set(sk.id, curSockCircuit);
    curOutlets += count;
  }

  // 5. Heaters
  let curHeatCircuit: ComputedCircuit | null = null;
  let curHeatW = 0;
  for (const h of powered.filter((i) => i.type === 'heater')) {
    const w = wattsOf(h);
    if (w > 3500) {
      const p = pickSection(w);
      const c = addCircuit('heat', [h], p.sectionMm2, p.breakerA, 5, 'AC');
      if (p.over) {
        c.warnings.push(`Puissance au-delà de ${frNum(p.limit)} W : à répartir.`);
      }
    } else {
      if (!curHeatCircuit || curHeatW + w > 3500) {
        curHeatCircuit = addCircuit('heat', [], 1.5, 16, 5, 'AC');
        curHeatW = 0;
      }
      curHeatCircuit.items.push(h);
      itemCircuitMap.set(h.id, curHeatCircuit);
      curHeatW += w;
    }
  }

  // 5b. HVAC / Air Conditioning (Climatisation réversible)
  const hvacItems = powered.filter(
    (i) => i.type === 'ac_split' || i.type === 'ac_outdoor'
  );
  let curHvacCircuit: ComputedCircuit | null = null;
  let curHvacW = 0;
  for (const hv of hvacItems) {
    const w = wattsOf(hv);
    if (!curHvacCircuit || curHvacW + w > 4400) {
      curHvacCircuit = addCircuit('hvac', [], 2.5, 20, 5, 'A');
      curHvacW = 0;
    }
    curHvacCircuit.items.push(hv);
    itemCircuitMap.set(hv.id, curHvacCircuit);
    curHvacW += w;
  }

  // Link thermostats to nearest HVAC circuit
  for (const th of items.filter((i) => i.type === 'thermostat')) {
    let bestHv: PlanItem | null = null;
    let bestD = Infinity;
    for (const hv of hvacItems) {
      const d =
        Math.abs(hv.x - th.x) +
        Math.abs(hv.y - th.y) +
        (hv.floorId === th.floorId ? 0 : 1200);
      if (d < bestD) {
        bestD = d;
        bestHv = hv;
      }
    }
    if (bestHv) {
      const c = itemCircuitMap.get(bestHv.id);
      if (c) {
        c.items.push(th);
        itemCircuitMap.set(th.id, c);
      }
    }
  }

  // 6. Specialized 20A circuits
  for (const sp of powered.filter((i) => i.type === 'spec')) {
    const p = pickSection(wattsOf(sp), 1);
    const isWashingMachine = /lave[-\s]?linge/i.test(sp.name);
    const c = addCircuit(
      'spec',
      [sp],
      p.sectionMm2,
      p.breakerA,
      5,
      isWashingMachine ? 'A' : 'AC',
      `Spécialisée${sp.name ? ` : ${sp.name}` : ''}`
    );
    if (p.over) {
      c.warnings.push(`Puissance au-delà de ${frNum(p.limit)} W : à répartir.`);
    }
  }

  // 7. Cooktop 32A
  for (const ck of powered.filter((i) => i.type === 'cooktop')) {
    const p = pickSection(wattsOf(ck), 2);
    const c = addCircuit(
      'cook',
      [ck],
      p.sectionMm2,
      p.breakerA,
      5,
      'A',
      `Plaque de cuisson${ck.name ? ` : ${ck.name}` : ''}`
    );
    if (p.over) {
      c.warnings.push(`Puissance supérieure à ${frNum(p.limit)} W (limite 32 A).`);
    }
  }

  // 8. EV Charger / IRVE
  for (const ev of powered.filter((i) => i.type === 'irve')) {
    const c = addCircuit(
      'irve',
      [ev],
      10,
      40,
      5,
      'A',
      `Borne VE${ev.name ? ` : ${ev.name}` : ''}`
    );
    if (wattsOf(ev) > 7400) {
      c.warnings.push('Au-delà de 7,4 kW, raccordement triphasé recommandé.');
    }
  }

  // 9. Surveillance & Security dedicated circuit
  const survItems = powered.filter((i) => TYPES[i.type].surveillance);
  if (survItems.length > 0) {
    addCircuit(
      'surveillance',
      survItems,
      1.5,
      16,
      5,
      'AC',
      'Surveillance & Alarme'
    );
  }

  // Name & base wattage
  const baseNames: Record<string, string> = {
    light: 'Éclairage',
    spot: 'Spots',
    neon: 'Néon / LED',
    socket: 'Prises 16 A',
    heat: 'Chauffage',
    hvac: 'Climatisation / PAC',
  };
  const kindCounts: Record<string, number> = {};
  for (const c of circuits) {
    if (baseNames[c.kind]) {
      kindCounts[c.kind] = (kindCounts[c.kind] || 0) + 1;
      c.name = `${baseNames[c.kind]} ${kindCounts[c.kind]}`;
    }
    if (c.kind === 'heat' && c.items.length === 1 && c.items[0].name) {
      c.name += ` (${c.items[0].name})`;
    }
    c.watts = c.items.reduce((sum, it) => sum + wattsOf(it), 0);
  }

  // Link floor appliances (TV, Fridge, PC) to nearest socket in same room
  const applianceLinks: { appliance: PlanItem; socket: PlanItem }[] = [];
  const unlinkedApplianceIds = new Set<number>();

  for (const app of items.filter((i) => TYPES[i.type].appl)) {
    let bestSock: PlanItem | null = null;
    let bestD = Infinity;
    for (const sk of items) {
      if (
        ['socket', 'socket2', 'usb_socket'].includes(sk.type) &&
        sk.roomId === app.roomId
      ) {
        const d = Math.hypot(sk.x - app.x, sk.y - app.y);
        if (d < bestD) {
          bestD = d;
          bestSock = sk;
        }
      }
    }
    if (bestSock && bestD <= 250) {
      const c = itemCircuitMap.get(bestSock.id);
      if (c) {
        c.extras.push({ item: app, watts: wattsOf(app) });
        c.watts += wattsOf(app);
        applianceLinks.push({ appliance: app, socket: bestSock });
        continue;
      }
    }
    unlinkedApplianceIds.add(app.id);
  }

  // Finalize currents, cable lengths (with multi-floor vertical riser!), voltage drops
  for (const c of circuits) {
    c.points =
      c.kind === 'spot'
        ? c.items.filter((i) => i.type === 'spots').reduce((sum, i) => sum + (i.count ?? 4), 0)
        : c.kind === 'stair_led'
        ? c.items.filter((i) => i.type === 'staircase').reduce((sum, i) => sum + (i.stepCount ?? 14), 0)
        : c.kind === 'socket'
        ? c.items
            .filter((i) => ['socket', 'socket2', 'usb_socket'].includes(i.type))
            .reduce((sum, i) => sum + (TYPES[i.type].outlets ?? 1), 0)
        : c.items.filter((i) => TYPES[i.type].power).length;

    c.currentA = c.watts / 230;
    if (c.currentA > c.breakerA) {
      c.warnings.push(
        `Intensité calculée (${frNum(c.currentA, 1)} A) supérieure au calibre ${c.breakerA} A.`
      );
    }

    if (panelItem) {
      const ordered = chainFrom(panelItem, c.items);
      c.chain = [
        { x: panelItem.x, y: panelItem.y, floorId: panelItem.floorId, roomId: panelItem.roomId, itemId: panelItem.id },
        ...ordered.map((it) => ({
          x: it.x,
          y: it.y,
          floorId: it.floorId,
          roomId: it.roomId,
          itemId: it.id,
        })),
      ];
      let cm = 0;
      let verticalCm = 0;
      for (let i = 1; i < c.chain.length; i++) {
        cm +=
          Math.abs(c.chain[i].x - c.chain[i - 1].x) +
          Math.abs(c.chain[i].y - c.chain[i - 1].y);
        const fPrev = floorById.get(c.chain[i - 1].floorId ?? 0)?.elevationIndex ?? 0;
        const fCur = floorById.get(c.chain[i].floorId ?? 0)?.elevationIndex ?? 0;
        if (fPrev !== fCur) {
          verticalCm += Math.abs(fCur - fPrev) * 280; // 2.8m riser between levels
        }
      }
      c.lengthM = (cm + verticalCm) / 100 + 1.5 * ordered.length;
      c.dropPct =
        ((2 * 0.0225 * c.lengthM * c.currentA) / (c.sectionMm2 * 230)) * 100;
      if (c.dropPct > c.dropMaxPct) {
        c.warnings.push(
          `Chute de tension ${frNum(c.dropPct, 1)} % (> ${c.dropMaxPct} %) : augmenter la section.`
        );
      }
    }
  }

  const itemCircuitColor: Record<number, string> = {};
  const itemCircuitId: Record<number, string> = {};
  for (const c of circuits) {
    for (const it of c.items) {
      itemCircuitColor[it.id] = c.color;
      itemCircuitId[it.id] = c.id;
    }
  }

  // Room reports + Bathroom Volume 0/1/2 checks
  const roomReports: RoomReport[] = rooms.map((room) => {
    const rt = ROOM_TYPES[room.type] || ROOM_TYPES.autre;
    const roomItems = items.filter((i) => i.roomId === room.id);
    const areaM2 = (room.w * room.h) / 10000;
    const checks: CheckMessage[] = [];
    const floorName = floorById.get(room.floorId)?.name ?? 'Niveau';

    const outletCount = roomItems
      .filter((i) => ['socket', 'socket2', 'usb_socket'].includes(i.type))
      .reduce((sum, i) => sum + (TYPES[i.type].outlets ?? 1), 0);
    const need = rt.sock(areaM2);
    if (need > 0) {
      checks.push({
        level: outletCount >= need ? 'ok' : 'warn',
        text: `Prises 16 A : ${outletCount} socle${plural(outletCount, '', 's')} sur ${need} minimum${
          rt.outdoor ? ' (étanches IP44)' : ''
        }`,
      });
    }

    const nLight = roomItems.filter((i) =>
      ['light', 'sconce', 'spots', 'neon', 'staircase'].includes(i.type)
    ).length;
    checks.push({
      level: nLight ? 'ok' : 'warn',
      text: nLight
        ? `Éclairage : ${nLight} équipement${plural(nLight, '', 's')} lumineux`
        : 'Aucun éclairage dans la pièce',
    });

    const nCmd = roomItems.filter((i) =>
      ['switch', 'pushbutton', 'dimmer', 'motion'].includes(i.type)
    ).length;
    if (nLight) {
      checks.push({
        level: nCmd ? 'ok' : 'warn',
        text: nCmd
          ? `Commande : ${nCmd} point${plural(nCmd, '', 's')} de commande`
          : "Aucun interrupteur ou détecteur pour commander l'éclairage",
      });
    }

    if (rt.rj) {
      const rjCount = roomItems.filter((i) => i.type === 'rj45').length;
      checks.push({
        level: rjCount ? 'ok' : 'info',
        text: `Prise RJ45 / TV : ${rjCount} (1 recommandée)`,
      });
    }

    for (const app of roomItems.filter((i) => TYPES[i.type].appl && unlinkedApplianceIds.has(i.id))) {
      checks.push({
        level: 'warn',
        text: `${app.name || TYPES[app.type].short} : aucune prise 16 A à moins de 2,5 m`,
      });
    }

    const wetFixtures = roomItems.filter((i) => i.type === 'bath' || i.type === 'shower');
    if (wetFixtures.length > 0) {
      let zoneViolationFound = false;
      for (const fix of wetFixtures) {
        const fw = (fix.rot % 180 === 0 ? fix.w : fix.h) ?? 90;
        const fh = (fix.rot % 180 === 0 ? fix.h : fix.w) ?? 90;
        const rx0 = fix.x - fw / 2;
        const rx1 = fix.x + fw / 2;
        const ry0 = fix.y - fh / 2;
        const ry1 = fix.y + fh / 2;

        for (const el of roomItems) {
          if (
            ![
              'socket',
              'socket2',
              'usb_socket',
              'spec',
              'switch',
              'pushbutton',
              'dimmer',
              'heater',
              'panel',
            ].includes(el.type)
          ) {
            continue;
          }
          const cx = clamp(el.x, rx0, rx1);
          const cy = clamp(el.y, ry0, ry1);
          const distCm = Math.hypot(el.x - cx, el.y - cy);
          if (distCm < 60) {
            zoneViolationFound = true;
            if (el.type === 'heater' && distCm >= 5) {
              checks.push({
                level: 'info',
                text: `${TYPES[el.type].short} à ${Math.round(distCm)} cm (Volume 2) : Classe II IPX4 obligatoire.`,
              });
            } else {
              checks.push({
                level: 'warn',
                text: `${TYPES[el.type].short} à ${Math.round(distCm)} cm de la ${
                  fix.type === 'bath' ? 'baignoire' : 'douche'
                } (< 60 cm interdit NF C 15-100).`,
              });
            }
          }
        }
      }
      if (!zoneViolationFound) {
        checks.push({
          level: 'ok',
          text: 'Volumes de sécurité (60 cm douche/baignoire) respectés.',
        });
      }
    } else if (room.type === 'sdb') {
      checks.push({
        level: 'info',
        text: 'Ajoutez la baignoire ou la douche pour vérifier le rayon de sécurité de 60 cm.',
      });
    }

    let powerW = roomItems
      .filter((i) => TYPES[i.type].power)
      .reduce((sum, i) => sum + wattsOf(i), 0);
    for (const link of applianceLinks) {
      if (link.appliance.roomId === room.id) {
        powerW += wattsOf(link.appliance);
      }
    }

    return {
      room,
      floorName,
      checks,
      powerW,
      areaM2,
      warnCount: checks.filter((c) => c.level === 'warn').length,
    };
  });

  // Distribution Panel
  const typeACircuits = circuits.filter((c) => c.diffType === 'A');
  const typeACCircuits = circuits.filter((c) => c.diffType === 'AC');
  const rows: DifferentialGroup[] = [];

  const pushDiffGroups = (list: ComputedCircuit[], diffType: 'A' | 'AC') => {
    for (let i = 0; i < list.length; i += 8) {
      const slice = list.slice(i, i + 8);
      const totalWatts = slice.reduce((s, c) => s + c.watts, 0);
      const needs63 =
        diffType === 'A' ||
        totalWatts > 8000 ||
        slice.some((c) => c.breakerA >= 32);
      rows.push({
        id: `diff-${rows.length + 1}`,
        rowIndex: rows.length + 1,
        type: diffType,
        ratingA: needs63 ? 63 : 40,
        sensitivityMa: 30,
        circuits: slice,
        totalWatts,
        modulesCount: 2 + slice.length,
      });
    }
  };

  if (typeACircuits.length > 0) pushDiffGroups(typeACircuits, 'A');
  if (typeACCircuits.length > 0) pushDiffGroups(typeACCircuits, 'AC');
  if (rows.length === 0) {
    rows.push({
      id: 'diff-1',
      rowIndex: 1,
      type: 'AC',
      ratingA: 40,
      sensitivityMa: 30,
      circuits: [],
      totalWatts: 0,
      modulesCount: 2,
    });
  }

  const hasJourNuitContactor = items.some(
    (i) => i.type === 'spec' && /chauffe[-\s]?eau|cumulus|ballon/i.test(i.name)
  );
  const hasTelerupteur = items.some((i) => i.type === 'pushbutton');
  const hasStairController = items.some((i) => i.type === 'staircase');

  const extraModules =
    (includeSurgeProtector ? 2 : 0) +
    (hasJourNuitContactor ? 3 : 0) +
    (hasTelerupteur ? 1 : 0) +
    (hasStairController ? 3 : 0);
  const totalModules =
    rows.reduce((sum, r) => sum + r.modulesCount, 0) + extraModules;
  const recommendedRows = Math.max(1, Math.min(4, Math.ceil(totalModules / 13)));

  const agcpRatingA: 30 | 45 | 60 =
    subscriptionKva <= 6 ? 30 : subscriptionKva <= 9 ? 45 : 60;

  const panel: DistributionPanelModel = {
    agcpRatingA,
    hasSurgeProtector: includeSurgeProtector,
    hasJourNuitContactor,
    hasTelerupteur,
    hasStairController,
    rows,
    totalModules,
    recommendedRows,
  };

  const totalInstalledW = circuits.reduce((sum, c) => sum + c.watts, 0);
  const totalActiveW = totalInstalledW * k;
  const totalCurrentA = totalActiveW / 230;

  // Materials & Budget BOM
  const materials: MaterialRow[] = [];
  const addMat = (
    id: string,
    category: MaterialRow['category'],
    label: string,
    quantity: number,
    unit: string,
    priceKey: string
  ) => {
    if (quantity <= 0) return;
    const unitPrice = unitPrices[priceKey] ?? 0;
    materials.push({
      id,
      category,
      label,
      quantity,
      unit,
      unitPrice,
      total: quantity * unitPrice,
    });
  };

  addMat(
    'mat-coffret',
    'Protection',
    `Coffret électrique ${recommendedRows} rangée${plural(recommendedRows, '', 's')} (${recommendedRows * 13} mod.)`,
    1,
    'u',
    'coffret'
  );
  addMat(
    'mat-diff-a',
    'Protection',
    'Interrupteur différentiel 30 mA Type A',
    rows.filter((r) => r.type === 'A').length,
    'u',
    'diffA'
  );
  addMat(
    'mat-diff-ac',
    'Protection',
    'Interrupteur différentiel 30 mA Type AC',
    rows.filter((r) => r.type === 'AC').length,
    'u',
    'diffAC'
  );
  if (includeSurgeProtector) {
    addMat('mat-para', 'Protection', 'Parafoudre modulaire Type 2', 1, 'u', 'parafoudre');
  }
  if (hasJourNuitContactor) {
    addMat('mat-jn', 'Automatisme', 'Contacteur Jour/Nuit + disj. 2 A', 1, 'ens.', 'contacteur');
  }
  if (hasTelerupteur) {
    addMat('mat-tel', 'Automatisme', 'Télérupteur modulaire 16 A', 1, 'u', 'telerupteur');
  }
  if (hasStairController) {
    addMat('mat-stairctrl', 'Automatisme', 'Contrôleur escalier LED séquentiel + 2 PIR', 1, 'kit', 'stairCtrl');
  }

  const breakerCounts: Record<number, number> = {};
  const cableMeters: Record<number, number> = {};
  for (const c of circuits) {
    breakerCounts[c.breakerA] = (breakerCounts[c.breakerA] || 0) + 1;
    if (c.lengthM !== null) {
      cableMeters[c.sectionMm2] = (cableMeters[c.sectionMm2] || 0) + c.lengthM;
    }
  }
  for (const amp of Object.keys(breakerCounts).map(Number).sort((a, b) => a - b)) {
    const key = amp <= 16 ? 'brk16' : amp <= 20 ? 'brk20' : 'brk32';
    addMat(
      `mat-brk-${amp}`,
      'Protection',
      `Disjoncteur divisionnaire ${amp} A`,
      breakerCounts[amp],
      'u',
      key
    );
  }

  for (const sec of Object.keys(cableMeters).map(Number).sort((a, b) => a - b)) {
    const meters = Math.ceil(cableMeters[sec] * 1.1);
    const key = sec <= 1.5 ? 'cable15' : sec <= 2.5 ? 'cable25' : 'cable6';
    addMat(
      `mat-cable-${sec}`,
      'Câblage',
      `Gaine ICTA + 3G ${frNum(sec, 1)} mm² (marge 10 %)`,
      meters,
      'm',
      key
    );
  }

  const countType = (t: PlanItem['type']) => items.filter((i) => i.type === t).length;
  addMat('mat-sock', 'Appareillage', 'Prise de courant 16 A + terre', countType('socket'), 'u', 'socket');
  addMat('mat-sock2', 'Appareillage', 'Double prise 16 A + terre', countType('socket2'), 'u', 'socket2');
  addMat('mat-usbsock', 'Appareillage', 'Prise 16 A + USB-C intégré', countType('usb_socket'), 'u', 'usb_socket');
  addMat('mat-spec', 'Appareillage', 'Prise spécialisée 20 A / Sortie de câble', countType('spec'), 'u', 'spec');
  addMat('mat-irve', 'Appareillage', 'Borne / Prise renforcée VE 32 A', countType('irve'), 'u', 'irve');
  addMat('mat-rj45', 'Appareillage', 'Prise RJ45 Cat. 6 / TV', countType('rj45'), 'u', 'rj45');
  addMat('mat-sw', 'Appareillage', 'Interrupteur simple / va-et-vient', countType('switch'), 'u', 'switch');
  addMat('mat-pb', 'Appareillage', 'Bouton poussoir lumineux', countType('pushbutton'), 'u', 'pushbutton');
  addMat('mat-dim', 'Appareillage', 'Variateur rotatif LED', countType('dimmer'), 'u', 'dimmer');
  addMat('mat-mot', 'Appareillage', 'Détecteur de mouvement mural', countType('motion'), 'u', 'motion');
  addMat('mat-light', 'Appareillage', 'Point DCL + luminaire plafonnier', countType('light'), 'u', 'light');
  addMat('mat-sconce', 'Appareillage', 'Applique murale', countType('sconce'), 'u', 'sconce');
  const totalSpots = items
    .filter((i) => i.type === 'spots')
    .reduce((sum, i) => sum + (i.count ?? 4), 0);
  addMat('mat-spots', 'Appareillage', 'Spot LED encastrable', totalSpots, 'u', 'spot');
  const neonMeters = Math.ceil(
    items.filter((i) => i.type === 'neon').reduce((sum, i) => sum + (i.len ?? 200), 0) / 100
  );
  addMat('mat-neon', 'Appareillage', 'Ruban / réglette LED', neonMeters, 'm', 'neon');
  const totalStairSteps = items
    .filter((i) => i.type === 'staircase')
    .reduce((sum, i) => sum + (i.stepCount ?? 14), 0);
  addMat('mat-stair-led', 'Appareillage', 'Profilé LED nez de marche escalier', totalStairSteps, 'u', 'stair_led');
  addMat('mat-heat', 'Appareillage', 'Radiateur électrique inertie', countType('heater'), 'u', 'heater');
  addMat('mat-ac-split', 'Appareillage', 'Unité intérieure Split Climatisation', countType('ac_split'), 'u', 'ac_split');
  addMat('mat-ac-out', 'Appareillage', 'Groupe extérieur Clim / PAC Inverter', countType('ac_outdoor'), 'u', 'ac_outdoor');
  addMat('mat-thermostat', 'Automatisme', 'Thermostat / Régulateur Climatisation', countType('thermostat'), 'u', 'thermostat');
  addMat('mat-cook', 'Appareillage', 'Plaque de cuisson induction', countType('cooktop'), 'u', 'cooktop');

  addMat('mat-smoke', 'Sécurité', 'Détecteur de fumée (DAAF EN 14604)', countType('smoke'), 'u', 'smoke');
  addMat('mat-cam', 'Sécurité', 'Caméra de surveillance IP PoE', countType('camera'), 'u', 'camera');
  addMat('mat-nvr', 'Sécurité', 'Écran Moniteur Vidéosurveillance NVR', countType('nvr_screen'), 'u', 'nvr_screen');
  addMat('mat-alarm', 'Sécurité', 'Centrale d’alarme connectée', countType('alarm_panel'), 'u', 'alarm_panel');
  addMat('mat-siren', 'Sécurité', 'Sirène intérieure / flash', countType('siren'), 'u', 'siren');
  addMat('mat-intercom', 'Sécurité', 'Visiophone / Interphone portier', countType('intercom'), 'u', 'intercom');

  return {
    sim: {
      circuits,
      itemCircuitColor,
      itemCircuitId,
      applianceLinks,
      unlinkedApplianceIds,
      roomReports,
      panel,
      totalInstalledW,
      totalActiveW,
      totalCurrentA,
    },
    materials,
  };
}
