import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { GLB_DEFS } from '../data/glbCatalog';

/**
 * Chargement unique + cache des GLB d'équipements.
 * - chaque fichier n'est téléchargé/parsé qu'une fois ; les instances sont des clones légers
 *   (géométries et matériaux partagés, marqués `userData.sharedGlb` pour ne jamais être libérés
 *   par le nettoyage de scène) ;
 * - tout échec est silencieux côté rendu : l'appelant reçoit `null` et garde son modèle procédural.
 */

const urls = import.meta.glob('../assets/glb/*.glb', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
const urlOf = (file: string): string | undefined => urls[`../assets/glb/${file}`];

const cache = new Map<string, THREE.Group>();
const failed = new Set<string>();
let loadPromise: Promise<void> | null = null;
let total = 0;

export type GlbStatus = 'idle' | 'loading' | 'ready' | 'partial';
let status: GlbStatus = 'idle';

export const glbStatus = (): GlbStatus => status;
export const glbFailedCount = (): number => failed.size;

function markShared(root: THREE.Object3D) {
  root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (!m.isMesh) return;
    m.geometry.userData.sharedGlb = true;
    const mats = Array.isArray(m.material) ? m.material : [m.material];
    mats.forEach((mat) => {
      mat.userData.sharedGlb = true;
    });
    m.castShadow = true;
    m.receiveShadow = true;
  });
}

export function loadGlbLibrary(): Promise<void> {
  if (loadPromise) return loadPromise;
  status = 'loading';
  const loader = new GLTFLoader();
  const files = Array.from(new Set(Object.values(GLB_DEFS).map((d) => d.file)));
  total = files.length;
  loadPromise = Promise.all(
    files.map(async (file) => {
      const url = urlOf(file);
      if (!url) {
        failed.add(file);
        return;
      }
      try {
        const gltf = await loader.loadAsync(url);
        markShared(gltf.scene);
        cache.set(file, gltf.scene);
      } catch (e) {
        failed.add(file);
        console.warn(`[GLB] échec de chargement de ${file} — rendu procédural conservé`, e);
      }
    })
  ).then(() => {
    status = failed.size ? 'partial' : 'ready';
  });
  return loadPromise;
}

/**
 * Instance d'un GLB (ou null si absent/échec → fallback procédural).
 * `plateColor` teinte le matériau nommé `plateMaterial` (cloné pour cette instance seulement).
 */
export function instantiateGlb(key: keyof typeof GLB_DEFS, plateColor?: THREE.Color): THREE.Group | null {
  const def = GLB_DEFS[key];
  const src = cache.get(def.file);
  if (!src) return null;
  const inst = src.clone(true);
  if (plateColor && def.plateMaterial) {
    inst.traverse((o) => {
      const m = o as THREE.Mesh;
      if (!m.isMesh) return;
      const mat = m.material as THREE.MeshStandardMaterial;
      if (mat.name === def.plateMaterial) {
        const c = mat.clone();
        c.color.copy(plateColor);
        c.userData.sharedGlb = false; // propre à l'instance : peut être libéré
        m.material = c;
      }
    });
  }
  return inst;
}

export { total as glbTotal };
