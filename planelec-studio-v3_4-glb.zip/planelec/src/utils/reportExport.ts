import { COMPANY } from '../data/company';
import { LOGO_DATA_URI } from './brand';
import { buildPlanSvg } from './planSvg';
import { frNum, SimulationOutput } from './electricalEngine';
import { formatFcfa } from './formatters';
import { MaterialRow, PlanProjectData } from '../types/planelec';
import { TYPES } from '../data/catalog';

export interface DocInfo {
  reference: string;
  client: string;
  site: string;
  validityDays: number;
  notes: string;
}

export const DEFAULT_DOC_INFO: DocInfo = {
  reference: '',
  client: '',
  site: '',
  validityDays: 30,
  notes:
    'Acompte de 50 % à la commande, solde à la réception des travaux.\nLes quantités de câbles incluent 10 % de marge de coupe.\nPrix estimatifs en FCFA, sous réserve de visite technique et de variation des cours du matériel.',
};

export interface ReportInput {
  project: PlanProjectData;
  sim: SimulationOutput;
  materials: MaterialRow[];
  vatRate: number;
  includeLabor: boolean;
  laborPerCircuit: number;
  doc: DocInfo;
  mode: 'dossier' | 'devis';
}

const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const today = () =>
  new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });

export function defaultReference(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `FALO-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}

const CSS = `
@page { size: A4; margin: 16mm 13mm 18mm 13mm;
  @bottom-left { content: "${COMPANY.name} · ${COMPANY.phones[0]} · ${COMPANY.email}"; font: 8pt Arial, sans-serif; color: #64748b; }
  @bottom-right { content: "Page " counter(page) " / " counter(pages); font: 8pt Arial, sans-serif; color: #64748b; }
}
@page :first { margin: 0; @bottom-left { content: none } @bottom-right { content: none } }
* { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
html, body { margin: 0; padding: 0; }
body { font-family: Inter, 'Segoe UI', Arial, Helvetica, sans-serif; color: #0f172a; font-size: 10pt; line-height: 1.45; background: #e5e7eb; }
.doc { max-width: 210mm; margin: 0 auto; background: #fff; }
.cover { height: 297mm; position: relative; overflow: hidden; color: #fff; page-break-after: always; break-after: page;
  background: radial-gradient(1200px 700px at 85% -10%, #14418a 0%, ${COMPANY.colors.navy} 45%, ${COMPANY.colors.navyDark} 100%); }
.cover::before { content: ""; position: absolute; right: -60mm; top: -40mm; width: 170mm; height: 170mm; border-radius: 50%; border: 18mm solid rgba(242,183,5,.13); }
.cover::after { content: ""; position: absolute; left: -40mm; bottom: 38mm; width: 110mm; height: 110mm; border-radius: 50%; border: 10mm solid rgba(255,255,255,.05); }
.cover .logo { position: absolute; left: 18mm; top: 20mm; width: 78mm; }
.cover .kicker { position: absolute; left: 18mm; top: 112mm; right: 18mm; }
.cover .kicker .eyebrow { display: inline-block; background: ${COMPANY.colors.gold}; color: ${COMPANY.colors.navyDark}; font-weight: 800; letter-spacing: .14em; font-size: 9pt; padding: 2mm 4mm; border-radius: 1.5mm; text-transform: uppercase; }
.cover h1 { font-size: 34pt; line-height: 1.08; margin: 7mm 0 3mm; font-weight: 800; letter-spacing: -.01em; }
.cover h1 span { color: ${COMPANY.colors.gold}; }
.cover .sub { font-size: 13pt; color: #cbd5e1; max-width: 140mm; }
.cover .meta { position: absolute; left: 18mm; right: 18mm; top: 170mm; display: grid; grid-template-columns: 1fr 1fr; gap: 5mm 10mm; border-top: 1.2mm solid ${COMPANY.colors.gold}; padding-top: 6mm; }
.cover .meta div b { display: block; font-size: 8pt; letter-spacing: .12em; text-transform: uppercase; color: ${COMPANY.colors.goldSoft}; margin-bottom: 1mm; font-weight: 700; }
.cover .meta div span { font-size: 12pt; font-weight: 600; }
.cover .contact { position: absolute; left: 0; right: 0; bottom: 0; background: rgba(4,18,44,.72); padding: 9mm 18mm; display: flex; justify-content: space-between; align-items: flex-end; gap: 10mm; border-top: 1mm solid ${COMPANY.colors.gold}; }
.cover .contact .big { font-size: 15pt; font-weight: 800; letter-spacing: .01em; }
.cover .contact small { display: block; color: #cbd5e1; font-size: 9pt; }
.cover .contact .base { color: ${COMPANY.colors.gold}; font-style: italic; font-weight: 600; font-size: 11pt; text-align: right; }
.sec { break-before: page; page-break-before: always; }
.sec:first-of-type { break-before: auto; page-break-before: auto; }
.band { background: linear-gradient(90deg, ${COMPANY.colors.navyDark}, ${COMPANY.colors.navy}); color: #fff; border-radius: 2mm; padding: 4mm 6mm; margin-bottom: 6mm; display: flex; align-items: center; justify-content: space-between; border-bottom: 1.2mm solid ${COMPANY.colors.gold}; }
.band img { height: 11mm; }
.band h2 { margin: 0; font-size: 15pt; font-weight: 800; letter-spacing: .01em; text-align: right; }
.band small { display: block; font-weight: 500; font-size: 8.5pt; color: ${COMPANY.colors.goldSoft}; }
h3 { font-size: 11pt; margin: 6mm 0 2.5mm; color: ${COMPANY.colors.navy}; border-left: 1.4mm solid ${COMPANY.colors.gold}; padding-left: 2.5mm; }
.kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 3mm; margin-bottom: 3mm; }
.kpi { border: .3mm solid #dbe3ee; border-radius: 2mm; padding: 3.2mm 3.6mm; background: #f8fafc; break-inside: avoid; }
.kpi b { display: block; font-size: 15pt; color: ${COMPANY.colors.navy}; font-weight: 800; }
.kpi span { font-size: 8pt; color: #64748b; text-transform: uppercase; letter-spacing: .06em; }
table { width: 100%; border-collapse: collapse; font-size: 8.8pt; }
thead { display: table-header-group; }
th { background: ${COMPANY.colors.navy}; color: #fff; text-align: left; padding: 2mm 2.4mm; font-weight: 700; font-size: 8pt; letter-spacing: .04em; text-transform: uppercase; }
td { padding: 1.9mm 2.4mm; border-bottom: .25mm solid #e2e8f0; vertical-align: top; }
tr { break-inside: avoid; }
tbody tr:nth-child(even) td { background: #f8fafc; }
.r { text-align: right; } .c { text-align: center; }
.mono { font-variant-numeric: tabular-nums; white-space: nowrap; }
.grp td { background: #fff7d6 !important; color: ${COMPANY.colors.navyDark}; font-weight: 800; border-bottom: .4mm solid ${COMPANY.colors.gold}; text-transform: uppercase; font-size: 8pt; letter-spacing: .06em; }
.sub td { background: #eef2f7 !important; font-weight: 700; }
.dot { display: inline-block; width: 2.6mm; height: 2.6mm; border-radius: 50%; margin-right: 1.6mm; vertical-align: -0.4mm; }
.ok { color: #047857; font-weight: 700; } .warn { color: #b45309; font-weight: 700; }
.plan { border: .3mm solid #cbd5e1; border-radius: 2mm; overflow: hidden; margin-bottom: 4mm; break-inside: avoid; }
.legend { display: flex; flex-wrap: wrap; gap: 1.6mm 5mm; font-size: 8pt; color: #334155; }
.totals { margin: 5mm 0 0 auto; width: 98mm; border: .3mm solid #cbd5e1; border-radius: 2mm; overflow: hidden; break-inside: avoid; }
.totals div { display: flex; justify-content: space-between; padding: 2.1mm 4mm; border-bottom: .25mm solid #e2e8f0; font-size: 9.5pt; }
.totals .ttc { background: ${COMPANY.colors.navy}; color: #fff; font-weight: 800; font-size: 12pt; border-bottom: 0; border-top: 1mm solid ${COMPANY.colors.gold}; }
.notes { white-space: pre-line; font-size: 9pt; color: #334155; border: .3mm dashed #cbd5e1; border-radius: 2mm; padding: 3mm 4mm; background: #f8fafc; }
.sign { display: grid; grid-template-columns: 1fr 1fr; gap: 8mm; margin-top: 8mm; break-inside: avoid; }
.sign div { border: .3mm solid #cbd5e1; border-radius: 2mm; height: 34mm; padding: 3mm 4mm; font-size: 8.5pt; color: #475569; }
.sign b { display: block; color: ${COMPANY.colors.navy}; margin-bottom: 1mm; }
.fine { font-size: 8pt; color: #64748b; margin-top: 4mm; }
.list { margin: 0; padding-left: 5mm; } .list li { margin: .6mm 0; }
.screen-bar { position: sticky; top: 0; z-index: 9; background: ${COMPANY.colors.navyDark}; color: #fff; padding: 8px 14px; display: flex; gap: 12px; align-items: center; font-size: 13px; }
.screen-bar button { background: ${COMPANY.colors.gold}; color: ${COMPANY.colors.navyDark}; border: 0; padding: 6px 12px; border-radius: 6px; font-weight: 700; cursor: pointer; }
@media print { body { background: #fff; } .doc { max-width: none; } .screen-bar { display: none; } }
@media screen { .doc { box-shadow: 0 6px 30px rgba(0,0,0,.18); margin: 14px auto; } .cover { height: 297mm; } .sec { padding: 14mm 13mm 6mm; } }
`;

function band(title: string, subtitle: string, info: ReportInput): string {
  return `<div class="band"><img src="${LOGO_DATA_URI}" alt="${COMPANY.name}"/><h2>${esc(title)}<small>${esc(subtitle)}</small></h2></div>`;
}

export function buildReportHtml(inp: ReportInput): string {
  const { project, sim, materials, vatRate, includeLabor, laborPerCircuit, doc, mode } = inp;
  const ref = doc.reference || defaultReference();
  const projectLine = doc.site || 'Installation électrique';
  const surface = sim.roomReports
    .filter((r) => r.room.type !== 'terrasse')
    .reduce((a, r) => a + r.areaM2, 0);
  const totalWarn = sim.roomReports.reduce((a, r) => a + r.warnCount, 0);
  const matTotal = materials.reduce((a, m) => a + m.total, 0);
  const labor = includeLabor ? sim.circuits.length * laborPerCircuit : 0;
  const totalHt = matTotal + labor;
  const tva = totalHt * (vatRate / 100);
  const ttc = totalHt + tva;
  const validUntil = new Date(Date.now() + doc.validityDays * 86400000).toLocaleDateString('fr-FR');
  const title = mode === 'devis' ? 'Devis estimatif' : 'Dossier d’installation électrique';
  const cableM = sim.circuits.reduce((s, c) => s + (c.lengthM ?? 0), 0) * 1.1;

  const cover = `
<section class="cover">
  <img class="logo" src="${LOGO_DATA_URI}" alt="${COMPANY.name}"/>
  <div class="kicker">
    <span class="eyebrow">${mode === 'devis' ? 'Devis' : 'Étude & chiffrage'} · ${esc(COMPANY.tagline.split('·')[1]?.trim() ?? 'Électricité')}</span>
    <h1>${mode === 'devis' ? 'Devis<br/><span>électricité</span> bâtiment' : 'Dossier<br/>d’installation <span>électrique</span>'}</h1>
    <div class="sub">${esc(projectLine)} — plans, circuits, tableau, matériel et chiffrage selon la norme NF C 15-100.</div>
  </div>
  <div class="meta">
    <div><b>Référence</b><span>${esc(ref)}</span></div>
    <div><b>Date</b><span>${today()}</span></div>
    <div><b>Client</b><span>${esc(doc.client || '—')}</span></div>
    <div><b>Chantier</b><span>${esc(doc.site || '—')}</span></div>
    <div><b>Établi par</b><span>${esc(COMPANY.engineer)}</span></div>
    <div><b>Validité</b><span>${doc.validityDays} jours · jusqu’au ${validUntil}</span></div>
  </div>
  <div class="contact">
    <div>
      <div class="big">${COMPANY.phones.join(' / ')}</div>
      <small>${COMPANY.email} · ${COMPANY.city}, ${COMPANY.district}</small>
    </div>
    <div class="base">${COMPANY.baseline}<small>${COMPANY.audience}</small></div>
  </div>
</section>`;

  // ---- Synthèse
  const synth = `
<section class="sec">
  ${band('Synthèse du projet', `${ref} · ${today()}`, inp)}
  <div class="kpis">
    <div class="kpi"><b>${frNum(surface, 1)} m²</b><span>Surface habitable</span></div>
    <div class="kpi"><b>${project.rooms.length}</b><span>Pièces · ${project.floors.length} niveau${project.floors.length > 1 ? 'x' : ''}</span></div>
    <div class="kpi"><b>${sim.circuits.length}</b><span>Circuits</span></div>
    <div class="kpi"><b>${project.subscriptionKva} kVA</b><span>Abonnement</span></div>
    <div class="kpi"><b>${frNum(sim.totalInstalledW / 1000, 1)} kW</b><span>Puissance installée</span></div>
    <div class="kpi"><b>${frNum(sim.totalCurrentA, 1)} A</b><span>Courant estimé (230 V)</span></div>
    <div class="kpi"><b>${sim.panel.recommendedRows} rangée${sim.panel.recommendedRows > 1 ? 's' : ''}</b><span>Coffret · ${sim.panel.totalModules} modules</span></div>
    <div class="kpi"><b>${frNum(cableM, 0)} m</b><span>Câblage (+10 %)</span></div>
  </div>
  <h3>Pièces et conformité</h3>
  <table>
    <thead><tr><th>Pièce</th><th>Niveau</th><th class="r">Surface</th><th class="r">Puissance</th><th>Contrôle NF C 15-100</th></tr></thead>
    <tbody>
    ${sim.roomReports
      .map(
        (r) => `<tr><td><b>${esc(r.room.name)}</b></td><td>${esc(r.floorName)}</td><td class="r mono">${frNum(r.areaM2, 1)} m²</td><td class="r mono">${frNum(r.powerW, 0)} W</td><td>${
          r.warnCount > 0
            ? `<span class="warn">⚠ ${r.warnCount} point${r.warnCount > 1 ? 's' : ''} à revoir</span>`
            : '<span class="ok">✓ Conforme</span>'
        }</td></tr>`
      )
      .join('')}
    </tbody>
  </table>
  ${
    totalWarn > 0
      ? `<h3>Points d’attention</h3><ul class="list">${sim.roomReports
          .flatMap((r) => r.checks.filter((c) => c.level === 'warn').map((c) => `<li><b>${esc(r.room.name)}</b> — ${esc(c.text)}</li>`))
          .join('')}</ul>`
      : '<p class="ok">✓ Aucun écart détecté sur les contrôles automatiques.</p>'
  }
</section>`;

  // ---- Plans
  const plans = project.floors
    .map((f) => {
      const p = buildPlanSvg(project, f.id, sim.itemCircuitColor);
      if (!p.svg) return '';
      const circuits = sim.circuits.filter((c) => c.chain.some((q) => (q.floorId ?? 0) === f.id));
      return `
<section class="sec">
  ${band(`Plan électrique · ${f.name}`, 'Implantation des équipements par circuit', inp)}
  <div class="plan">${p.svg}</div>
  <div class="legend">${circuits
    .map((c) => `<span><i class="dot" style="background:${c.color}"></i>${esc(c.name)}</span>`)
    .join('')}<span><i class="dot" style="background:#dc2626"></i>TD = tableau de distribution</span></div>
</section>`;
    })
    .join('');

  // ---- Circuits
  const circuitsSec = `
<section class="sec">
  ${band('Circuits & protections', 'Dimensionnement des lignes et des disjoncteurs', inp)}
  <table>
    <thead><tr><th>Circuit</th><th class="c">Points</th><th class="r">Puissance</th><th class="r">Courant</th><th class="c">Section</th><th class="c">Disjoncteur</th><th class="r">Longueur</th><th class="r">Chute U</th></tr></thead>
    <tbody>
    ${sim.circuits
      .map(
        (c) => `<tr><td><i class="dot" style="background:${c.color}"></i><b>${esc(c.name)}</b></td><td class="c">${c.points}</td><td class="r mono">${frNum(c.watts, 0)} W</td><td class="r mono">${frNum(c.currentA, 1)} A</td><td class="c mono">${frNum(c.sectionMm2, 1)} mm²</td><td class="c mono">${c.breakerA} A · Diff. ${c.diffType}</td><td class="r mono">${c.lengthM != null ? frNum(c.lengthM, 0) + ' m' : '—'}</td><td class="r mono">${c.dropPct != null ? frNum(c.dropPct, 1) + ' %' : '—'}</td></tr>`
      )
      .join('')}
    </tbody>
  </table>
  <h3>Tableau de distribution</h3>
  <div class="kpis" style="grid-template-columns:repeat(4,1fr)">
    <div class="kpi"><b>${sim.panel.agcpRatingA} A</b><span>Disjoncteur de branchement</span></div>
    <div class="kpi"><b>${sim.panel.rows.length}</b><span>Interrupteur(s) différentiel(s) 30 mA</span></div>
    <div class="kpi"><b>${sim.panel.hasSurgeProtector ? 'Oui' : 'Non'}</b><span>Parafoudre</span></div>
    <div class="kpi"><b>${sim.panel.totalModules}</b><span>Modules DIN</span></div>
  </div>
  <table>
    <thead><tr><th>Rangée</th><th>Différentiel</th><th>Circuits protégés</th></tr></thead>
    <tbody>
    ${sim.panel.rows
      .map(
        (r, i) => `<tr><td><b>Rangée ${i + 1}</b></td><td class="mono">Type ${r.type} · ${r.ratingA} A · ${r.sensitivityMa} mA</td><td>${r.circuits.map((c) => `<i class="dot" style="background:${c.color}"></i>${esc(c.name)} (${c.breakerA} A)`).join(' &nbsp; ')}</td></tr>`
      )
      .join('')}
    </tbody>
  </table>
</section>`;

  // ---- Devis
  const cats = Array.from(new Set(materials.map((m) => m.category)));
  let n = 0;
  const devisRows = cats
    .map((cat) => {
      const rows = materials.filter((m) => m.category === cat);
      const sub = rows.reduce((a, m) => a + m.total, 0);
      return `<tr class="grp"><td colspan="5">${esc(cat)}</td></tr>${rows
        .map(
          (m) => `<tr><td class="c">${++n}</td><td>${esc(m.label)}</td><td class="r mono">${frNum(m.quantity)} ${esc(m.unit)}</td><td class="r mono">${formatFcfa(m.unitPrice, false)}</td><td class="r mono"><b>${formatFcfa(m.total, false)}</b></td></tr>`
        )
        .join('')}<tr class="sub"><td></td><td class="r" colspan="3">Sous-total ${esc(cat)}</td><td class="r mono">${formatFcfa(sub, false)}</td></tr>`;
    })
    .join('');
  const laborRow = includeLabor
    ? `<tr class="grp"><td colspan="5">Main-d’œuvre</td></tr><tr><td class="c">${++n}</td><td>Pose : tirage, appareillage, raccordement tableau</td><td class="r mono">${sim.circuits.length} circuits</td><td class="r mono">${formatFcfa(laborPerCircuit, false)}</td><td class="r mono"><b>${formatFcfa(labor, false)}</b></td></tr>`
    : '';
  const devis = `
<section class="sec">
  ${band('Devis estimatif', `${ref} · valable jusqu’au ${validUntil}`, inp)}
  <table>
    <thead><tr><th class="c" style="width:9mm">N°</th><th>Désignation</th><th class="r">Quantité</th><th class="r">P.U. (FCFA HT)</th><th class="r">Total (FCFA HT)</th></tr></thead>
    <tbody>${devisRows}${laborRow}</tbody>
  </table>
  <div class="totals">
    <div><span>Fournitures HT</span><b class="mono">${formatFcfa(matTotal)}</b></div>
    ${includeLabor ? `<div><span>Main-d’œuvre HT</span><b class="mono">${formatFcfa(labor)}</b></div>` : ''}
    <div><span>Total HT</span><b class="mono">${formatFcfa(totalHt)}</b></div>
    <div><span>TVA ${frNum(vatRate, vatRate % 1 ? 2 : 0)} %</span><b class="mono">${formatFcfa(tva)}</b></div>
    <div class="ttc"><span>Total TTC</span><span class="mono">${formatFcfa(ttc)}</span></div>
  </div>
  <h3>Conditions</h3>
  <div class="notes">${esc(doc.notes)}</div>
  <div class="sign">
    <div><b>Le prestataire</b>${esc(COMPANY.name)}<br/>${esc(COMPANY.engineer)}<br/>Date et signature :</div>
    <div><b>Bon pour accord — Le client</b>${esc(doc.client || '')}<br/><br/>Date et signature (précédée de « Bon pour accord ») :</div>
  </div>
  <p class="fine">${esc(COMPANY.name)} — ${COMPANY.city}, ${COMPANY.district} — Tél. ${COMPANY.phones.join(' / ')} — ${COMPANY.email}. Document généré avec PlanÉlec Studio.</p>
</section>`;

  const body = mode === 'devis' ? cover + devis : cover + synth + plans + circuitsSec + devis;
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"/><title>${esc(title)} — ${esc(COMPANY.name)} — ${esc(ref)}</title><style>${CSS}</style></head><body>
<div class="screen-bar"><span>${esc(title)} · ${esc(ref)}</span><button onclick="window.print()">Imprimer / Enregistrer en PDF</button></div>
<div class="doc">${body}</div></body></html>`;
}

/** Imprime le HTML dans un cadre invisible (fonctionne aussi dans Electron). */
export function printHtml(html: string): void {
  const f = document.createElement('iframe');
  f.setAttribute('aria-hidden', 'true');
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
  document.body.appendChild(f);
  const d = f.contentDocument!;
  d.open();
  d.write(html);
  d.close();
  window.setTimeout(() => {
    try {
      f.contentWindow?.focus();
      f.contentWindow?.print();
    } finally {
      window.setTimeout(() => f.remove(), 2000);
    }
  }, 500);
}

export function previewHtml(html: string): void {
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.open();
  w.document.write(html);
  w.document.close();
}

export function itemLabel(t: keyof typeof TYPES): string {
  return TYPES[t].label;
}

const BUDGET_KEY = 'planelec.budget.v1';
const DOC_KEY = 'planelec.docinfo.v1';

export interface BudgetPrefs {
  vatRate: number;
  includeLabor: boolean;
  laborPerCircuit: number;
}
export const DEFAULT_BUDGET_PREFS: BudgetPrefs = { vatRate: 19.25, includeLabor: true, laborPerCircuit: 95000 };

export function loadBudgetPrefs(): BudgetPrefs {
  try {
    const raw = localStorage.getItem(BUDGET_KEY);
    if (raw) return { ...DEFAULT_BUDGET_PREFS, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...DEFAULT_BUDGET_PREFS };
}
export function saveBudgetPrefs(p: BudgetPrefs) {
  try {
    localStorage.setItem(BUDGET_KEY, JSON.stringify(p));
  } catch {
    /* ignore */
  }
}
export function loadDocInfo(): DocInfo {
  try {
    const raw = localStorage.getItem(DOC_KEY);
    if (raw) return { ...DEFAULT_DOC_INFO, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...DEFAULT_DOC_INFO };
}
export function saveDocInfo(d: DocInfo) {
  try {
    localStorage.setItem(DOC_KEY, JSON.stringify(d));
  } catch {
    /* ignore */
  }
}

export function downloadTextFile(filename: string, mime: string, content: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** Enveloppe un SVG existant dans un cadre FALO : bandeau logo en tête, cartouche en pied. */
export function brandSvg(innerSvg: string, viewBox: { w: number; h: number }, title: string, subtitle: string): string {
  const W = 1600;
  const planH = Math.round((W - 80) * (viewBox.h / viewBox.w));
  const headH = 150;
  const footH = 110;
  const H = headH + planH + footH + 60;
  const logoH = 100;
  const logoW = Math.round(logoH * (636 / 368));
  const date = new Date().toLocaleDateString('fr-FR');
  const inner = innerSvg
    .replace(/<svg\b([^>]*?)>/, (_m, attrs: string) => {
      const cleaned = attrs.replace(/\s(width|height|x|y)="[^"]*"/g, '');
      return `<svg ${cleaned} x="40" y="${headH + 20}" width="${W - 80}" height="${planH}">`;
    });
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="Inter, Arial, sans-serif">
<defs><linearGradient id="hg" x1="0" x2="1"><stop offset="0" stop-color="${COMPANY.colors.navyDark}"/><stop offset="1" stop-color="${COMPANY.colors.navy}"/></linearGradient></defs>
<rect width="${W}" height="${H}" fill="#ffffff"/>
<rect width="${W}" height="${headH}" fill="url(#hg)"/><rect y="${headH - 8}" width="${W}" height="8" fill="${COMPANY.colors.gold}"/>
<image href="${LOGO_DATA_URI}" x="40" y="${(headH - 8 - logoH) / 2}" width="${logoW}" height="${logoH}"/>
<text x="${W - 40}" y="68" text-anchor="end" font-size="40" font-weight="800" fill="#ffffff">${esc(title)}</text>
<text x="${W - 40}" y="105" text-anchor="end" font-size="22" fill="${COMPANY.colors.goldSoft}">${esc(subtitle)}</text>
<rect x="40" y="${headH + 20}" width="${W - 80}" height="${planH}" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
${inner}
<g transform="translate(0 ${headH + planH + 40})">
<rect x="40" width="${W - 80}" height="${footH}" rx="8" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2"/>
<rect x="40" width="10" height="${footH}" rx="4" fill="${COMPANY.colors.gold}"/>
<text x="72" y="40" font-size="24" font-weight="800" fill="${COMPANY.colors.navy}">${esc(COMPANY.name)} — ${esc(COMPANY.engineer)}</text>
<text x="72" y="72" font-size="19" fill="#334155">${COMPANY.phones.join(' / ')} · ${COMPANY.email} · ${COMPANY.city}, ${COMPANY.district}</text>
<text x="72" y="98" font-size="16" fill="#64748b">${esc(COMPANY.baseline)}</text>
<text x="${W - 72}" y="40" text-anchor="end" font-size="19" fill="#334155">Date : ${date}</text>
<text x="${W - 72}" y="72" text-anchor="end" font-size="16" fill="#64748b">Généré avec PlanÉlec Studio</text>
</g>
</svg>`;
}
