/**
 * Équipements associés automatiques (« IA de placement »).
 *
 * Quand on pose un équipement (clim, plafonnier, TV, lit, caméra…), les équipements
 * indispensables à son fonctionnement sont créés tout seuls à un endroit logique
 * (groupe extérieur sur la face externe du mur, interrupteur à côté de la porte,
 * prises derrière la TV, prises de chevet…). Ils suivent ensuite leur parent quand
 * on le déplace, jusqu'à ce que l'utilisateur en déplace un à la main (il est alors « détaché »).
 *
 * Tout est calculé par des fonctions pures à partir du projet : aucune dépendance à React ni à Three.
 */
import {
  ItemType,
  PlanItem,
  PlanProjectData,
  Room,
  WallSide,
} from '../types/planelec';
import { TYPES } from '../data/catalog';
import { edgeDist, inRoom, snap } from './electricalEngine';

const SIDES: WallSide[] = ['top', 'right', 'bottom', 'left'];
const ROT_OF: Record<WallSide, number> = { top: 0, right: 90, bottom: 180, left: -90 };

/** Hauteurs murales par défaut (cm) — identiques à snap3d.defaultWallElevationCm pour les types utilisés. */
const ELEV = {
  outdoor: 55,
  indoorSplit: 210,
  thermostat: 120,
  switch: 110,
  sockLow: 40,
  sockMid: 110,
  hood: 190,
  nvr: 148,
  camera: 222,
  siren: 235,
  bedside: 40,
} as const;

const SOCKET_TYPES: ItemType[] = ['socket', 'socket2', 'usb_socket'];
const CONTROLLER_TYPES: ItemType[] = ['switch', 'pushbutton', 'dimmer', 'motion'];

export const ROLE_LABEL: Record<string, string> = {
  outdoor: 'Groupe extérieur',
  indoor: 'Unité intérieure',
  thermo: 'Commande murale',
  switch: 'Interrupteur',
  sock: 'Prise',
  'sock-1': 'Prise',
  'sock-2': 'Prise',
  rj: 'Prise RJ45',
  hood: 'Prise hotte',
  'bed-L': 'Prise de chevet (gauche)',
  'bed-R': 'Prise de chevet (droite)',
  poe: 'Prise RJ45 PoE',
  nvr: 'Écran NVR',
  siren: 'Sirène extérieure',
};

/** Types d'équipements qui déclenchent des équipements associés. */
export const COMPANION_PARENT_TYPES: ReadonlySet<ItemType> = new Set<ItemType>([
  'ac_split',
  'ac_outdoor',
  'light',
  'spots',
  'neon',
  'sconce',
  'tv',
  'pc',
  'desk',
  'sofa',
  'fridge',
  'counter',
  'cooktop',
  'bed1',
  'bed2',
  'camera',
  'nvr_screen',
  'alarm_panel',
]);

/* ------------------------------------------------------------------ */
/* Géométrie des murs                                                  */
/* ------------------------------------------------------------------ */

const isHoriz = (s: WallSide) => s === 'top' || s === 'bottom';

function wallSpan(room: Room, side: WallSide): [number, number] {
  return isHoriz(side) ? [room.x, room.x + room.w] : [room.y, room.y + room.h];
}

function wallXY(room: Room, side: WallSide, along: number): { x: number; y: number } {
  switch (side) {
    case 'top':
      return { x: along, y: room.y };
    case 'bottom':
      return { x: along, y: room.y + room.h };
    case 'left':
      return { x: room.x, y: along };
    case 'right':
      return { x: room.x + room.w, y: along };
  }
}

function alongOf(side: WallSide, p: { x: number; y: number }): number {
  return isHoriz(side) ? p.x : p.y;
}

function outsideProbe(room: Room, side: WallSide, along: number, d = 30): { x: number; y: number } {
  switch (side) {
    case 'top':
      return { x: along, y: room.y - d };
    case 'bottom':
      return { x: along, y: room.y + room.h + d };
    case 'left':
      return { x: room.x - d, y: along };
    case 'right':
      return { x: room.x + room.w + d, y: along };
  }
}

/** Le côté `side` donne-t-il sur l'extérieur (aucune autre pièce de l'étage derrière) ? */
export function isExteriorSide(room: Room, side: WallSide, rooms: Room[]): boolean {
  const [a, b] = wallSpan(room, side);
  return ![0.2, 0.5, 0.8].some((f) => {
    const pt = outsideProbe(room, side, a + (b - a) * f);
    return rooms.some(
      (r) =>
        r.id !== room.id &&
        r.floorId === room.floorId &&
        r.type !== 'terrasse' &&
        inRoom(r, pt)
    );
  });
}

function nearestSide(room: Room, p: { x: number; y: number }, allowed: WallSide[] = SIDES): WallSide {
  let best: WallSide = allowed[0] ?? 'top';
  let bestD = Infinity;
  for (const s of allowed) {
    const d = edgeDist(room, s, p);
    if (d < bestD) {
      bestD = d;
      best = s;
    }
  }
  return best;
}

function elevOf(it: PlanItem): number {
  if (typeof it.elevationCm === 'number') return it.elevationCm;
  switch (it.type) {
    case 'socket':
    case 'socket2':
    case 'usb_socket':
    case 'rj45':
    case 'spec':
      return 35;
    case 'switch':
    case 'pushbutton':
    case 'dimmer':
    case 'motion':
      return 115;
    case 'thermostat':
      return 145;
    case 'ac_split':
    case 'siren':
      return 210;
    case 'ac_outdoor':
    case 'heater':
      return 55;
    case 'camera':
      return 222;
    default:
      return 110;
  }
}

/**
 * Cherche, sur un mur, la position libre la plus proche de `desired`
 * (évite les portes, fenêtres et autres appareils déjà présents à la même hauteur et sur la même face).
 */
function findFreeAlong(
  room: Room,
  side: WallSide,
  desired: number,
  type: ItemType,
  face: 'in' | 'out',
  elev: number,
  items: PlanItem[]
): number {
  const [a, b] = wallSpan(room, side);
  const halfW = TYPES[type].half ?? 16;
  const lo = a + halfW + 6;
  const hi = b - halfW - 6;
  if (lo > hi) return Math.round((a + b) / 2);

  const blockers = items.filter(
    (i) =>
      i.roomId === room.id &&
      i.side === side &&
      (TYPES[i.type].struct || ((i.face ?? 'in') === face && Math.abs(elevOf(i) - elev) < 45))
  );
  const isBlocked = (pos: number) =>
    blockers.some((i) => {
      const T = TYPES[i.type];
      const hw = T.struct ? (i.len ?? T.len ?? 90) / 2 + 12 : T.half ?? 16;
      return Math.abs(pos - alongOf(side, i)) < hw + halfW + 4;
    });

  const start = Math.min(hi, Math.max(lo, snap(desired, 5)));
  if (!isBlocked(start)) return start;
  for (let step = 10; step <= b - a; step += 10) {
    for (const cand of [start + step, start - step]) {
      if (cand >= lo && cand <= hi && !isBlocked(cand)) return cand;
    }
  }
  return start;
}

/** Un appareil du même genre est-il déjà à proximité de ce point du mur ? */
function hasNear(
  items: PlanItem[],
  types: ItemType[],
  room: Room,
  side: WallSide,
  along: number,
  radius: number,
  face: 'in' | 'out' = 'in',
  minElev = -Infinity,
  maxElev = Infinity
): boolean {
  return items.some(
    (i) =>
      types.includes(i.type) &&
      i.roomId === room.id &&
      i.side === side &&
      (i.face ?? 'in') === face &&
      Math.abs(alongOf(side, i) - along) <= radius &&
      elevOf(i) >= minElev &&
      elevOf(i) <= maxElev
  );
}

/** Une prise (au sens du moteur : même pièce, ≤ 250 cm) alimente-t-elle déjà cet appareil ? */
function appliancePowered(parent: PlanItem, items: PlanItem[]): boolean {
  return items.some(
    (i) =>
      SOCKET_TYPES.includes(i.type) &&
      i.roomId === parent.roomId &&
      Math.hypot(i.x - parent.x, i.y - parent.y) <= 220
  );
}

/* ------------------------------------------------------------------ */
/* Plan de placement                                                   */
/* ------------------------------------------------------------------ */

export interface PlannedCompanion {
  role: string;
  type: ItemType;
  roomId: number;
  floorId: number;
  x: number;
  y: number;
  side: WallSide;
  face: 'in' | 'out';
  rot: number;
  elevationCm: number;
  name: string;
  extra?: Partial<PlanItem>;
}

function wallPlan(
  room: Room,
  side: WallSide,
  desiredAlong: number,
  type: ItemType,
  role: string,
  elev: number,
  face: 'in' | 'out',
  items: PlanItem[],
  name = '',
  extra?: Partial<PlanItem>
): PlannedCompanion {
  const along = findFreeAlong(room, side, desiredAlong, type, face, elev, items);
  const pt = wallXY(room, side, along);
  return {
    role,
    type,
    roomId: room.id,
    floorId: room.floorId,
    x: pt.x,
    y: pt.y,
    side,
    face,
    rot: ROT_OF[side],
    elevationCm: elev,
    name,
    extra,
  };
}

/** Interrupteur placé à côté de la porte de la pièce (côté où il y a le plus de place). */
function doorSwitchPlan(room: Room, items: PlanItem[], role: string): PlannedCompanion {
  const door = items.find((i) => i.type === 'door' && i.roomId === room.id && i.side);
  if (door && door.side) {
    const side = door.side;
    const [a, b] = wallSpan(room, side);
    const dAlong = alongOf(side, door);
    const halfDoor = (door.len ?? TYPES.door.len ?? 90) / 2;
    const dir = dAlong - a > b - dAlong ? -1 : 1;
    return wallPlan(room, side, dAlong + dir * (halfDoor + 22), 'switch', role, ELEV.switch, 'in', items);
  }
  const [a] = wallSpan(room, 'top');
  return wallPlan(room, 'top', a + 35, 'switch', role, ELEV.switch, 'in', items);
}

function bestRoomForNvr(parentRoom: Room, parent: PlanItem, project: PlanProjectData): Room {
  if (parent.face !== 'out' && parent.camPlacement !== 'exterior') return parentRoom;
  const sameFloor = project.rooms.filter((r) => r.floorId === parentRoom.floorId);
  for (const t of ['bureau', 'sejour', 'couloir'] as const) {
    const r = sameFloor.find((x) => x.type === t);
    if (r) return r;
  }
  return parentRoom;
}

/** Calcule les équipements associés d'un parent, positionnés sur le projet courant. */
export function planCompanions(parent: PlanItem, project: PlanProjectData): PlannedCompanion[] {
  if (parent.autoOf !== undefined) return [];
  const room = project.rooms.find((r) => r.id === parent.roomId);
  if (!room) return [];
  // On ignore les compagnons du parent lui-même, sinon ils « satisfont » leurs propres conditions.
  const others = project.items.filter((i) => i.id !== parent.id && i.autoOf !== parent.id);
  const out: PlannedCompanion[] = [];
  const p = { x: parent.x, y: parent.y };

  const nearestWallOf = (pt: { x: number; y: number }) => {
    const side = nearestSide(room, pt);
    return { side, along: alongOf(side, pt) };
  };

  switch (parent.type) {
    /* ---------------- Climatisation ---------------- */
    case 'ac_split': {
      if (!parent.side) break;
      const exteriorSides = SIDES.filter((s) => isExteriorSide(room, s, project.rooms));
      const outSide = isExteriorSide(room, parent.side, project.rooms)
        ? parent.side
        : exteriorSides.length
        ? nearestSide(room, p, exteriorSides)
        : parent.side;
      out.push(
        wallPlan(
          room,
          outSide,
          alongOf(outSide, p),
          'ac_outdoor',
          'outdoor',
          ELEV.outdoor,
          'out',
          others,
          'Groupe ext.'
        )
      );
      if (!others.some((i) => i.type === 'thermostat' && i.roomId === room.id)) {
        const [a, b] = wallSpan(room, parent.side);
        const al = alongOf(parent.side, p);
        const dir = al - a > b - al ? -1 : 1;
        out.push(
          wallPlan(room, parent.side, al + dir * 80, 'thermostat', 'thermo', ELEV.thermostat, 'in', others)
        );
      }
      break;
    }
    case 'ac_outdoor': {
      if (!parent.side) break;
      if (others.some((i) => i.type === 'ac_split' && i.roomId === room.id)) break;
      out.push(
        wallPlan(
          room,
          parent.side,
          alongOf(parent.side, p),
          'ac_split',
          'indoor',
          ELEV.indoorSplit,
          'in',
          others,
          'Split'
        )
      );
      break;
    }

    /* ---------------- Éclairage ---------------- */
    case 'light':
    case 'spots':
    case 'neon':
    case 'sconce': {
      if (room.type === 'terrasse') break;
      if (parent.type === 'light' && parent.mountSurface === 'furniture') break;
      if (others.some((i) => CONTROLLER_TYPES.includes(i.type) && i.roomId === room.id)) break;
      out.push(doorSwitchPlan(room, others, 'switch'));
      break;
    }

    /* ---------------- Multimédia & bureautique ---------------- */
    case 'tv':
    case 'pc':
    case 'desk': {
      let side: WallSide;
      let along: number;
      let elev: number;
      if (parent.side && parent.mountSurface === 'wall') {
        side = parent.side;
        along = alongOf(side, p);
        elev = ELEV.sockMid;
      } else {
        ({ side, along } = nearestWallOf(p));
        elev = ELEV.sockLow;
      }
      const powered = parent.type !== 'desk' && appliancePowered(parent, others);
      if (!powered && !hasNear(others, SOCKET_TYPES, room, side, along, 90, 'in', elev - 60, elev + 60)) {
        out.push(wallPlan(room, side, along, 'socket2', 'sock', elev, 'in', others));
      }
      if (!hasNear(others, ['rj45'], room, side, along, 110, 'in', elev - 60, elev + 60)) {
        out.push(wallPlan(room, side, along + 40, 'rj45', 'rj', elev, 'in', others));
      }
      break;
    }
    case 'sofa': {
      const { side, along } = nearestWallOf(p);
      if (!hasNear(others, SOCKET_TYPES, room, side, along, 150, 'in', 0, 80)) {
        out.push(wallPlan(room, side, along, 'socket', 'sock', 35, 'in', others, 'Lampe canapé'));
      }
      break;
    }

    /* ---------------- Cuisine ---------------- */
    case 'fridge': {
      if (appliancePowered(parent, others)) break;
      const { side, along } = nearestWallOf(p);
      out.push(wallPlan(room, side, along, 'socket', 'sock', ELEV.sockMid, 'in', others, 'Frigo'));
      break;
    }
    case 'counter': {
      const { side, along } = nearestWallOf(p);
      const pts = [along - 70, along + 70];
      pts.forEach((al, idx) => {
        if (!hasNear(others, SOCKET_TYPES, room, side, al, 55, 'in', 90, 140)) {
          out.push(
            wallPlan(room, side, al, 'socket2', `sock-${idx + 1}`, ELEV.sockMid, 'in', others, 'Plan de travail')
          );
        }
      });
      break;
    }
    case 'cooktop': {
      if (!parent.side) break;
      const al = alongOf(parent.side, p);
      if (!hasNear(others, SOCKET_TYPES, room, parent.side, al, 70, 'in', 150, 230)) {
        out.push(wallPlan(room, parent.side, al, 'socket', 'hood', ELEV.hood, 'in', others, 'Hotte'));
      }
      break;
    }

    /* ---------------- Chambre : prises de chevet ---------------- */
    case 'bed1':
    case 'bed2': {
      const T = TYPES[parent.type];
      const bw = parent.w ?? T.w ?? 160;
      const bd = parent.h ?? T.h ?? 200;
      const rad = ((parent.rot || 0) * Math.PI) / 180;
      const head = { x: parent.x + Math.sin(rad) * (bd / 2), y: parent.y - Math.cos(rad) * (bd / 2) };
      const lat = { x: Math.cos(rad), y: Math.sin(rad) };
      const off = bw / 2 + 28;
      const pts = [
        { role: 'bed-L', pt: { x: head.x - lat.x * off, y: head.y - lat.y * off } },
        { role: 'bed-R', pt: { x: head.x + lat.x * off, y: head.y + lat.y * off } },
      ];
      const usable =
        parent.type === 'bed2'
          ? pts
          : [pts.reduce((best, cur) => {
              const dBest = Math.min(...SIDES.map((s) => edgeDist(room, s, best.pt)));
              const dCur = Math.min(...SIDES.map((s) => edgeDist(room, s, cur.pt)));
              return dCur < dBest ? cur : best;
            })];
      for (const { role, pt } of usable) {
        const side = nearestSide(room, pt);
        const al = alongOf(side, pt);
        if (!hasNear(others, [...SOCKET_TYPES], room, side, al, 60, 'in', 0, 90)) {
          out.push(wallPlan(room, side, al, 'usb_socket', role, ELEV.bedside, 'in', others, 'Chevet'));
        }
      }
      break;
    }

    /* ---------------- Sécurité & vidéosurveillance ---------------- */
    case 'camera': {
      if (!parent.side) break;
      const isExt = parent.face === 'out' || parent.camPlacement === 'exterior';
      const al = alongOf(parent.side, p);
      out.push(
        wallPlan(
          room,
          parent.side,
          isExt ? al : al + 30,
          'rj45',
          'poe',
          isExt ? Math.min(ELEV.camera, elevOf(parent)) : elevOf(parent),
          'in',
          others,
          'PoE'
        )
      );
      if (!project.items.some((i) => i.type === 'nvr_screen' && i.autoOf !== parent.id)) {
        const nvrRoom = bestRoomForNvr(room, parent, project);
        const longest = [...SIDES].sort((s1, s2) => {
          const [a1, b1] = wallSpan(nvrRoom, s1);
          const [a2, b2] = wallSpan(nvrRoom, s2);
          return b2 - a2 - (b1 - a1);
        })[0];
        const [na, nb] = wallSpan(nvrRoom, longest);
        const nvr = wallPlan(
          nvrRoom,
          longest,
          (na + nb) / 2,
          'nvr_screen',
          'nvr',
          ELEV.nvr,
          'in',
          project.items.filter((i) => i.autoOf !== parent.id),
          'NVR'
        );
        out.push(nvr);
      }
      break;
    }
    case 'nvr_screen': {
      if (!parent.side) break;
      const al = alongOf(parent.side, p);
      if (!hasNear(others, ['rj45'], room, parent.side, al, 90, 'in', 100, 200)) {
        out.push(wallPlan(room, parent.side, al + 45, 'rj45', 'rj', elevOf(parent) - 40, 'in', others));
      }
      break;
    }
    case 'alarm_panel': {
      if (others.some((i) => i.type === 'siren')) break;
      const exteriorSides = SIDES.filter((s) => isExteriorSide(room, s, project.rooms));
      if (exteriorSides.length === 0) break;
      const side = nearestSide(room, p, exteriorSides);
      out.push(wallPlan(room, side, alongOf(side, p), 'siren', 'siren', ELEV.siren, 'out', others));
      break;
    }
    default:
      break;
  }

  // Un même mur ne peut pas accueillir deux compagnons exactement au même endroit.
  for (let i = 0; i < out.length; i++) {
    for (let j = 0; j < i; j++) {
      const a = out[i];
      const b = out[j];
      if (a.roomId === b.roomId && a.side === b.side && a.face === b.face && Math.abs(a.elevationCm - b.elevationCm) < 45) {
        const shifted = findFreeAlong(
          project.rooms.find((r) => r.id === a.roomId) ?? room,
          a.side,
          alongOf(a.side, a) + 45,
          a.type,
          a.face,
          a.elevationCm,
          [...others, ...out.slice(0, i).map(plannedAsItem)]
        );
        const pt = wallXY(project.rooms.find((r) => r.id === a.roomId) ?? room, a.side, shifted);
        a.x = pt.x;
        a.y = pt.y;
      }
    }
  }
  return out;
}

function plannedAsItem(p: PlannedCompanion): PlanItem {
  return {
    id: -1,
    floorId: p.floorId,
    type: p.type,
    x: p.x,
    y: p.y,
    roomId: p.roomId,
    side: p.side,
    rot: p.rot,
    name: p.name,
    watts: 0,
    elevationCm: p.elevationCm,
    face: p.face,
  };
}

/* ------------------------------------------------------------------ */
/* Réconciliation après chaque modification du projet                  */
/* ------------------------------------------------------------------ */

const poseKey = (i: PlanItem) =>
  `${i.x}|${i.y}|${i.side}|${i.face ?? 'in'}|${i.roomId}|${i.floorId}|${i.rot}|${i.elevationCm ?? ''}|${i.mountSurface ?? ''}`;

export function companionsOf(parentId: number, items: PlanItem[]): PlanItem[] {
  return items.filter((i) => i.autoOf === parentId);
}

export interface ReconcileResult {
  project: PlanProjectData;
  added: PlanItem[];
  parent: PlanItem | null;
}

/**
 * Compare le projet avant / après une modification et applique la logique des équipements associés :
 *  1. supprime les compagnons dont le parent a disparu ;
 *  2. « détache » les compagnons déplacés à la main ;
 *  3. fait suivre les compagnons non détachés quand leur parent bouge ;
 *  4. crée les compagnons d'un équipement tout juste posé.
 */
export function reconcileCompanions(
  prev: PlanProjectData,
  next: PlanProjectData,
  allowCreate = true
): ReconcileResult {
  const noChange: ReconcileResult = { project: next, added: [], parent: null };
  if (prev === next || prev.items === next.items) return noChange;

  const prevById = new Map(prev.items.map((i) => [i.id, i]));
  const nextIds = new Set(next.items.map((i) => i.id));
  let items = next.items;
  let changed = false;

  // 1. Parents supprimés
  const removed = prev.items.filter((i) => !nextIds.has(i.id)).map((i) => i.id);
  if (removed.length > 0) {
    const drop = new Set(removed);
    const filtered = items.filter((i) => !(i.autoOf !== undefined && drop.has(i.autoOf) && !i.autoDetached));
    if (filtered.length !== items.length) {
      items = filtered;
      changed = true;
    }
  }

  // 2. Compagnons déplacés à la main → détachés
  const itemById = (arr: PlanItem[]) => new Map(arr.map((i) => [i.id, i]));
  let nextById = itemById(items);
  const parentMoved = (parentId: number) => {
    const a = prevById.get(parentId);
    const b = nextById.get(parentId);
    return Boolean(a && b && poseKey(a) !== poseKey(b));
  };
  const detached = items.map((c) => {
    if (c.autoOf === undefined || c.autoDetached) return c;
    const before = prevById.get(c.id);
    if (!before || poseKey(before) === poseKey(c)) return c;
    if (parentMoved(c.autoOf)) return c;
    if (removed.includes(c.autoOf)) return c;
    return { ...c, autoDetached: true };
  });
  if (detached.some((c, idx) => c !== items[idx])) {
    items = detached;
    changed = true;
    nextById = itemById(items);
  }

  // 3. Parents déplacés → les compagnons suivent
  const movedParents = items.filter(
    (i) => i.autoOf === undefined && prevById.has(i.id) && parentMoved(i.id) && COMPANION_PARENT_TYPES.has(i.type)
  );
  if (movedParents.length > 0) {
    const proj = { ...next, items };
    const patches = new Map<number, Partial<PlanItem>>();
    for (const parent of movedParents) {
      const planned = planCompanions(parent, proj);
      const existing = items.filter((c) => c.autoOf === parent.id && !c.autoDetached);
      for (const c of existing) {
        const pl = planned.find((x) => x.role === c.autoRole && x.type === c.type);
        if (!pl) continue;
        patches.set(c.id, {
          x: pl.x,
          y: pl.y,
          side: pl.side,
          face: pl.face,
          rot: pl.rot,
          elevationCm: pl.elevationCm,
          roomId: pl.roomId,
          floorId: pl.floorId,
        });
      }
    }
    if (patches.size > 0) {
      items = items.map((c) => (patches.has(c.id) ? { ...c, ...patches.get(c.id) } : c));
      changed = true;
    }
  }

  // 4. Nouveaux équipements → création de leurs compagnons
  let nextId = next.nextId;
  const added: PlanItem[] = [];
  let lastParent: PlanItem | null = null;
  const newItems = items.filter((i) => !prevById.has(i.id));
  const looksLikeEdit =
    newItems.length > 0 && newItems.length <= 3 && prev.rooms.length === next.rooms.length;
  if (allowCreate && looksLikeEdit) {
    const proj = { ...next, items };
    for (const parent of newItems) {
      if (parent.autoOf !== undefined || !COMPANION_PARENT_TYPES.has(parent.type)) continue;
      const planned = planCompanions(parent, { ...proj, items: [...items, ...added] });
      const have = new Set(items.filter((c) => c.autoOf === parent.id).map((c) => c.autoRole));
      for (const pl of planned) {
        if (have.has(pl.role)) continue;
        const id = nextId++;
        added.push({
          id,
          floorId: pl.floorId,
          type: pl.type,
          x: pl.x,
          y: pl.y,
          roomId: pl.roomId,
          side: pl.side,
          rot: pl.rot,
          name: pl.name,
          watts: TYPES[pl.type].watts,
          elevationCm: pl.elevationCm,
          mountSurface: 'wall',
          mountHostId: null,
          face: pl.face,
          autoOf: parent.id,
          autoRole: pl.role,
          ...(pl.extra ?? {}),
        });
        lastParent = parent;
      }
    }
  }

  if (!changed && added.length === 0) return noChange;
  return {
    project: {
      ...next,
      items: added.length > 0 ? [...items, ...added] : items,
      nextId,
    },
    added,
    parent: lastParent,
  };
}

/** Texte lisible pour la notification « N équipements ajoutés ». */
export function describeAdded(added: PlanItem[]): string {
  const names = added.map((a) => ROLE_LABEL[a.autoRole ?? ''] ?? TYPES[a.type].short);
  return names.join(', ');
}

/**
 * Replace tous les compagnons d'un parent à leur position logique (et les rattache).
 * À committer avec l'option { raw: true } pour ne pas les « détacher » par erreur.
 */
export function resnapCompanions(project: PlanProjectData, parentId: number): PlanProjectData {
  const parent = project.items.find((i) => i.id === parentId);
  if (!parent) return project;
  const planned = planCompanions(parent, project);
  const items = project.items.map((c) => {
    if (c.autoOf !== parentId) return c;
    const pl = planned.find((x) => x.role === c.autoRole && x.type === c.type);
    if (!pl) return { ...c, autoDetached: false };
    return {
      ...c,
      x: pl.x,
      y: pl.y,
      side: pl.side,
      face: pl.face,
      rot: pl.rot,
      elevationCm: pl.elevationCm,
      roomId: pl.roomId,
      floorId: pl.floorId,
      autoDetached: false,
    };
  });
  return { ...project, items };
}
