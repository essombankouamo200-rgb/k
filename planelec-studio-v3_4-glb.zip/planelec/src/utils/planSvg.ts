import { PlanItem, PlanProjectData, Room } from '../types/planelec';
import { ROOM_TYPES, TYPES } from '../data/catalog';

const ROOM_FILL: Record<string, string> = {
  chambre: '#eef2ff',
  sejour: '#fff7ed',
  cuisine: '#fefce8',
  sdb: '#ecfeff',
  wc: '#f0f9ff',
  couloir: '#f8fafc',
  bureau: '#f5f3ff',
  garage: '#f1f5f9',
  terrasse: '#ecfccb',
  autre: '#f8fafc',
};

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export interface PlanSvgResult {
  svg: string;
  width: number;
  height: number;
}

/** Plan d'étage propre et autonome (SVG), pour les exports : pièces, murs, portes, fenêtres, équipements colorés par circuit. */
export function buildPlanSvg(
  project: PlanProjectData,
  floorId: number,
  itemColor: Record<number, string>
): PlanSvgResult {
  const rooms = project.rooms.filter((r) => r.floorId === floorId);
  const items = project.items.filter((i) => i.floorId === floorId);
  if (rooms.length === 0) return { svg: '', width: 0, height: 0 };
  const pad = 70;
  const minX = Math.min(...rooms.map((r) => r.x)) - pad;
  const minY = Math.min(...rooms.map((r) => r.y)) - pad;
  const maxX = Math.max(...rooms.map((r) => r.x + r.w)) + pad;
  const maxY = Math.max(...rooms.map((r) => r.y + r.h)) + pad;
  const W = maxX - minX;
  const H = maxY - minY;
  const out: string[] = [];

  out.push(`<rect x="${minX}" y="${minY}" width="${W}" height="${H}" fill="#ffffff"/>`);
  // grille légère
  const g0x = Math.ceil(minX / 100) * 100;
  const g0y = Math.ceil(minY / 100) * 100;
  for (let x = g0x; x < maxX; x += 100) out.push(`<line x1="${x}" y1="${minY}" x2="${x}" y2="${maxY}" stroke="#eef2f7" stroke-width="1"/>`);
  for (let y = g0y; y < maxY; y += 100) out.push(`<line x1="${minX}" y1="${y}" x2="${maxX}" y2="${y}" stroke="#eef2f7" stroke-width="1"/>`);

  const fills = (r: Room) => ROOM_FILL[r.type] ?? '#f8fafc';
  for (const r of rooms) out.push(`<rect x="${r.x}" y="${r.y}" width="${r.w}" height="${r.h}" fill="${fills(r)}"/>`);

  // mobilier (contours)
  for (const it of items) {
    const T = TYPES[it.type];
    if (!T.furn || !it.w || !it.h) continue;
    out.push(
      `<g transform="translate(${it.x} ${it.y}) rotate(${it.rot || 0})"><rect x="${-it.w / 2}" y="${-it.h / 2}" width="${it.w}" height="${it.h}" rx="6" fill="#ffffff" stroke="#94a3b8" stroke-width="2" opacity=".95"/><text y="4" text-anchor="middle" font-size="13" fill="#94a3b8">${esc(T.label)}</text></g>`
    );
  }

  // murs
  const wt = project.rooms.length ? 10 : 10;
  for (const r of rooms) {
    out.push(
      `<rect x="${r.x}" y="${r.y}" width="${r.w}" height="${r.h}" fill="none" stroke="#1e293b" stroke-width="${r.type === 'terrasse' ? 3 : wt}" ${r.type === 'terrasse' ? 'stroke-dasharray="14 8"' : ''} stroke-linejoin="miter"/>`
    );
  }

  // portes et fenêtres
  const dirs = {
    top: { ix: 0, iy: 1, ax: 1, ay: 0 },
    bottom: { ix: 0, iy: -1, ax: 1, ay: 0 },
    left: { ix: 1, iy: 0, ax: 0, ay: 1 },
    right: { ix: -1, iy: 0, ax: 0, ay: 1 },
  } as const;
  for (const it of items) {
    if ((it.type !== 'door' && it.type !== 'window') || !it.side) continue;
    const d = dirs[it.side];
    const L = it.len ?? TYPES[it.type].len ?? 90;
    const sx = it.x - (d.ax * L) / 2;
    const sy = it.y - (d.ay * L) / 2;
    const ex = it.x + (d.ax * L) / 2;
    const ey = it.y + (d.ay * L) / 2;
    // ouverture dans le mur
    out.push(`<line x1="${sx}" y1="${sy}" x2="${ex}" y2="${ey}" stroke="#ffffff" stroke-width="${wt + 3}"/>`);
    if (it.type === 'window') {
      for (const o of [-3.5, 3.5]) {
        out.push(
          `<line x1="${sx + d.ix * o}" y1="${sy + d.iy * o}" x2="${ex + d.ix * o}" y2="${ey + d.iy * o}" stroke="#0284c7" stroke-width="2.2"/>`
        );
      }
      out.push(`<line x1="${sx}" y1="${sy}" x2="${ex}" y2="${ey}" stroke="#7dd3fc" stroke-width="2"/>`);
    } else {
      const lx = sx + d.ix * L;
      const ly = sy + d.iy * L;
      const cross = d.ix * d.ay - d.iy * d.ax;
      out.push(`<line x1="${sx}" y1="${sy}" x2="${lx}" y2="${ly}" stroke="#92400e" stroke-width="3.5" stroke-linecap="round"/>`);
      out.push(
        `<path d="M ${lx} ${ly} A ${L} ${L} 0 0 ${cross > 0 ? 1 : 0} ${ex} ${ey}" fill="none" stroke="#92400e" stroke-width="1.6" stroke-dasharray="5 4"/>`
      );
    }
  }

  // équipements
  const drawItem = (it: PlanItem) => {
    const T = TYPES[it.type];
    if (it.type === 'door' || it.type === 'window' || T.furn) return;
    const col = itemColor[it.id] ?? '#475569';
    let cx = it.x;
    let cy = it.y;
    if (it.side) {
      const d = dirs[it.side];
      cx += d.ix * 16;
      cy += d.iy * 16;
    }
    if (it.type === 'panel') {
      out.push(
        `<rect x="${cx - 16}" y="${cy - 16}" width="32" height="32" rx="4" fill="#dc2626" stroke="#7f1d1d" stroke-width="2"/><text x="${cx}" y="${cy + 5}" text-anchor="middle" font-size="14" font-weight="700" fill="#fff">TD</text>`
      );
      return;
    }
    if (it.type === 'neon' && it.len) {
      out.push(`<line x1="${cx - it.len / 2}" y1="${cy}" x2="${cx + it.len / 2}" y2="${cy}" stroke="${col}" stroke-width="7" stroke-linecap="round"/>`);
      return;
    }
    out.push(`<circle cx="${cx}" cy="${cy}" r="14" fill="#ffffff" stroke="${col}" stroke-width="4"/>`);
    out.push(
      `<text x="${cx}" y="${cy + 4}" text-anchor="middle" font-size="${T.short.length > 2 ? 9.5 : 12}" font-weight="700" fill="${col}">${esc(T.short)}</text>`
    );
  };
  items.forEach(drawItem);

  // noms de pièces
  for (const r of rooms) {
    const rt = ROOM_TYPES[r.type] ?? ROOM_TYPES.autre;
    void rt;
    out.push(
      `<text x="${r.x + 14}" y="${r.y + 28}" font-size="19" font-weight="700" fill="#0f172a">${esc(r.name)}</text><text x="${r.x + 14}" y="${r.y + 48}" font-size="14" fill="#64748b">${((r.w * r.h) / 10000).toFixed(1).replace('.', ',')} m²</text>`
    );
  }

  // échelle graphique 1 m
  out.push(
    `<g transform="translate(${minX + 24} ${maxY - 26})"><rect width="100" height="7" fill="#0f172a"/><rect x="50" width="50" height="7" fill="#fff" stroke="#0f172a" stroke-width="1.5"/><text y="-6" font-size="13" fill="#0f172a">0</text><text x="92" y="-6" font-size="13" fill="#0f172a">1 m</text></g>`
  );
  // flèche nord
  out.push(
    `<g transform="translate(${maxX - 40} ${minY + 52})"><circle r="22" fill="#fff" stroke="#cbd5e1" stroke-width="2"/><path d="M0 -16 L8 10 L0 5 L-8 10 Z" fill="#0b2a5b"/><text y="-26" text-anchor="middle" font-size="13" font-weight="700" fill="#0b2a5b">N</text></g>`
  );

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${minX} ${minY} ${W} ${H}" width="100%" font-family="Inter, Arial, sans-serif">${out.join('')}</svg>`;
  return { svg, width: W, height: H };
}
