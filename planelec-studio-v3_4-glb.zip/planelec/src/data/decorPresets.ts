import { EnvKind, EnvObject, GroundStyle, PlanProjectData } from '../types/planelec';
import { makeEnvObject } from './envCatalog';

/**
 * Décors extérieurs (clôtures, portail, arbres, allées, véhicules, lampadaires…) livrés avec
 * les modèles de bâtiments prédéfinis. Tout est exprimé en cm dans le repère du plan ; la
 * façade d'entrée est le côté bas (y max), comme pour l'ajout manuel d'objets d'environnement.
 */

type Enclosure = 'wall' | 'fence' | 'hedge' | 'none';

interface Box {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

interface Ctx {
  b: Box & { cx: number; cy: number };
  plot: Box;
  /** x du portail (axe de l'allée / de l'entrée). */
  gx: number;
  add: (kind: EnvKind, x: number, y: number, patch?: Partial<EnvObject>) => EnvObject;
}

interface Preset {
  ground: GroundStyle;
  /** marges parcelle autour du bâti : gauche, droite, fond, façade (cm) */
  margin: { l: number; r: number; back: number; front: number };
  enclosure: Enclosure;
  /** clôture de façade si différente */
  frontEnclosure?: Enclosure;
  gateLen?: number;
  /** décalage du portail par rapport au bord gauche du bâti (cm) ; défaut : centré */
  gateOffset?: number;
  /** largeur de l'allée principale (0 = aucune) */
  pathW?: number;
  extras: (c: Ctx) => void;
}

/* ---------- Jeux de décors ---------- */

/** Arbres/arbustes de coin de parcelle, façon "jardin tropical". */
const corners = (c: Ctx, kinds: EnvKind[], inset = 220) => {
  const { plot: p } = c;
  const pts: [number, number][] = [
    [p.x0 + inset, p.y0 + inset],
    [p.x1 - inset, p.y0 + inset],
    [p.x0 + inset, p.y1 - inset - 80],
    [p.x1 - inset, p.y1 - inset - 80],
  ];
  kinds.forEach((k, i) => {
    const [x, y] = pts[i % pts.length];
    c.add(k, x, y, { scale: k === 'bush' ? 1 : 0.95 + ((i * 37) % 30) / 100 });
  });
};

/** Lampadaires de part et d'autre de l'allée. */
const pathLights = (c: Ctx, n = 3) => {
  const { b, plot: p, gx } = c;
  const span = p.y1 - b.y1;
  for (let i = 0; i < n; i++) {
    const y = b.y1 + (span * (i + 0.6)) / (n + 0.2);
    c.add('garden_light', gx + (i % 2 ? 105 : -105), y);
  }
};

const PRESETS: Record<string, Preset> = {
  f2: {
    ground: 'terre',
    margin: { l: 300, r: 300, back: 300, front: 650 },
    enclosure: 'fence',
    gateLen: 300,
    gateOffset: 210,
    pathW: 110,
    extras: (c) => {
      const { b, plot: p } = c;
      c.add('tree', p.x1 - 200, p.y1 - 330, { name: 'Manguier', scale: 1.1 });
      c.add('bush', p.x0 + 120, p.y1 - 150);
      c.add('bush', p.x0 + 120, p.y1 - 260);
      c.add('bush', c.gx + 230, p.y1 - 140);
      { const lx0 = p.x0 + 120, lx1 = c.gx - 110; c.add('lawn', (lx0 + lx1) / 2, b.y1 + 330, { w: Math.max(150, lx1 - lx0), h: 260 }); }
      c.add('tank', p.x1 - 150, p.y0 + 150, { name: 'Citerne' });
      pathLights(c, 2);
    },
  },

  f3: {
    ground: 'herbe',
    margin: { l: 400, r: 450, back: 350, front: 850 },
    enclosure: 'wall',
    gateLen: 400,
    pathW: 120,
    extras: (c) => {
      const { b, plot: p } = c;
      corners(c, ['tree', 'palm', 'tree'], 240);
      c.add('hedge', p.x0 + 140 + 200, p.y1 - 140, { len: 400 });
      c.add('bush', b.x0 + 100, b.y1 + 120);
      c.add('bush', b.x0 + 260, b.y1 + 120);
      c.add('bush', b.x1 - 100, b.y1 + 120);
      c.add('car', c.gx + 380, p.y1 - 330, { rot: 90, name: 'Voiture (stationnement)' });
      c.add('generator', p.x1 - 160, p.y0 + 150, { name: 'Groupe électrogène' });
      pathLights(c, 3);
    },
  },

  f4: {
    ground: 'herbe',
    margin: { l: 400, r: 850, back: 350, front: 800 },
    enclosure: 'wall',
    gateLen: 400,
    gateOffset: 300,
    pathW: 130,
    extras: (c) => {
      const { b, plot: p } = c;
      // piscine à droite de la maison, entourée de plage
      c.add('pool', b.x1 + 450, b.y0 + 380, { w: 500, h: 250, name: 'Piscine' });
      c.add('palm', b.x1 + 130, b.y0 + 120);
      c.add('palm', b.x1 + 780, b.y0 + 130);
      c.add('palm', b.x1 + 780, b.y0 + 640);
      c.add('tree', p.x0 + 230, p.y0 + 230, { name: 'Manguier', scale: 1.2 });
      c.add('tree', p.x0 + 230, p.y1 - 280, { scale: 1.0 });
      c.add('hedge', b.x1 + 450, b.y0 + 760, { len: 600 });
      c.add('car', c.gx + 400, p.y1 - 330, { rot: 90, name: 'Voiture (stationnement)' });
      c.add('generator', p.x1 - 160, p.y0 + 140, { name: 'Groupe électrogène' });
      c.add('solar', p.x1 - 330, p.y1 - 160, { len: 340, rot: 0, name: 'Panneaux solaires' });
      pathLights(c, 3);
      c.add('garden_light', b.x1 + 130, b.y0 + 380);
    },
  },

  villa_r1: {
    ground: 'dalles',
    margin: { l: 450, r: 900, back: 400, front: 900 },
    enclosure: 'wall',
    gateLen: 500,
    gateOffset: 200, // face au garage
    pathW: 300, // allée carrossable
    extras: (c) => {
      const { b, plot: p } = c;
      c.add('car', c.gx, b.y1 + 330, { rot: 90, name: 'Voiture (garage)' });
      c.add('pool', b.x1 + 480, b.y0 + 380, { w: 550, h: 280, name: 'Piscine' });
      c.add('lawn', b.x1 + 480, b.y0 + 780, { w: 550, h: 260 });
      c.add('palm', b.x1 + 120, b.y0 + 110);
      c.add('palm', b.x1 + 830, b.y0 + 110);
      c.add('palm', b.x1 + 830, b.y0 + 700);
      c.add('tree', p.x0 + 230, p.y0 + 230, { name: 'Manguier', scale: 1.25 });
      c.add('tree', p.x0 + 230, p.y1 - 300, { scale: 1.1 });
      c.add('bush', b.x1 + 150, b.y1 + 120);
      c.add('bush', b.x1 + 320, b.y1 + 120);
      c.add('bush', b.x1 + 490, b.y1 + 120);
      c.add('tank', p.x1 - 160, p.y0 + 160, { name: 'Château d’eau' });
      c.add('generator', p.x1 - 160, p.y0 + 380, { name: 'Groupe électrogène' });
      c.add('solar', b.cx, p.y0 + 140, { len: 510, name: 'Panneaux solaires' });
      c.add('garden_light', c.gx - 190, b.y1 + 200);
      c.add('garden_light', c.gx + 190, b.y1 + 200);
      c.add('garden_light', c.gx - 190, b.y1 + 560);
      c.add('garden_light', c.gx + 190, b.y1 + 560);
      c.add('garden_light', b.x1 + 130, b.y0 + 380);
    },
  },

  duplex: {
    ground: 'herbe',
    margin: { l: 400, r: 400, back: 350, front: 800 },
    enclosure: 'wall',
    frontEnclosure: 'hedge',
    gateLen: 400,
    gateOffset: 350,
    pathW: 120,
    extras: (c) => {
      const { b, plot: p } = c;
      corners(c, ['tree', 'tree'], 230);
      c.add('palm', p.x1 - 230, p.y1 - 300);
      c.add('bush', b.x0 + 100, b.y1 + 110);
      c.add('bush', b.x0 + 260, b.y1 + 110);
      c.add('bush', b.x1 - 260, b.y1 + 110);
      c.add('car', c.gx + 400, p.y1 - 330, { rot: 90, name: 'Voiture (stationnement)' });
      pathLights(c, 3);
    },
  },

  boutique: {
    ground: 'dalles',
    margin: { l: 250, r: 250, back: 250, front: 950 },
    enclosure: 'fence',
    frontEnclosure: 'none', // façade commerciale ouverte sur la rue
    pathW: 0,
    extras: (c) => {
      const { b, plot: p } = c;
      // parvis + parking client
      c.add('path', b.cx, b.y1 + 250, { len: b.x1 - b.x0, w: 300, name: 'Parvis' });
      c.add('car', b.x0 + 220, p.y1 - 350, { rot: 90, name: 'Voiture client' });
      c.add('car', b.x0 + 480, p.y1 - 350, { rot: 90, name: 'Voiture client' });
      c.add('palm', p.x0 + 150, p.y1 - 120);
      c.add('palm', p.x1 - 150, p.y1 - 120);
      c.add('garden_light', b.x0 + 80, b.y1 + 420);
      c.add('garden_light', b.cx, b.y1 + 420);
      c.add('garden_light', b.x1 - 80, b.y1 + 420);
      c.add('generator', p.x1 - 130, p.y0 + 140, { name: 'Groupe électrogène' });
    },
  },

  bureaux: {
    ground: 'dalles',
    margin: { l: 350, r: 350, back: 300, front: 1050 },
    enclosure: 'wall',
    gateLen: 500,
    pathW: 160,
    extras: (c) => {
      const { b, plot: p } = c;
      // parking de 4 places à gauche de l'allée
      for (let i = 0; i < 4; i++) c.add('car', b.x0 + 150 + i * 280, p.y1 - 420, { rot: 90, name: `Parking ${i + 1}` });
      c.add('tree', p.x0 + 220, p.y0 + 220, { scale: 1.1 });
      c.add('tree', p.x1 - 220, p.y0 + 220, { scale: 1.1 });
      c.add('palm', p.x1 - 230, p.y1 - 300);
      c.add('bush', b.x0 + 100, b.y1 + 110);
      c.add('bush', b.x1 - 100, b.y1 + 110);
      c.add('generator', p.x1 - 140, p.y0 + 420, { name: 'Groupe électrogène' });
      c.add('solar', b.cx, p.y0 + 130, { len: 680, name: 'Panneaux solaires' });
      pathLights(c, 4);
      c.add('garden_light', b.x0 + 100, p.y1 - 150);
      c.add('garden_light', b.x0 + 860, p.y1 - 150);
    },
  },

  bungalow: {
    ground: 'terre',
    margin: { l: 450, r: 450, back: 400, front: 750 },
    enclosure: 'fence',
    gateLen: 350,
    gateOffset: 230,
    pathW: 110,
    extras: (c) => {
      const { b, plot: p } = c;
      c.add('tree', p.x0 + 260, p.y0 + 260, { name: 'Manguier', scale: 1.4 });
      c.add('tree', p.x1 - 260, p.y1 - 330, { name: 'Manguier', scale: 1.2 });
      c.add('palm', p.x0 + 200, p.y1 - 280);
      c.add('palm', p.x1 - 220, p.y0 + 240);
      c.add('bush', b.x0 + 90, b.y1 + 110);
      c.add('bush', b.x0 + 230, b.y1 + 110);
      c.add('bush', b.x1 - 100, b.y1 + 110);
      c.add('hedge', b.x1 + 220, b.y0 + 60, { len: 300, rot: 90 });
      { const lx0 = p.x0 + 120, lx1 = c.gx - 110; c.add('lawn', (lx0 + lx1) / 2, b.y1 + 330, { w: Math.max(150, lx1 - lx0), h: 280 }); }
      c.add('tank', p.x1 - 160, p.y0 + 160, { name: 'Château d’eau' });
      pathLights(c, 2);
    },
  },

  /** Maison R+1 d'exemple (modèle par défaut / T3). */
  house: {
    ground: 'herbe',
    margin: { l: 400, r: 450, back: 350, front: 800 },
    enclosure: 'wall',
    gateLen: 400,
    pathW: 120,
    extras: (c) => {
      const { b, plot: p } = c;
      corners(c, ['tree', 'palm', 'tree'], 240);
      c.add('bush', b.x0 + 100, b.y1 + 110);
      c.add('bush', b.x1 - 100, b.y1 + 110);
      c.add('car', c.gx + 400, p.y1 - 330, { rot: 90, name: 'Voiture (stationnement)' });
      c.add('generator', p.x1 - 160, p.y0 + 150, { name: 'Groupe électrogène' });
      pathLights(c, 3);
    },
  },

  studio: {
    ground: 'dalles',
    margin: { l: 250, r: 250, back: 250, front: 550 },
    enclosure: 'fence',
    gateLen: 300,
    pathW: 100,
    extras: (c) => {
      const { plot: p } = c;
      c.add('tree', p.x1 - 180, p.y0 + 180, { scale: 0.9 });
      c.add('bush', p.x0 + 110, p.y1 - 140);
      c.add('bush', p.x1 - 110, p.y1 - 140);
      pathLights(c, 2);
    },
  },
};

/* ---------- Génération ---------- */

function segment(
  c: Ctx,
  kind: Enclosure,
  ax: number,
  ay: number,
  bx: number,
  by: number
): void {
  if (kind === 'none') return;
  const len = Math.hypot(bx - ax, by - ay);
  if (len < 40) return;
  c.add(kind, (ax + bx) / 2, (ay + by) / 2, { len, rot: (Math.atan2(by - ay, bx - ax) * 180) / Math.PI });
}

/** Retourne les décors (objets + style de sol) d'un modèle, ou null si le modèle est inconnu. */
export function buildDecor(
  presetId: string,
  project: Pick<PlanProjectData, 'rooms'>
): { env: EnvObject[]; groundStyle: GroundStyle } | null {
  const preset = PRESETS[presetId];
  if (!preset) return null;
  const ground = project.rooms.filter((r) => r.floorId === 0);
  const rooms = ground.length ? ground : project.rooms;
  if (!rooms.length) return null;

  const x0 = Math.min(...rooms.map((r) => r.x));
  const y0 = Math.min(...rooms.map((r) => r.y));
  const x1 = Math.max(...rooms.map((r) => r.x + r.w));
  const y1 = Math.max(...rooms.map((r) => r.y + r.h));
  const b = { x0, y0, x1, y1, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
  const m = preset.margin;
  const plot: Box = { x0: x0 - m.l, y0: y0 - m.back, x1: x1 + m.r, y1: y1 + m.front };
  const gateLen = preset.gateLen ?? 400;
  const gx = preset.gateOffset != null ? x0 + preset.gateOffset : b.cx;

  const env: EnvObject[] = [];
  const ctx: Ctx = {
    b,
    plot,
    gx,
    add: (kind, x, y, patch = {}) => {
      const o = { ...makeEnvObject(kind, env.length + 1, x, y), ...patch };
      env.push(o);
      return o;
    },
  };

  // Clôture : fond, côtés, façade (avec portail)
  const front = preset.frontEnclosure ?? preset.enclosure;
  segment(ctx, preset.enclosure, plot.x0, plot.y0, plot.x1, plot.y0);
  segment(ctx, preset.enclosure, plot.x0, plot.y0, plot.x0, plot.y1);
  segment(ctx, preset.enclosure, plot.x1, plot.y0, plot.x1, plot.y1);
  if (front !== 'none') {
    segment(ctx, front, plot.x0, plot.y1, gx - gateLen / 2, plot.y1);
    segment(ctx, front, gx + gateLen / 2, plot.y1, plot.x1, plot.y1);
    ctx.add('gate', gx, plot.y1, { len: gateLen, name: 'Portail d’entrée' });
  }

  // Allée principale du portail à la façade
  if (preset.pathW) {
    const len = plot.y1 - y1;
    ctx.add('path', gx, y1 + len / 2, { len, w: preset.pathW, rot: 90, name: 'Allée' });
  }

  preset.extras(ctx);
  return { env, groundStyle: preset.ground };
}

/** Ajoute les décors d'un modèle à un projet (sans écraser un environnement déjà présent). */
export function withDecor(project: PlanProjectData, presetId: string): PlanProjectData {
  if (project.env && project.env.length) return project;
  const d = buildDecor(presetId, project);
  return d ? { ...project, env: d.env, groundStyle: d.groundStyle } : project;
}
