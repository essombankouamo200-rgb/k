/** Identité de l'entreprise, reprise dans l'en-tête de l'app et dans tous les exports. */
export const COMPANY = {
  name: 'FALO FINITION BTP',
  tagline: 'Carrelage · Électricité bâtiment & industrielle',
  baseline: 'Expertise · Qualité · Sécurité',
  engineer: 'Ingénieur Martial Loïc',
  phones: ['658 959 484', '651 182 384'],
  email: 'fanzoumartial@gmail.com',
  city: 'Yaoundé',
  district: 'Quartier : Nkolfesson',
  audience: 'Particuliers · Entreprises · Chantiers',
  services: [
    'Installation électrique complète',
    'Tableaux électriques',
    'Éclairage',
    'Prises et interrupteurs',
    'Dépannage',
    'Réseaux, armoires, câblage et maintenance industriels',
  ],
  colors: { navy: '#0b2a5b', navyDark: '#071d42', gold: '#f2b705', goldSoft: '#fbe08a' },
} as const;
