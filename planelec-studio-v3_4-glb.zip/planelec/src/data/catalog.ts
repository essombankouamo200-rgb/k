import {
  FinishStyle,
  FloorFinishId,
  FloorLevel,
  ItemType,
  LibraryCategory,
  LibraryComponentDef,
  ManualNode,
  ManualWire,
  PlanItem,
  PlanProjectData,
  Room,
  RoomType,
  ToolTabId,
  WallFinishId,
  WallSide,
} from '../types/planelec';

export interface ItemTypeDef {
  label: string;
  short: string;
  place: 'ceil' | 'wall' | 'floor';
  watts: number;
  power?: boolean;
  family?: 'light' | 'spot' | 'neon';
  half?: number;
  len?: number;
  struct?: boolean;
  furn?: boolean;
  w?: number;
  h?: number;
  appl?: boolean;
  outlets?: number;
  surveillance?: boolean;
}

export const CIRCUIT_PALETTE = [
  '#d97706',
  '#2563eb',
  '#7c3aed',
  '#059669',
  '#db2777',
  '#0891b2',
  '#dc2626',
  '#4f46e5',
  '#65a30d',
  '#ea580c',
];

export const FINISH_STYLES: Record<
  FinishStyle,
  { label: string; frameHex: string; plateHex: string; accentHex: string }
> = {
  blanc_mat: {
    label: 'Blanc Mat Architecte',
    frameHex: '#f8fafc',
    plateHex: '#e2e8f0',
    accentHex: '#0f172a',
  },
  anthracite: {
    label: 'Anthracite Brossé',
    frameHex: '#1e293b',
    plateHex: '#334155',
    accentHex: '#f8fafc',
  },
  laiton: {
    label: 'Laiton & Champagne',
    frameHex: '#d4af37',
    plateHex: '#fef3c7',
    accentHex: '#78350f',
  },
  alu: {
    label: 'Aluminium Industriel',
    frameHex: '#94a3b8',
    plateHex: '#cbd5e1',
    accentHex: '#0f172a',
  },
};

export const WALL_FINISHES: {
  id: WallFinishId;
  label: string;
  group: 'Peinture' | 'Carrelage' | 'Matière';
  hex: string;
  groutHex?: string;
}[] = [
  { id: 'peinture_blanche', label: 'Peinture Blanc Pur', group: 'Peinture', hex: '#f1f5f9' },
  { id: 'peinture_lin', label: 'Peinture Lin Chaud', group: 'Peinture', hex: '#ece3d5' },
  { id: 'peinture_sauge', label: 'Peinture Vert Sauge', group: 'Peinture', hex: '#cbd8cc' },
  { id: 'peinture_terracotta', label: 'Peinture Terracotta', group: 'Peinture', hex: '#d89b84' },
  { id: 'peinture_bleu_nuit', label: 'Peinture Bleu Nuit', group: 'Peinture', hex: '#334e68' },
  { id: 'carrelage_blanc', label: 'Carrelage Faïence Blanc', group: 'Carrelage', hex: '#f8fafc', groutHex: '#cbd5e1' },
  { id: 'carrelage_marbre', label: 'Carrelage Marbre Veinée', group: 'Carrelage', hex: '#e8ecf1', groutHex: '#94a3b8' },
  { id: 'carrelage_ardoise', label: 'Carrelage Ardoise Foncé', group: 'Carrelage', hex: '#475569', groutHex: '#1e293b' },
  { id: 'brique', label: 'Parement Brique', group: 'Matière', hex: '#b86b52', groutHex: '#d6cfc7' },
];

export const FLOOR_FINISHES: {
  id: FloorFinishId;
  label: string;
  hex: string;
}[] = [
  { id: 'auto', label: 'Automatique (selon pièce)', hex: '#e2e8f0' },
  { id: 'parquet_chene', label: 'Parquet Chêne Clair', hex: '#d9c3a3' },
  { id: 'parquet_noyer', label: 'Parquet Noyer Foncé', hex: '#8b6545' },
  { id: 'carrelage_gris', label: 'Carrelage Grès Gris', hex: '#cbd5e1' },
  { id: 'carrelage_travertin', label: 'Carrelage Travertin', hex: '#e6dcc8' },
  { id: 'beton_cire', label: 'Béton Ciré', hex: '#94a3b8' },
];

const F = (
  label: string,
  short: string,
  w: number,
  h: number,
  watts = 0,
  appl = false
): ItemTypeDef => ({
  label,
  short,
  place: 'floor',
  furn: true,
  w,
  h,
  watts,
  appl,
});

export const TYPES: Record<ItemType, ItemTypeDef> = {
  light: { label: 'Plafonnier', short: 'Plafonnier', place: 'ceil', watts: 100, power: true, family: 'light' },
  sconce: { label: 'Applique murale', short: 'Applique', place: 'wall', watts: 40, power: true, family: 'light' },
  spots: { label: 'Rangée de spots', short: 'Spots', place: 'ceil', watts: 7, power: true, family: 'spot' },
  neon: { label: 'Néon / ruban LED', short: 'Néon LED', place: 'ceil', watts: 0, power: true, family: 'neon' },
  switch: { label: 'Interrupteur', short: 'Interr.', place: 'wall', watts: 0 },
  pushbutton: { label: 'Bouton poussoir (télérupteur)', short: 'Poussoir', place: 'wall', watts: 0 },
  dimmer: { label: 'Variateur rotatif', short: 'Variateur', place: 'wall', watts: 0 },
  motion: { label: 'Détecteur présence', short: 'Détect. mvt', place: 'wall', watts: 0 },
  socket: { label: 'Prise 16 A', short: 'Prise 16 A', place: 'wall', watts: 150, power: true, outlets: 1 },
  socket2: { label: 'Double prise 16 A', short: 'Prise ×2', place: 'wall', watts: 250, power: true, outlets: 2, half: 22 },
  usb_socket: { label: 'Prise 16 A + USB-C', short: 'Prise USB-C', place: 'wall', watts: 180, power: true, outlets: 1, half: 18 },
  spec: { label: 'Prise spécialisée 20 A', short: 'Spécialisée', place: 'wall', watts: 2000, power: true },
  irve: { label: 'Borne / Prise VE 32 A', short: 'Borne VE', place: 'wall', watts: 7400, power: true, half: 28 },
  rj45: { label: 'Prise RJ45 / TV', short: 'RJ45 / TV', place: 'wall', watts: 0 },
  heater: { label: 'Radiateur électrique', short: 'Radiateur', place: 'wall', watts: 1500, power: true, half: 41 },
  ac_split: { label: 'Split Climatisation (Int.)', short: 'Clim Split', place: 'wall', watts: 1500, power: true, half: 42 },
  ac_outdoor: { label: 'Groupe Extérieur Clim (PAC)', short: 'Groupe Clim', place: 'wall', watts: 2200, power: true, half: 44 },
  thermostat: { label: 'Thermostat / Commande Clim', short: 'Thermostat', place: 'wall', watts: 0 },
  cooktop: { label: 'Plaque de cuisson 32 A', short: 'Plaque 32 A', place: 'wall', watts: 6000, power: true, half: 36 },
  smoke: { label: 'Détecteur de fumée', short: 'DAAF', place: 'ceil', watts: 0, surveillance: true },
  camera: { label: 'Caméra surveillance IP', short: 'Caméra IP', place: 'wall', watts: 15, power: true, surveillance: true },
  nvr_screen: { label: 'Écran Moniteur Caméras NVR', short: 'Écran NVR', place: 'wall', watts: 25, power: true, surveillance: true, half: 28 },
  alarm_panel: { label: 'Centrale d’alarme', short: 'Alarme', place: 'wall', watts: 25, power: true, surveillance: true, half: 20 },
  siren: { label: 'Sirène d’alarme', short: 'Sirène', place: 'wall', watts: 15, power: true, surveillance: true },
  intercom: { label: 'Visiophone / Interphone', short: 'Visiophone', place: 'wall', watts: 12, power: true, surveillance: true },
  panel: { label: 'Tableau électrique', short: 'Tableau', place: 'wall', watts: 0, half: 26 },
  door: { label: 'Porte', short: 'Porte', place: 'wall', watts: 0, len: 90, struct: true },
  window: { label: 'Fenêtre', short: 'Fenêtre', place: 'wall', watts: 0, len: 120, struct: true },
  staircase: { label: 'Escalier lumineux LED', short: 'Escalier LED', place: 'floor', watts: 0, power: true, w: 100, h: 280 },
  bed1: F('Lit 1 place', 'Lit 1 pl.', 90, 190),
  bed2: F('Lit double', 'Lit double', 160, 200),
  sofa: F('Canapé', 'Canapé', 200, 90),
  table: F('Table', 'Table', 140, 80),
  desk: F('Bureau', 'Bureau', 140, 70),
  wardrobe: F('Armoire', 'Armoire', 120, 60),
  tv: F('Télévision', 'TV', 110, 12, 120, true),
  fridge: F('Réfrigérateur', 'Frigo', 60, 65, 150, true),
  pc: F('Poste informatique', 'PC', 80, 40, 200, true),
  counter: F('Plan de travail', 'Plan travail', 240, 60),
  bath: F('Baignoire', 'Baignoire', 170, 70),
  shower: F('Douche', 'Douche', 90, 90),
  sink: F('Lavabo', 'Lavabo', 60, 50),
  wc: F('WC', 'WC', 40, 70),
};

export const TOOL_TABS: { id: ToolTabId; label: string; tools: ItemType[] }[] = [
  { id: 'pieces', label: 'Pièces & Escalier', tools: ['door', 'window', 'staircase'] },
  { id: 'eclairage', label: 'Éclairage & Commandes', tools: ['light', 'spots', 'sconce', 'neon', 'switch', 'pushbutton', 'dimmer', 'motion'] },
  { id: 'prises', label: 'Prises, Clim & Puissance', tools: ['socket', 'socket2', 'usb_socket', 'spec', 'irve', 'rj45', 'heater', 'ac_split', 'ac_outdoor', 'thermostat', 'cooktop', 'panel'] },
  { id: 'surveillance', label: 'Surveillance & Écrans', tools: ['smoke', 'camera', 'nvr_screen', 'alarm_panel', 'siren', 'intercom'] },
  {
    id: 'mobilier',
    label: 'Mobilier & Sanitaires',
    tools: ['bed1', 'bed2', 'sofa', 'table', 'desk', 'wardrobe', 'tv', 'fridge', 'pc', 'counter', 'bath', 'shower', 'sink', 'wc'],
  },
];

export const ROOM_TYPES: Record<
  RoomType,
  { label: string; sock: (areaM2: number) => number; rj?: boolean; outdoor?: boolean }
> = {
  chambre: { label: 'Chambre', sock: () => 3, rj: true },
  sejour: { label: 'Séjour', sock: (a) => Math.min(7, Math.max(5, Math.ceil(a / 4))), rj: true },
  cuisine: { label: 'Cuisine', sock: (a) => (a <= 4 ? 3 : 6) },
  sdb: { label: 'Salle de bains', sock: () => 1 },
  wc: { label: 'WC', sock: () => 0 },
  couloir: { label: 'Couloir / Palier', sock: () => 1 },
  bureau: { label: 'Bureau', sock: () => 3, rj: true },
  garage: { label: 'Garage / Local', sock: () => 1 },
  terrasse: { label: 'Terrasse', sock: () => 1, outdoor: true },
  autre: { label: 'Autre pièce', sock: () => 3 },
};

export const APPLIANCE_PRESETS: [string, string, number][] = [
  ['', 'Appareil personnalisé', 2000],
  ['Lave-linge', 'Lave-linge (Type A)', 2500],
  ['Lave-vaisselle', 'Lave-vaisselle', 2200],
  ['Four', 'Four encastrable', 3000],
  ['Sèche-linge', 'Sèche-linge', 2500],
  ['Chauffe-eau', 'Chauffe-eau (Jour/Nuit)', 2000],
  ['Climatiseur', 'Climatiseur', 2500],
];

/** Prix unitaires HT indicatifs en FCFA (conversion 1 € = 655,957 FCFA, arrondie). Modifiables dans l’onglet Devis. */
export const DEFAULT_UNIT_PRICES: Record<string, number> = {
  coffret: 82000,
  diffA: 44500,
  diffAC: 34000,
  parafoudre: 95000,
  contacteur: 27500,
  telerupteur: 23500,
  stairCtrl: 58000,
  brk16: 7000,
  brk20: 8000,
  brk32: 12000,
  cable15: 900,
  cable25: 1400,
  cable6: 3150,
  socket: 9000,
  socket2: 15500,
  usb_socket: 21000,
  spec: 12000,
  irve: 387000,
  rj45: 14500,
  switch: 8500,
  pushbutton: 9000,
  dimmer: 31500,
  motion: 27500,
  light: 23000,
  sconce: 29500,
  spot: 12000,
  neon: 14500,
  stair_led: 10500,
  heater: 210000,
  ac_split: 446000,
  ac_outdoor: 754000,
  thermostat: 56000,
  brk20d: 17000,
  cooktop: 315000,
  smoke: 15500,
  camera: 75000,
  nvr_screen: 157000,
  alarm_panel: 184000,
  siren: 49000,
  intercom: 128000,
};

// ============================================================================
// BIBLIOTHÈQUE EXHAUSTIVE DES ÉQUIPEMENTS POUR ZONE DE CÂBLAGE MANUELLE
// ============================================================================
export const LIBRARY_CATEGORIES: { id: LibraryCategory; label: string }[] = [
  { id: 'comptage', label: 'Comptage & Tarifs' },
  { id: 'protection', label: 'Protection Tableau' },
  { id: 'automatisme', label: 'Relais & Automatisme' },
  { id: 'surveillance', label: 'Surveillance & Alarme' },
  { id: 'style', label: 'Style & Appareillage' },
  { id: 'charges', label: 'Éclairage & Escalier LED' },
];

export const ELECTRICAL_LIBRARY: LibraryComponentDef[] = [
  // 1. Comptage & Arrivée
  {
    typeId: 'compteur_linky',
    category: 'comptage',
    name: 'Compteur Énergie (Linky)',
    shortName: 'Compteur',
    spec: 'Monophasé 230 V · Téléinfo C1/C2',
    description: 'Comptage kWh total et contact sec Heures Creuses C1/C2.',
    width: 144,
    height: 108,
    terminals: [
      { id: 'in_l', label: 'L Arr.', wireType: 'phase', rx: 32, ry: 108 },
      { id: 'in_n', label: 'N Arr.', wireType: 'neutral', rx: 64, ry: 108 },
      { id: 'c1', label: 'C1 HC', wireType: 'command', rx: 110, ry: 108 },
    ],
  },
  {
    typeId: 'compteur_horaire',
    category: 'comptage',
    name: 'Compteur selon l’heure (HP/HC)',
    shortName: 'Compteur Horaire',
    spec: 'Double tarif · 22h30 – 06h30',
    description: 'Compteur bi-horaire avec commutation automatique selon l’heure du jour.',
    modulesDin: 2,
    width: 148,
    height: 106,
    interactive: 'clock',
    terminals: [
      { id: 'l_in', label: 'L In', wireType: 'phase', rx: 30, ry: 0 },
      { id: 'n_in', label: 'N In', wireType: 'neutral', rx: 62, ry: 0 },
      { id: 'hc_out', label: 'HC Out', wireType: 'command', rx: 112, ry: 106 },
    ],
  },
  {
    typeId: 'agcp',
    category: 'comptage',
    name: 'Disjoncteur de Branchement AGCP',
    shortName: 'AGCP 500 mA',
    spec: '15/45 A · Sélectif Type S',
    description: 'Coupure générale d’urgence et limitation d’abonnement Enedis.',
    width: 136,
    height: 108,
    interactive: 'toggle',
    terminals: [
      { id: 'n_out', label: 'N Out', wireType: 'neutral', rx: 42, ry: 108 },
      { id: 'l_out', label: 'L Out', wireType: 'phase', rx: 94, ry: 108 },
    ],
  },
  {
    typeId: 'bornier_l',
    category: 'comptage',
    name: 'Bornier Phase (Rouge)',
    shortName: 'Bornier L',
    spec: 'Répartiteur 100 A',
    description: 'Distribution de la phase vers les rangées du tableau.',
    width: 116,
    height: 54,
    terminals: [
      { id: 'l_in', label: 'In', wireType: 'phase', rx: 22, ry: 0 },
      { id: 'l_out1', label: 'L1', wireType: 'phase', rx: 58, ry: 54 },
      { id: 'l_out2', label: 'L2', wireType: 'phase', rx: 92, ry: 54 },
    ],
  },
  {
    typeId: 'bornier_n',
    category: 'comptage',
    name: 'Bornier Neutre (Bleu)',
    shortName: 'Bornier N',
    spec: 'Répartiteur 100 A',
    description: 'Distribution du neutre vers les interrupteurs différentiels.',
    width: 116,
    height: 54,
    terminals: [
      { id: 'n_in', label: 'In', wireType: 'neutral', rx: 22, ry: 0 },
      { id: 'n_out1', label: 'N1', wireType: 'neutral', rx: 58, ry: 54 },
      { id: 'n_out2', label: 'N2', wireType: 'neutral', rx: 92, ry: 54 },
    ],
  },
  {
    typeId: 'terre_piquet',
    category: 'comptage',
    name: 'Bornier & Piquet de Terre (PE)',
    shortName: 'Terre ≤ 100 Ω',
    spec: 'Vert/Jaune · 16 mm²',
    description: 'Liaison équipotentielle et mise à la terre de l’installation.',
    width: 126,
    height: 62,
    terminals: [
      { id: 'pe1', label: 'PE 1', wireType: 'earth', rx: 36, ry: 0 },
      { id: 'pe2', label: 'PE 2', wireType: 'earth', rx: 90, ry: 0 },
    ],
  },

  // 2. Protection Tableau
  {
    typeId: 'diff_a',
    category: 'protection',
    name: 'Interrupteur Différentiel Type A',
    shortName: 'ID 30 mA Type A',
    spec: '63 A · 30 mA (2 mod.)',
    description: 'Obligatoire pour plaque de cuisson, lave-linge et borne VE.',
    modulesDin: 2,
    width: 136,
    height: 108,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N In', wireType: 'neutral', rx: 38, ry: 0 },
      { id: 'l_in', label: 'L In', wireType: 'phase', rx: 98, ry: 0 },
      { id: 'n_out', label: 'N Out', wireType: 'neutral', rx: 38, ry: 108 },
      { id: 'l_out', label: 'L Out', wireType: 'phase', rx: 98, ry: 108 },
    ],
  },
  {
    typeId: 'diff_ac',
    category: 'protection',
    name: 'Interrupteur Différentiel Type AC',
    shortName: 'ID 30 mA Type AC',
    spec: '40 A · 30 mA (2 mod.)',
    description: 'Protection des circuits d’éclairage, prises 16 A et chauffage.',
    modulesDin: 2,
    width: 136,
    height: 108,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N In', wireType: 'neutral', rx: 38, ry: 0 },
      { id: 'l_in', label: 'L In', wireType: 'phase', rx: 98, ry: 0 },
      { id: 'n_out', label: 'N Out', wireType: 'neutral', rx: 38, ry: 108 },
      { id: 'l_out', label: 'L Out', wireType: 'phase', rx: 98, ry: 108 },
    ],
  },
  {
    typeId: 'disj_2a',
    category: 'protection',
    name: 'Disjoncteur 2 A (Protection Bobine)',
    shortName: 'Disj. 2 A',
    spec: '2 A Courbe C · 1,5 mm²',
    description: 'Protection dédiée aux bobines (Contacteur J/N, Horloge, VMC).',
    modulesDin: 1,
    width: 110,
    height: 104,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 32, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 78, ry: 0 },
      { id: 'n_out', label: 'N', wireType: 'neutral', rx: 32, ry: 104 },
      { id: 'l_out', label: 'L', wireType: 'phase', rx: 78, ry: 104 },
    ],
  },
  {
    typeId: 'disj_16a',
    category: 'protection',
    name: 'Disjoncteur Divisionnaire 16 A',
    shortName: 'Disj. 16 A',
    spec: '16 A Courbe C · 1,5 mm²',
    description: 'Protection éclairage (8 pts), télérupteur ou circuit 8 prises.',
    modulesDin: 1,
    width: 110,
    height: 104,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 32, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 78, ry: 0 },
      { id: 'n_out', label: 'N', wireType: 'neutral', rx: 32, ry: 104 },
      { id: 'l_out', label: 'L', wireType: 'phase', rx: 78, ry: 104 },
    ],
  },
  {
    typeId: 'disj_20a',
    category: 'protection',
    name: 'Disjoncteur Divisionnaire 20 A',
    shortName: 'Disj. 20 A',
    spec: '20 A Courbe C · 2,5 mm²',
    description: 'Protection prises 2,5 mm², four, lave-linge ou chauffe-eau.',
    modulesDin: 1,
    width: 110,
    height: 104,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 32, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 78, ry: 0 },
      { id: 'n_out', label: 'N', wireType: 'neutral', rx: 32, ry: 104 },
      { id: 'l_out', label: 'L', wireType: 'phase', rx: 78, ry: 104 },
    ],
  },
  {
    typeId: 'disj_32a',
    category: 'protection',
    name: 'Disjoncteur Puissance 32 A',
    shortName: 'Disj. 32 A',
    spec: '32 A Courbe C · 6 mm²',
    description: 'Protection plaque de cuisson induction ou borne de recharge.',
    modulesDin: 1,
    width: 116,
    height: 104,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 34, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 82, ry: 0 },
      { id: 'n_out', label: 'N', wireType: 'neutral', rx: 34, ry: 104 },
      { id: 'l_out', label: 'L', wireType: 'phase', rx: 82, ry: 104 },
    ],
  },
  {
    typeId: 'disj_courbe_d',
    category: 'protection',
    name: 'Disjoncteur Courbe D 20 A (Clim/PAC)',
    shortName: 'Disj. 20 A D',
    spec: '20 A Courbe D · 2,5 mm²',
    description: 'Absorbe le courant d’appel au démarrage du compresseur de climatisation.',
    modulesDin: 1,
    width: 116,
    height: 104,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 34, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 82, ry: 0 },
      { id: 'n_out', label: 'N', wireType: 'neutral', rx: 34, ry: 104 },
      { id: 'l_out', label: 'L', wireType: 'phase', rx: 82, ry: 104 },
    ],
  },
  {
    typeId: 'sectionneur_clim',
    category: 'protection',
    name: 'Sectionneur Proximité Clim IP65',
    shortName: 'Sectionneur IP65',
    spec: '20 A · Coupure cadenassable ext.',
    description: 'Coffret de coupure de sécurité obligatoire à côté du groupe extérieur.',
    width: 124,
    height: 98,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: 'N In', wireType: 'neutral', rx: 34, ry: 0 },
      { id: 'l_in', label: 'L In', wireType: 'phase', rx: 90, ry: 0 },
      { id: 'n_out', label: 'N Out', wireType: 'neutral', rx: 34, ry: 98 },
      { id: 'l_out', label: 'L Out', wireType: 'phase', rx: 90, ry: 98 },
    ],
  },
  {
    typeId: 'parafoudre',
    category: 'protection',
    name: 'Parafoudre Modulaire Type 2',
    shortName: 'Parafoudre T2',
    spec: 'Imax 20 kA · Cartouche',
    description: 'Écoulement des surtensions atmosphériques vers la terre.',
    modulesDin: 2,
    width: 126,
    height: 104,
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 32, ry: 0 },
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 94, ry: 0 },
      { id: 'pe_out', label: 'PE', wireType: 'earth', rx: 63, ry: 104 },
    ],
  },

  // 3. Relais & Automatisme
  {
    typeId: 'telerupteur',
    category: 'automatisme',
    name: 'Télérupteur Unipolaire 16 A',
    shortName: 'Télérupteur',
    spec: 'Bobine 230 V · A1/A2 · 1-2',
    description: 'Commande d’un point lumineux depuis 3 boutons poussoirs ou plus.',
    modulesDin: 1,
    width: 138,
    height: 108,
    terminals: [
      { id: 'l_in', label: '1 (L)', wireType: 'phase', rx: 32, ry: 0 },
      { id: 'a1', label: 'A1 Cmd', wireType: 'command', rx: 72, ry: 0 },
      { id: 'a2', label: 'A2 (N)', wireType: 'neutral', rx: 110, ry: 0 },
      { id: 'lamp_out', label: '2 Retour', wireType: 'command', rx: 69, ry: 108 },
    ],
  },
  {
    typeId: 'minuterie',
    category: 'automatisme',
    name: 'Minuterie d’Escalier / Couloir',
    shortName: 'Minuterie',
    spec: 'Temporisation 30 s à 10 min',
    description: 'Extinction automatique temporisée pour couloirs et paliers.',
    modulesDin: 1,
    width: 138,
    height: 108,
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 34, ry: 0 },
      { id: 'bp', label: 'BP', wireType: 'command', rx: 72, ry: 0 },
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 108, ry: 0 },
      { id: 'out', label: 'Lampes', wireType: 'command', rx: 69, ry: 108 },
    ],
  },
  {
    typeId: 'contacteur_jn',
    category: 'automatisme',
    name: 'Contacteur Jour / Nuit (HP-HC)',
    shortName: 'Contacteur J/N',
    spec: '20 A · Auto / 0 / Marche forcée',
    description: 'Enclenche le chauffe-eau sur signal Heures Creuses ou marche forcée.',
    modulesDin: 1,
    width: 142,
    height: 108,
    interactive: 'toggle',
    terminals: [
      { id: 'n_in', label: '1 (N)', wireType: 'neutral', rx: 28, ry: 0 },
      { id: 'l_in', label: '3 (L)', wireType: 'phase', rx: 64, ry: 0 },
      { id: 'a1', label: 'A1 HC', wireType: 'command', rx: 112, ry: 0 },
      { id: 'n_out', label: '2 (N)', wireType: 'neutral', rx: 38, ry: 108 },
      { id: 'l_out', label: '4 (L)', wireType: 'phase', rx: 98, ry: 108 },
    ],
  },
  {
    typeId: 'horloge_prog',
    category: 'automatisme',
    name: 'Horloge Programmable Hebdo',
    shortName: 'Horloge Prog.',
    spec: 'Programmation horaire 230 V',
    description: 'Déclenche éclairage extérieur, vitrine ou chauffage selon l’heure.',
    modulesDin: 2,
    width: 142,
    height: 108,
    interactive: 'clock',
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 36, ry: 0 },
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 104, ry: 0 },
      { id: 'out', label: 'Sortie', wireType: 'command', rx: 70, ry: 108 },
    ],
  },
  {
    typeId: 'ctrl_escalier',
    category: 'automatisme',
    name: 'Contrôleur Escalier LED Séquentiel',
    shortName: 'Contrôleur Escalier',
    spec: '24 V DC · 16 sorties marches',
    description: 'Allume progressivement les marches au passage des capteurs bas et haut.',
    modulesDin: 3,
    width: 162,
    height: 110,
    terminals: [
      { id: 'l_in', label: '230V L', wireType: 'phase', rx: 32, ry: 0 },
      { id: 'n_in', label: '230V N', wireType: 'neutral', rx: 78, ry: 0 },
      { id: 'pir_bas', label: 'PIR Bas', wireType: 'signal', rx: 32, ry: 110 },
      { id: 'pir_haut', label: 'PIR Haut', wireType: 'signal', rx: 81, ry: 110 },
      { id: 'led_bus', label: 'Bus Marches', wireType: 'command', rx: 132, ry: 110 },
    ],
  },
  {
    typeId: 'delesteur',
    category: 'automatisme',
    name: 'Délesteur Monophasé',
    shortName: 'Délesteur',
    spec: '2 voies · Seuil 45 A',
    description: 'Coupe temporairement les radiateurs pour éviter la disjonction générale.',
    modulesDin: 2,
    width: 142,
    height: 104,
    terminals: [
      { id: 'ti', label: 'Téléinfo', wireType: 'signal', rx: 36, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 104, ry: 0 },
      { id: 'v1', label: 'Voie 1', wireType: 'command', rx: 71, ry: 104 },
    ],
  },
  {
    typeId: 'thermostat_clim',
    category: 'automatisme',
    name: 'Thermostat / Régulateur Clim',
    shortName: 'Thermostat Clim',
    spec: 'Bus / Fil pilote · Sonde ambiante',
    description: 'Pilote la consigne chaud/froid et la vitesse du split intérieur.',
    width: 132,
    height: 98,
    interactive: 'toggle',
    planToolType: 'thermostat',
    terminals: [
      { id: 'l_in', label: 'L / Alim', wireType: 'phase', rx: 36, ry: 0 },
      { id: 'bus_out', label: 'Bus Clim', wireType: 'signal', rx: 96, ry: 98 },
    ],
  },

  // 4. Surveillance & Alarme
  {
    typeId: 'centrale_alarme',
    category: 'surveillance',
    name: 'Centrale Alarme & Supervision',
    shortName: 'Centrale Alarme',
    spec: 'IP / GSM · Batterie 12 V',
    description: 'Collecte les détecteurs PIR, DAAF et caméras, pilote la sirène.',
    width: 156,
    height: 110,
    interactive: 'toggle',
    planToolType: 'alarm_panel',
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 30, ry: 0 },
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 66, ry: 0 },
      { id: 'zone1', label: 'Zone PIR', wireType: 'signal', rx: 42, ry: 110 },
      { id: 'siren_out', label: 'Sirène', wireType: 'command', rx: 114, ry: 110 },
    ],
  },
  {
    typeId: 'camera_ip',
    category: 'surveillance',
    name: 'Caméra Surveillance IP PoE',
    shortName: 'Caméra IP',
    spec: '4K IR · PoE / 12 V',
    description: 'Vidéosurveillance intérieure ou extérieure reliée au réseau RJ45.',
    width: 132,
    height: 98,
    interactive: 'sensor',
    planToolType: 'camera',
    terminals: [
      { id: 'rj', label: 'PoE / Bus', wireType: 'signal', rx: 66, ry: 0 },
      { id: 'pe', label: 'PE', wireType: 'earth', rx: 106, ry: 98 },
    ],
  },
  {
    typeId: 'detecteur_mvt',
    category: 'surveillance',
    name: 'Détecteur Mouvement PIR / Escalier',
    shortName: 'Capteur PIR',
    spec: 'Infrarouge 120° · 5 m',
    description: 'Déclenche un éclairage ou un signal d’alarme/escalier au passage.',
    width: 128,
    height: 98,
    interactive: 'sensor',
    planToolType: 'motion',
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 36, ry: 0 },
      { id: 'sig_out', label: 'Signal', wireType: 'signal', rx: 92, ry: 98 },
    ],
  },
  {
    typeId: 'sirene',
    category: 'surveillance',
    name: 'Sirène Intérieure / Flash',
    shortName: 'Sirène 105 dB',
    spec: '12 V / 230 V · Flash LED',
    description: 'Alerte sonore et lumineuse en cas d’intrusion ou incendie.',
    width: 126,
    height: 94,
    planToolType: 'siren',
    terminals: [
      { id: 'cmd', label: 'Déclenc.', wireType: 'command', rx: 42, ry: 0 },
      { id: 'n', label: '0 V / N', wireType: 'neutral', rx: 86, ry: 0 },
    ],
  },
  {
    typeId: 'daaf',
    category: 'surveillance',
    name: 'Détecteur de Fumée (DAAF)',
    shortName: 'DAAF EN14604',
    spec: 'Autonome / Interconnectable',
    description: 'Obligatoire dans chaque logement, idéalement au palier/couloir.',
    width: 124,
    height: 94,
    interactive: 'sensor',
    planToolType: 'smoke',
    terminals: [
      { id: 'bus', label: 'Interco.', wireType: 'signal', rx: 62, ry: 94 },
    ],
  },
  {
    typeId: 'onduleur',
    category: 'surveillance',
    name: 'Onduleur / Batterie Secours',
    shortName: 'Onduleur UPS',
    spec: '800 VA · Autonomie 45 min',
    description: 'Maintient la centrale d’alarme, les caméras et la box en cas de coupure.',
    width: 138,
    height: 102,
    terminals: [
      { id: 'l_in', label: 'L In', wireType: 'phase', rx: 38, ry: 0 },
      { id: 'l_out', label: 'L Sec.', wireType: 'phase', rx: 100, ry: 102 },
    ],
  },
  {
    typeId: 'ecran_nvr',
    category: 'surveillance',
    name: 'Écran Moniteur Caméras NVR',
    shortName: 'Moniteur NVR',
    spec: 'HDMI / PoE Switch · Mosaïque Live',
    description: 'Affiche en direct les flux vidéo des caméras IP raccordées.',
    width: 152,
    height: 106,
    interactive: 'toggle',
    planToolType: 'nvr_screen',
    terminals: [
      { id: 'l_in', label: 'L 230V', wireType: 'phase', rx: 34, ry: 0 },
      { id: 'cam_in', label: 'Flux IP', wireType: 'signal', rx: 112, ry: 0 },
    ],
  },

  // 5. Style & Appareillage
  {
    typeId: 'bouton_poussoir',
    category: 'style',
    name: 'Bouton Poussoir (avec voyant)',
    shortName: 'Poussoir',
    spec: 'Contact NO 10 A · Rappel ressort',
    description: 'Impulsion momentanée pour télérupteur ou minuterie.',
    width: 126,
    height: 96,
    interactive: 'pushbutton',
    planToolType: 'pushbutton',
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 38, ry: 0 },
      { id: 'ret', label: 'Retour BP', wireType: 'command', rx: 88, ry: 96 },
    ],
  },
  {
    typeId: 'inter_va_et_vient',
    category: 'style',
    name: 'Interrupteur / Va-et-Vient',
    shortName: 'Interrupteur',
    spec: '10 AX · Finition Architecte',
    description: 'Commande directe d’un point lumineux.',
    width: 126,
    height: 96,
    interactive: 'toggle',
    planToolType: 'switch',
    terminals: [
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 38, ry: 0 },
      { id: 'ret', label: 'Retour', wireType: 'command', rx: 88, ry: 96 },
    ],
  },
  {
    typeId: 'prise_16a',
    category: 'style',
    name: 'Prise 16 A + Terre (2P+T)',
    shortName: 'Prise 16 A',
    spec: '230 V · Éclipses sécurité',
    description: 'Socle de courant standard câblé en Phase, Neutre et Terre.',
    width: 126,
    height: 98,
    planToolType: 'socket',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 30, ry: 0 },
      { id: 'pe_in', label: 'PE', wireType: 'earth', rx: 63, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 96, ry: 0 },
    ],
  },
  {
    typeId: 'prise_usb',
    category: 'style',
    name: 'Prise 16 A + Chargeur USB-C',
    shortName: 'Prise USB-C',
    spec: '16 A + 30 W PD intégré',
    description: 'Prise murale design avec port USB-C Power Delivery.',
    width: 128,
    height: 98,
    planToolType: 'usb_socket',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 32, ry: 0 },
      { id: 'pe_in', label: 'PE', wireType: 'earth', rx: 64, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 96, ry: 0 },
    ],
  },
  {
    typeId: 'borne_ve',
    category: 'style',
    name: 'Borne Recharge Véhicule 32 A',
    shortName: 'Borne VE 7,4 kW',
    spec: '32 A · 10 mm² · Type A',
    description: 'Wallbox dédiée avec protection différentielle Type A ou F.',
    width: 138,
    height: 104,
    planToolType: 'irve',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 34, ry: 0 },
      { id: 'pe_in', label: 'PE', wireType: 'earth', rx: 69, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 104, ry: 0 },
    ],
  },

  // 6. Éclairage & Charges
  {
    typeId: 'lampe_dcl',
    category: 'charges',
    name: 'Point Lumineux DCL / Plafonnier',
    shortName: 'Plafonnier DCL',
    spec: 'LED 12–100 W · Phase + N + PE',
    description: 'Luminaire raccordé au retour de commande, neutre et terre.',
    width: 126,
    height: 98,
    planToolType: 'light',
    terminals: [
      { id: 'cmd_in', label: 'Retour', wireType: 'command', rx: 32, ry: 0 },
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 64, ry: 0 },
      { id: 'pe_in', label: 'PE', wireType: 'earth', rx: 96, ry: 0 },
    ],
  },
  {
    typeId: 'escalier_led',
    category: 'charges',
    name: 'Escalier Lumineux Séquentiel',
    shortName: 'Marches LED',
    spec: '14 marches · 24 V DC · 28 W',
    description: 'Rubans LED sous nez de marche pilotés marche par marche.',
    width: 148,
    height: 104,
    planToolType: 'staircase',
    terminals: [
      { id: 'bus_in', label: 'Bus Marches', wireType: 'command', rx: 74, ry: 0 },
    ],
  },
  {
    typeId: 'chauffe_eau',
    category: 'charges',
    name: 'Chauffe-Eau Électrique (Ballon)',
    shortName: 'Chauffe-eau 2000 W',
    spec: '200 L · Piloté Contacteur J/N',
    description: 'Chauffe automatiquement en Heures Creuses ou marche forcée.',
    width: 144,
    height: 104,
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 36, ry: 0 },
      { id: 'pe_in', label: 'PE', wireType: 'earth', rx: 72, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 108, ry: 0 },
    ],
  },
  {
    typeId: 'radiateur_elec',
    category: 'charges',
    name: 'Radiateur Inertie + Fil Pilote',
    shortName: 'Radiateur 1500 W',
    spec: 'Classe II · 6 ordres fil pilote',
    description: 'Chauffage électrique pilotable par délesteur ou horloge.',
    width: 142,
    height: 100,
    planToolType: 'heater',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 34, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 72, ry: 0 },
      { id: 'fp_in', label: 'Pilote', wireType: 'command', rx: 108, ry: 0 },
    ],
  },
  {
    typeId: 'clim_groupe_ext',
    category: 'charges',
    name: 'Groupe Extérieur Clim (PAC)',
    shortName: 'Groupe Ext. PAC',
    spec: 'Inverter 2200 W · Alim 3G 2,5 + Com',
    description: 'Compresseur extérieur alimenté via Courbe D et sectionneur IP65.',
    width: 156,
    height: 108,
    planToolType: 'ac_outdoor',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 30, ry: 0 },
      { id: 'pe_in', label: 'PE', wireType: 'earth', rx: 66, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 104, ry: 0 },
      { id: 'n_split', label: 'N Split', wireType: 'neutral', rx: 38, ry: 108 },
      { id: 'l_split', label: 'L Split', wireType: 'phase', rx: 82, ry: 108 },
      { id: 'com_split', label: 'Com', wireType: 'signal', rx: 124, ry: 108 },
    ],
  },
  {
    typeId: 'clim_split',
    category: 'charges',
    name: 'Split Climatisation Réversible (Int.)',
    shortName: 'Split Clim',
    spec: 'Liaison 4G 1,5 mm² (L/N/PE/Com)',
    description: 'Unité intérieure murale reliée au groupe extérieur par câble 4G + com.',
    width: 152,
    height: 102,
    planToolType: 'ac_split',
    terminals: [
      { id: 'n_in', label: 'N', wireType: 'neutral', rx: 36, ry: 0 },
      { id: 'l_in', label: 'L', wireType: 'phase', rx: 76, ry: 0 },
      { id: 'com_in', label: 'Com', wireType: 'signal', rx: 118, ry: 0 },
    ],
  },
];

// Pre-built interactive wiring templates for the Manual Wiring Lab
export interface WiringTemplate {
  id: string;
  name: string;
  subtitle: string;
  nodes: ManualNode[];
  wires: ManualWire[];
}

export const WIRING_TEMPLATES: WiringTemplate[] = [
  {
    id: 'telerupteur_3bp',
    name: 'Câblage Télérupteur + 3 Boutons Poussoirs',
    subtitle: 'Idéal pour couloir / cage d’escalier multi-niveaux',
    nodes: [
      { id: 'n1', typeId: 'diff_ac', label: 'ID 30 mA Type AC', x: 70, y: 40, stateOn: true },
      { id: 'n2', typeId: 'disj_16a', label: 'Disj. 16 A Éclairage', x: 260, y: 40, stateOn: true },
      { id: 'n3', typeId: 'telerupteur', label: 'Télérupteur 16 A', x: 440, y: 40, stateOn: false },
      { id: 'n4', typeId: 'bouton_poussoir', label: 'Poussoir RDC', x: 80, y: 240, stateOn: false },
      { id: 'n5', typeId: 'bouton_poussoir', label: 'Poussoir Palier', x: 240, y: 240, stateOn: false },
      { id: 'n6', typeId: 'bouton_poussoir', label: 'Poussoir Étage', x: 400, y: 240, stateOn: false },
      { id: 'n7', typeId: 'lampe_dcl', label: 'Plafonnier Couloir', x: 580, y: 240, stateOn: false },
    ],
    wires: [
      { id: 'w1', fromNodeId: 'n1', fromTerminalId: 'n_out', toNodeId: 'n2', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'w2', fromNodeId: 'n1', fromTerminalId: 'l_out', toNodeId: 'n2', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'w3', fromNodeId: 'n2', fromTerminalId: 'n_out', toNodeId: 'n3', toTerminalId: 'a2', wireType: 'neutral' },
      { id: 'w4', fromNodeId: 'n2', fromTerminalId: 'l_out', toNodeId: 'n3', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'w5', fromNodeId: 'n2', fromTerminalId: 'l_out', toNodeId: 'n4', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'w6', fromNodeId: 'n2', fromTerminalId: 'l_out', toNodeId: 'n5', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'w7', fromNodeId: 'n2', fromTerminalId: 'l_out', toNodeId: 'n6', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'w8', fromNodeId: 'n4', fromTerminalId: 'ret', toNodeId: 'n3', toTerminalId: 'a1', wireType: 'command' },
      { id: 'w9', fromNodeId: 'n5', fromTerminalId: 'ret', toNodeId: 'n3', toTerminalId: 'a1', wireType: 'command' },
      { id: 'w10', fromNodeId: 'n6', fromTerminalId: 'ret', toNodeId: 'n3', toTerminalId: 'a1', wireType: 'command' },
      { id: 'w11', fromNodeId: 'n3', fromTerminalId: 'lamp_out', toNodeId: 'n7', toTerminalId: 'cmd_in', wireType: 'command' },
      { id: 'w12', fromNodeId: 'n2', fromTerminalId: 'n_out', toNodeId: 'n7', toTerminalId: 'n_in', wireType: 'neutral' },
    ],
  },
  {
    id: 'escalier_led_seq',
    name: 'Escalier Lumineux Séquentiel + Capteurs Haut/Bas',
    subtitle: 'Allumage progressif marche par marche au passage',
    nodes: [
      { id: 's1', typeId: 'disj_16a', label: 'Disj. 16 A Escalier', x: 90, y: 40, stateOn: true },
      { id: 's2', typeId: 'ctrl_escalier', label: 'Contrôleur Séquentiel', x: 310, y: 40, stateOn: true },
      { id: 's3', typeId: 'detecteur_mvt', label: 'Capteur Bas (RDC)', x: 80, y: 240, stateOn: false },
      { id: 's4', typeId: 'detecteur_mvt', label: 'Capteur Haut (Étage)', x: 260, y: 240, stateOn: false },
      { id: 's5', typeId: 'escalier_led', label: 'Escalier 14 Marches', x: 470, y: 240, stateOn: false },
    ],
    wires: [
      { id: 'sw1', fromNodeId: 's1', fromTerminalId: 'l_out', toNodeId: 's2', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'sw2', fromNodeId: 's1', fromTerminalId: 'n_out', toNodeId: 's2', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'sw3', fromNodeId: 's1', fromTerminalId: 'l_out', toNodeId: 's3', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'sw4', fromNodeId: 's1', fromTerminalId: 'l_out', toNodeId: 's4', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'sw5', fromNodeId: 's3', fromTerminalId: 'sig_out', toNodeId: 's2', toTerminalId: 'pir_bas', wireType: 'signal' },
      { id: 'sw6', fromNodeId: 's4', fromTerminalId: 'sig_out', toNodeId: 's2', toTerminalId: 'pir_haut', wireType: 'signal' },
      { id: 'sw7', fromNodeId: 's2', fromTerminalId: 'led_bus', toNodeId: 's5', toTerminalId: 'bus_in', wireType: 'command' },
    ],
  },
  {
    id: 'compteur_hphc_chauffe_eau',
    name: 'Compteur selon l’heure (HP/HC) + Contacteur J/N',
    subtitle: 'Démarrage automatique du chauffe-eau en heures creuses',
    nodes: [
      { id: 'h1', typeId: 'compteur_horaire', label: 'Compteur HP/HC', x: 70, y: 40, stateOn: true },
      { id: 'h2', typeId: 'disj_2a', label: 'Disj. 2 A Bobine', x: 260, y: 40, stateOn: true },
      { id: 'h3', typeId: 'disj_20a', label: 'Disj. 20 A Ballon', x: 410, y: 40, stateOn: true },
      { id: 'h4', typeId: 'contacteur_jn', label: 'Contacteur J/N', x: 280, y: 210, stateOn: true },
      { id: 'h5', typeId: 'chauffe_eau', label: 'Chauffe-eau 2000 W', x: 490, y: 210, stateOn: false },
    ],
    wires: [
      { id: 'hw1', fromNodeId: 'h1', fromTerminalId: 'hc_out', toNodeId: 'h4', toTerminalId: 'a1', wireType: 'command' },
      { id: 'hw2', fromNodeId: 'h3', fromTerminalId: 'n_out', toNodeId: 'h4', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'hw3', fromNodeId: 'h3', fromTerminalId: 'l_out', toNodeId: 'h4', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'hw4', fromNodeId: 'h4', fromTerminalId: 'n_out', toNodeId: 'h5', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'hw5', fromNodeId: 'h4', fromTerminalId: 'l_out', toNodeId: 'h5', toTerminalId: 'l_in', wireType: 'phase' },
    ],
  },
  {
    id: 'surveillance_alarme',
    name: 'Centrale Surveillance + Caméra IP + Sirène',
    subtitle: 'Chaîne de sécurité secourue par onduleur',
    nodes: [
      { id: 'a1', typeId: 'onduleur', label: 'Onduleur 800 VA', x: 70, y: 40, stateOn: true },
      { id: 'a2', typeId: 'centrale_alarme', label: 'Centrale Alarme', x: 260, y: 40, stateOn: true },
      { id: 'a3', typeId: 'camera_ip', label: 'Caméra Entrée', x: 80, y: 230, stateOn: false },
      { id: 'a4', typeId: 'detecteur_mvt', label: 'PIR Couloir', x: 260, y: 230, stateOn: false },
      { id: 'a5', typeId: 'sirene', label: 'Sirène 105 dB', x: 440, y: 230, stateOn: false },
    ],
    wires: [
      { id: 'aw1', fromNodeId: 'a1', fromTerminalId: 'l_out', toNodeId: 'a2', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'aw2', fromNodeId: 'a3', fromTerminalId: 'rj', toNodeId: 'a2', toTerminalId: 'zone1', wireType: 'signal' },
      { id: 'aw3', fromNodeId: 'a4', fromTerminalId: 'sig_out', toNodeId: 'a2', toTerminalId: 'zone1', wireType: 'signal' },
      { id: 'aw4', fromNodeId: 'a2', fromTerminalId: 'siren_out', toNodeId: 'a5', toTerminalId: 'cmd', wireType: 'command' },
    ],
  },
  {
    id: 'clim_reversible',
    name: 'Climatisation Réversible (Courbe D + Sectionneur + PAC + Split)',
    subtitle: 'Alimentation 3G 2,5 mm² au groupe extérieur et liaison 4G vers le split',
    nodes: [
      { id: 'c1', typeId: 'disj_courbe_d', label: 'Disj. 20 A Courbe D', x: 70, y: 40, stateOn: true },
      { id: 'c2', typeId: 'sectionneur_clim', label: 'Sectionneur IP65', x: 260, y: 40, stateOn: true },
      { id: 'c3', typeId: 'clim_groupe_ext', label: 'Groupe Extérieur PAC', x: 450, y: 36, stateOn: true },
      { id: 'c4', typeId: 'thermostat_clim', label: 'Thermostat Salon', x: 140, y: 235, stateOn: true },
      { id: 'c5', typeId: 'clim_split', label: 'Split Intérieur Séjour', x: 450, y: 235, stateOn: false },
    ],
    wires: [
      { id: 'cw1', fromNodeId: 'c1', fromTerminalId: 'n_out', toNodeId: 'c2', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'cw2', fromNodeId: 'c1', fromTerminalId: 'l_out', toNodeId: 'c2', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'cw3', fromNodeId: 'c2', fromTerminalId: 'n_out', toNodeId: 'c3', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'cw4', fromNodeId: 'c2', fromTerminalId: 'l_out', toNodeId: 'c3', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'cw5', fromNodeId: 'c3', fromTerminalId: 'n_split', toNodeId: 'c5', toTerminalId: 'n_in', wireType: 'neutral' },
      { id: 'cw6', fromNodeId: 'c3', fromTerminalId: 'l_split', toNodeId: 'c5', toTerminalId: 'l_in', wireType: 'phase' },
      { id: 'cw7', fromNodeId: 'c4', fromTerminalId: 'bus_out', toNodeId: 'c5', toTerminalId: 'com_in', wireType: 'signal' },
      { id: 'cw8', fromNodeId: 'c3', fromTerminalId: 'com_split', toNodeId: 'c5', toTerminalId: 'com_in', wireType: 'signal' },
    ],
  },
];

function clampVal(v: number, a: number, b: number) {
  return a > b ? (a + b) / 2 : Math.min(b, Math.max(a, v));
}

function snapVal(v: number, g: number) {
  return Math.round(v / g) * g;
}

function wallPosSeed(r: Room, side: WallSide, along: number, half: number) {
  if (side === 'top' || side === 'bottom') {
    return {
      x: clampVal(snapVal(along, 5), r.x + half, r.x + r.w - half),
      y: side === 'top' ? r.y : r.y + r.h,
    };
  }
  return {
    x: side === 'left' ? r.x : r.x + r.w,
    y: clampVal(snapVal(along, 5), r.y + half, r.y + r.h - half),
  };
}

// Featured default project: Multi-Story House (RDC + 1er Étage) with Corridor + Luminous Staircase
export function createMultiStoryHouseProject(): PlanProjectData {
  let nextId = 1;
  const floors: FloorLevel[] = [
    { id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 },
    { id: 1, name: '1er Étage', elevationIndex: 1 },
  ];
  const rooms: Room[] = [];
  const items: PlanItem[] = [];

  const addRoom = (
    floorId: number,
    x: number,
    y: number,
    w: number,
    h: number,
    type: RoomType,
    name: string
  ) => {
    const r: Room = { id: nextId++, floorId, x, y, w, h, type, name };
    rooms.push(r);
    return r;
  };

  const addWall = (
    r: Room,
    type: ItemType,
    side: WallSide,
    along: number,
    extra: Partial<PlanItem> = {}
  ) => {
    const T = TYPES[type];
    const len = extra.len ?? T.len;
    const half = len && T.struct ? len / 2 + 6 : T.half ?? 16;
    const pos = wallPosSeed(r, side, along, half);
    const it: PlanItem = {
      id: nextId++,
      floorId: r.floorId,
      type,
      x: pos.x,
      y: pos.y,
      roomId: r.id,
      side,
      rot: 0,
      name: '',
      watts: T.watts,
      ...(len ? { len } : {}),
      ...extra,
    };
    items.push(it);
    return it;
  };

  const addFloor = (
    r: Room,
    type: ItemType,
    x: number,
    y: number,
    extra: Partial<PlanItem> = {}
  ) => {
    const T = TYPES[type];
    const it: PlanItem = {
      id: nextId++,
      floorId: r.floorId,
      type,
      x,
      y,
      roomId: r.id,
      side: null,
      rot: 0,
      name: '',
      watts: T.watts,
      ...(T.furn || type === 'staircase' ? { w: T.w, h: T.h } : {}),
      ...(type === 'neon' ? { len: 200, wpm: 12, watts: 0 } : {}),
      ...(type === 'spots' ? { count: 4, spacing: 80, watts: 7 } : {}),
      ...(type === 'staircase'
        ? { stepCount: 14, ledColor: 'warm', wattsPerStep: 2 }
        : {}),
      ...extra,
    };
    items.push(it);
    return it;
  };

  // === RDC (Floor 0) ===
  const sej = addRoom(0, 0, 0, 500, 420, 'sejour', 'Séjour');
  const cui = addRoom(0, 500, 0, 350, 260, 'cuisine', 'Cuisine');
  const cou = addRoom(0, 500, 260, 350, 160, 'couloir', 'Couloir & Escalier');
  const gar = addRoom(0, 0, 420, 320, 260, 'garage', 'Garage / Technique');
  const ter = addRoom(0, -220, 0, 220, 420, 'terrasse', 'Terrasse');

  addWall(cou, 'panel', 'right', 320);
  addWall(cou, 'door', 'bottom', 600);
  addWall(sej, 'door', 'right', 330);
  addWall(sej, 'door', 'left', 210, { len: 130 });
  addWall(cui, 'door', 'bottom', 580);
  addWall(gar, 'door', 'top', 180);

  addWall(sej, 'window', 'top', 240, { len: 150 });
  addWall(cui, 'window', 'top', 680, { len: 110 });

  // Staircase connecting RDC to 1er Étage
  addFloor(cou, 'staircase', 740, 340, {
    rot: 90,
    w: 110,
    h: 220,
    stepCount: 14,
    ledColor: 'warm',
    wattsPerStep: 2,
    name: 'Escalier LED',
  });

  // Lighting & Surveillance RDC
  addFloor(sej, 'light', 170, 210);
  addFloor(sej, 'light', 350, 210);
  addFloor(cui, 'spots', 675, 130, { count: 4, spacing: 80 });
  addFloor(cou, 'light', 575, 340);
  addFloor(gar, 'neon', 160, 550, { len: 220, wpm: 16 });
  addFloor(cou, 'smoke', 550, 290);

  addWall(cou, 'alarm_panel', 'left', 360);
  addWall(cou, 'nvr_screen', 'left', 295, { name: 'Écran Caméras' });
  addWall(cou, 'intercom', 'bottom', 670);
  addWall(sej, 'ac_split', 'top', 110, { name: 'Clim Séjour' });
  addWall(sej, 'thermostat', 'right', 250);
  addWall(ter, 'ac_outdoor', 'left', 100, { name: 'PAC Ext.' });
  addWall(ter, 'camera', 'top', -50, {
    name: 'Cam. Terrasse',
    camPlacement: 'interior',
    camAngle: 10,
    camFov: 90,
    camRange: 450,
  });
  addWall(gar, 'camera', 'right', 550, {
    name: 'Cam. Ext. Allée',
    camPlacement: 'exterior',
    camAngle: 0,
    camFov: 100,
    camRange: 550,
  });

  addWall(sej, 'dimmer', 'right', 290);
  addWall(cui, 'switch', 'bottom', 530);
  addWall(cou, 'pushbutton', 'left', 310);
  addWall(cou, 'motion', 'right', 380);
  addWall(gar, 'switch', 'top', 240);
  addWall(ter, 'switch', 'right', 140);

  addWall(sej, 'socket2', 'top', 110);
  addWall(sej, 'socket', 'top', 380);
  addWall(sej, 'socket', 'left', 80);
  addWall(sej, 'socket', 'bottom', 220);
  addWall(sej, 'usb_socket', 'bottom', 400);
  addWall(sej, 'rj45', 'top', 420);
  addWall(sej, 'heater', 'top', 240, { name: 'Radiateur Séjour', watts: 1500 });

  addWall(cui, 'socket2', 'right', 80);
  addWall(cui, 'socket2', 'right', 190);
  addWall(cui, 'socket', 'top', 580);
  addWall(cui, 'cooktop', 'top', 770);
  addWall(cui, 'spec', 'left', 130, { name: 'Lave-vaisselle', watts: 2200 });
  addWall(cui, 'spec', 'right', 20, { name: 'Four', watts: 3000 });

  addWall(gar, 'irve', 'bottom', 160, { name: 'Borne VE 7,4 kW', watts: 7400 });
  addWall(gar, 'spec', 'left', 540, { name: 'Chauffe-eau', watts: 2000 });
  addWall(gar, 'socket2', 'right', 480);

  addFloor(sej, 'sofa', 250, 360, { rot: 180 });
  addFloor(sej, 'table', 340, 240);
  addFloor(sej, 'tv', 410, 14);
  addFloor(cui, 'fridge', 540, 45);
  addFloor(cui, 'counter', 720, 35);

  // === 1er ÉTAGE (Floor 1) ===
  const palier = addRoom(1, 500, 260, 350, 160, 'couloir', 'Palier Étage');
  const ch1 = addRoom(1, 0, 0, 460, 350, 'chambre', 'Chambre Parentale');
  const ch2 = addRoom(1, 460, 0, 390, 260, 'bureau', 'Chambre / Bureau');
  const sdb = addRoom(1, 0, 350, 350, 250, 'sdb', 'Salle de bains');
  const wc1 = addRoom(1, 350, 350, 150, 160, 'wc', 'WC Étage');

  addFloor(palier, 'staircase', 740, 340, {
    rot: 90,
    w: 110,
    h: 220,
    stepCount: 14,
    ledColor: 'warm',
    wattsPerStep: 2,
    name: 'Arrivée Escalier',
  });
  addFloor(palier, 'light', 575, 340);
  addFloor(palier, 'smoke', 550, 290);
  addWall(palier, 'pushbutton', 'left', 310);
  addWall(palier, 'siren', 'top', 580);
  addWall(palier, 'socket', 'bottom', 560);

  addWall(ch1, 'door', 'right', 290);
  addWall(ch1, 'window', 'top', 230, { len: 130 });
  addFloor(ch1, 'light', 230, 175);
  addFloor(ch1, 'neon', 230, 35, { len: 200 });
  addWall(ch1, 'switch', 'right', 230);
  addWall(ch1, 'usb_socket', 'left', 90);
  addWall(ch1, 'usb_socket', 'left', 260);
  addWall(ch1, 'socket', 'bottom', 180);
  addWall(ch1, 'rj45', 'bottom', 300);
  addWall(ch1, 'heater', 'top', 110, { name: 'Rad. Chambre 1', watts: 1000 });
  addFloor(ch1, 'bed2', 110, 175, { rot: 90 });
  addFloor(ch1, 'wardrobe', 390, 45);

  addWall(ch2, 'door', 'bottom', 560);
  addWall(ch2, 'window', 'top', 655, { len: 110 });
  addFloor(ch2, 'light', 655, 130);
  addWall(ch2, 'switch', 'bottom', 510);
  addWall(ch2, 'socket2', 'top', 560);
  addWall(ch2, 'socket', 'right', 130);
  addWall(ch2, 'rj45', 'top', 750);
  addWall(ch2, 'heater', 'right', 60, { name: 'Rad. Bureau', watts: 1000 });
  addFloor(ch2, 'desk', 655, 50);
  addFloor(ch2, 'pc', 655, 45);

  addWall(sdb, 'door', 'right', 420, { len: 80 });
  addWall(sdb, 'window', 'left', 475, { len: 60 });
  addFloor(sdb, 'light', 175, 475);
  addWall(sdb, 'sconce', 'top', 180);
  addWall(sdb, 'switch', 'right', 380);
  addWall(sdb, 'socket', 'right', 530);
  addWall(sdb, 'spec', 'bottom', 260, { name: 'Lave-linge', watts: 2500 });
  addWall(sdb, 'heater', 'right', 560, { name: 'Sèche-serviette', watts: 750 });
  addFloor(sdb, 'bath', 95, 550);
  addFloor(sdb, 'sink', 180, 385);

  addWall(wc1, 'door', 'right', 400, { len: 80 });
  addFloor(wc1, 'light', 425, 430);
  addWall(wc1, 'motion', 'right', 370);
  addFloor(wc1, 'wc', 425, 555);

  return {
    floors,
    activeFloorId: 0,
    finishStyle: 'blanc_mat',
    rooms,
    items,
    nextId,
    k: 0.6,
    sockMode: 8,
    includeSurgeProtector: true,
    subscriptionKva: 12,
  };
}

export function createExampleT3Project(): PlanProjectData {
  const house = createMultiStoryHouseProject();
  return {
    ...house,
    floors: [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }],
    activeFloorId: 0,
    rooms: house.rooms.filter((r) => r.floorId === 0),
    items: house.items.filter((i) => i.floorId === 0),
    subscriptionKva: 9,
  };
}

export function createStudioProject(): PlanProjectData {
  let nextId = 1;
  const floors: FloorLevel[] = [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }];
  const rooms: Room[] = [];
  const items: PlanItem[] = [];

  const addRoom = (x: number, y: number, w: number, h: number, type: RoomType, name: string) => {
    const r: Room = { id: nextId++, floorId: 0, x, y, w, h, type, name };
    rooms.push(r);
    return r;
  };
  const addWall = (r: Room, type: ItemType, side: WallSide, along: number, extra: Partial<PlanItem> = {}) => {
    const T = TYPES[type];
    const len = extra.len ?? T.len;
    const half = len && T.struct ? len / 2 + 6 : T.half ?? 16;
    const pos = wallPosSeed(r, side, along, half);
    const it: PlanItem = {
      id: nextId++,
      floorId: 0,
      type,
      x: pos.x,
      y: pos.y,
      roomId: r.id,
      side,
      rot: 0,
      name: '',
      watts: T.watts,
      ...(len ? { len } : {}),
      ...extra,
    };
    items.push(it);
    return it;
  };
  const addFloor = (r: Room, type: ItemType, x: number, y: number, extra: Partial<PlanItem> = {}) => {
    const T = TYPES[type];
    const it: PlanItem = {
      id: nextId++,
      floorId: 0,
      type,
      x,
      y,
      roomId: r.id,
      side: null,
      rot: 0,
      name: '',
      watts: T.watts,
      ...(T.furn ? { w: T.w, h: T.h } : {}),
      ...extra,
    };
    items.push(it);
    return it;
  };

  const main = addRoom(0, 0, 520, 420, 'sejour', 'Pièce de vie');
  const sdb = addRoom(520, 0, 220, 240, 'sdb', 'Salle d’eau');
  const ent = addRoom(520, 240, 220, 180, 'couloir', 'Entrée / Kitchenette');

  addWall(ent, 'panel', 'right', 320);
  addWall(ent, 'door', 'bottom', 630);
  addWall(sdb, 'door', 'bottom', 600, { len: 80 });
  addWall(main, 'window', 'top', 260, { len: 140 });

  addFloor(main, 'light', 260, 210);
  addFloor(sdb, 'light', 630, 120);
  addFloor(ent, 'light', 630, 330);
  addFloor(ent, 'smoke', 630, 270);

  addWall(main, 'switch', 'right', 290);
  addWall(sdb, 'switch', 'bottom', 560);
  addWall(ent, 'switch', 'bottom', 700);

  addWall(main, 'socket', 'top', 100);
  addWall(main, 'usb_socket', 'top', 420);
  addWall(main, 'socket', 'left', 140);
  addWall(main, 'socket', 'left', 320);
  addWall(main, 'socket', 'bottom', 260);
  addWall(main, 'rj45', 'left', 220);
  addWall(main, 'heater', 'top', 260, { name: 'Radiateur séjour', watts: 1500 });

  addWall(ent, 'cooktop', 'top', 650, { watts: 3500 });
  addWall(ent, 'socket2', 'right', 290);
  addWall(ent, 'spec', 'left', 350, { name: 'Chauffe-eau', watts: 1800 });

  addWall(sdb, 'socket', 'top', 580);
  addWall(sdb, 'heater', 'right', 120, { name: 'Sèche-serviette', watts: 500 });

  addFloor(main, 'sofa', 130, 360, { rot: 180 });
  addFloor(main, 'desk', 410, 70);
  addFloor(main, 'pc', 410, 65);
  addFloor(sdb, 'shower', 690, 50);
  addFloor(sdb, 'wc', 560, 45);

  return {
    floors,
    activeFloorId: 0,
    finishStyle: 'anthracite',
    rooms,
    items,
    nextId,
    k: 0.7,
    sockMode: 8,
    includeSurgeProtector: false,
    subscriptionKva: 6,
  };
}
