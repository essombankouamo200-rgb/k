import { ItemType } from '../types/planelec';

/**
 * Catalogue central des modèles GLB d'équipements (unités : mètres, axe +Z = face avant,
 * dos de l'appareil à Z ≈ 0, centré sur X/Y). Les GLB sont des représentations visuelles :
 * ils ne modifient ni la logique électrique, ni les identifiants métier, ni les collisions.
 */
export interface GlbDef {
  /** nom du fichier dans src/assets/glb */
  file: string;
  label: string;
  /** dimensions nominales (m) : largeur, hauteur, profondeur hors-tout */
  size: [number, number, number];
  /** nom du matériau de la plaque à teinter selon la finition du projet (facultatif) */
  plateMaterial?: string;
  /** décalage Z (m) ajouté à la surface du mur intérieur (> 0 = en saillie) */
  zOffset: number;
}

export const GLB_DEFS: Record<string, GlbDef> = {
  prise: { file: 'prise_2p_t.glb', label: 'Prise 2P+T', size: [0.086, 0.086, 0.036], plateMaterial: 'Porcelaine blanche', zOffset: 0 },
  prise_double: { file: 'prise_double_2p_t.glb', label: 'Double prise 2P+T', size: [0.16, 0.086, 0.036], plateMaterial: 'Porcelaine blanche', zOffset: 0 },
  interrupteur: { file: 'interrupteur.glb', label: 'Interrupteur', size: [0.086, 0.086, 0.038], plateMaterial: 'Porcelaine blanche', zOffset: 0 },
  variateur: { file: 'variateur.glb', label: 'Variateur rotatif', size: [0.086, 0.086, 0.056], plateMaterial: 'Porcelaine blanche', zOffset: 0 },
  rj45: { file: 'rj45.glb', label: 'Prise RJ45', size: [0.086, 0.086, 0.036], plateMaterial: 'Porcelaine blanche', zOffset: 0 },
  usb: { file: 'usb.glb', label: 'Prise USB', size: [0.086, 0.086, 0.034], plateMaterial: 'Porcelaine blanche', zOffset: 0 },
  // Tableau semi-encastré : le fond (Z < 0) est noyé dans le mur.
  tableau: { file: 'tableau_electrique_modulaire.glb', label: 'Tableau modulaire', size: [0.42, 0.58, 0.196], zOffset: 0 },
  // Pas encore branchés sur le rendu du câblage (Phase 3) : chargés et disponibles.
  boite_derivation: { file: 'boite_derivation_ouverte.glb', label: 'Boîte de dérivation', size: [0.276, 0.149, 0.099], zOffset: 0 },
  gaine_icta: { file: 'gaine_icta_3_conducteurs.glb', label: 'Gaine ICTA 3 conducteurs', size: [0.03, 0.456, 0.03], zOffset: 0 },
};

/** Type d'équipement du plan → modèle GLB. */
export const GLB_BY_ITEM_TYPE: Partial<Record<ItemType, keyof typeof GLB_DEFS>> = {
  socket: 'prise',
  socket2: 'prise_double',
  switch: 'interrupteur',
  pushbutton: 'interrupteur',
  dimmer: 'variateur',
  rj45: 'rj45',
  usb_socket: 'usb',
  panel: 'tableau',
};
