import { FloorLevel, ItemType, PlanItem, PlanProjectData, Room, RoomType, WallSide } from '../types/planelec';
import { TYPES } from './catalog';
import { withDecor } from './decorPresets';

type Dir = WallSide;

interface RoomSpec {
  floor?: number;
  x: number;
  y: number;
  w: number;
  h: number;
  type: RoomType;
  name: string;
  /** mur par lequel on entre (porte) */
  door?: Dir;
  /** mur de la fenêtre */
  window?: Dir;
  /** équipements supplémentaires : [type, mur, position le long du mur, extras] */
  extra?: [ItemType, Dir, number, Partial<PlanItem>?][];
  /** mobilier au sol : [type, x, y, rot?] (coordonnées relatives à la pièce) */
  furn?: [ItemType, number, number, number?][];
  wallFinish?: Room['wallFinish'];
}

export interface HouseModel {
  id: string;
  label: string;
  description: string;
  area: string;
  build: () => PlanProjectData;
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const snap5 = (v: number) => Math.round(v / 5) * 5;

function assemble(
  specs: RoomSpec[],
  opts: { floors?: FloorLevel[]; panelRoom: number; k?: number; kva?: 6 | 9 | 12 | 15; sock?: 8 | 12; ac?: number[]; extraItems?: (g: Gen) => void }
): PlanProjectData {
  const floors: FloorLevel[] = opts.floors ?? [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }];
  const rooms: Room[] = [];
  const items: PlanItem[] = [];
  let nextId = 1;

  const g: Gen = {
    rooms,
    items,
    wall(r, type, side, along, extra = {}) {
      const T = TYPES[type];
      const len = extra.len ?? T.len;
      const half = len && T.struct ? len / 2 + 6 : T.half ?? 16;
      let x: number;
      let y: number;
      if (side === 'top' || side === 'bottom') {
        x = clamp(snap5(along), r.x + half, r.x + r.w - half);
        y = side === 'top' ? r.y : r.y + r.h;
      } else {
        x = side === 'left' ? r.x : r.x + r.w;
        y = clamp(snap5(along), r.y + half, r.y + r.h - half);
      }
      const it: PlanItem = {
        id: nextId++,
        floorId: r.floorId,
        type,
        x,
        y,
        roomId: r.id,
        side,
        rot: 0,
        name: '',
        watts: T.watts,
        ...(len ? { len } : {}),
        ...extra,
      };
      items.push(it);
      return it;
    },
    floor(r, type, x, y, extra = {}) {
      const T = TYPES[type];
      const it: PlanItem = {
        id: nextId++,
        floorId: r.floorId,
        type,
        x,
        y,
        roomId: r.id,
        side: null,
        rot: 0,
        name: '',
        watts: T.watts,
        ...(T.furn ? { w: T.w, h: T.h } : {}),
        ...extra,
      };
      items.push(it);
      return it;
    },
  };

  const made: Room[] = specs.map((s) => {
    const r: Room = { id: nextId++, floorId: s.floor ?? 0, x: s.x, y: s.y, w: s.w, h: s.h, type: s.type, name: s.name };
    if (s.wallFinish) r.wallFinish = s.wallFinish;
    rooms.push(r);
    return r;
  });

  const opposite: Record<Dir, Dir> = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
  const mid = (r: Room, side: Dir) => (side === 'top' || side === 'bottom' ? r.x + r.w / 2 : r.y + r.h / 2);
  const span = (r: Room, side: Dir) => (side === 'top' || side === 'bottom' ? r.w : r.h);
  const at = (r: Room, side: Dir, f: number) =>
    (side === 'top' || side === 'bottom' ? r.x : r.y) + span(r, side) * f;

  made.forEach((r, i) => {
    const s = specs[i];
    const doorSide = s.door ?? 'bottom';
    if (s.type !== 'terrasse') {
      g.wall(r, 'door', doorSide, mid(r, doorSide) - 30, { len: r.type === 'sdb' || r.type === 'wc' ? 75 : 90 });
    }
    if (s.window && s.type !== 'wc') {
      g.wall(r, 'window', s.window, mid(r, s.window), { len: Math.min(150, span(r, s.window) * 0.5) });
    }
    // éclairage + commande près de la porte
    if (s.type !== 'terrasse') {
      g.floor(r, s.type === 'sejour' || s.type === 'garage' ? 'spots' : 'light', r.x + r.w / 2, r.y + r.h / 2);
      const swSide = doorSide;
      g.wall(r, s.type === 'sejour' ? 'dimmer' : 'switch', swSide, mid(r, swSide) + 70, {});
    } else {
      g.wall(r, 'sconce', 'top', mid(r, 'top'));
      g.wall(r, 'socket2', 'left', mid(r, 'left'));
    }
    // prises
    const back = opposite[doorSide];
    switch (s.type) {
      case 'chambre':
        g.wall(r, 'socket', back, at(r, back, 0.2));
        g.wall(r, 'socket', back, at(r, back, 0.8));
        g.wall(r, 'socket', window_side(s, doorSide), at(r, window_side(s, doorSide), 0.8));
        g.floor(r, 'bed2', r.x + r.w / 2, r.y + r.h * 0.4);
        g.floor(r, 'wardrobe', r.x + 45, r.y + r.h - 35);
        break;
      case 'sejour':
        g.wall(r, 'socket', back, at(r, back, 0.15));
        g.wall(r, 'socket', back, at(r, back, 0.5));
        g.wall(r, 'rj45', back, at(r, back, 0.7));
        g.wall(r, 'usb_socket', back, at(r, back, 0.88));
        g.wall(r, 'socket', 'left', at(r, 'left', 0.5));
        g.floor(r, 'sofa', r.x + r.w / 2, r.y + r.h * 0.65);
        g.floor(r, 'table', r.x + r.w / 2, r.y + r.h * 0.4);
        break;
      case 'cuisine':
        g.wall(r, 'socket2', back, at(r, back, 0.2));
        g.wall(r, 'socket2', back, at(r, back, 0.45));
        g.wall(r, 'cooktop', back, at(r, back, 0.72), { watts: 3500 });
        g.floor(r, 'fridge', r.x + r.w - 40, r.y + 40);
        g.floor(r, 'sink', r.x + 50, r.y + 40);
        break;
      case 'sdb':
        g.wall(r, 'socket', back, at(r, back, 0.5));
        g.wall(r, 'spec', back, at(r, back, 0.85), { name: 'Chauffe-eau', watts: 1800 });
        g.floor(r, 'shower', r.x + r.w - 50, r.y + 50);
        g.floor(r, 'sink', r.x + 45, r.y + r.h - 40);
        break;
      case 'wc':
        g.floor(r, 'wc', r.x + r.w / 2, r.y + r.h - 45);
        break;
      case 'bureau':
        g.wall(r, 'socket', back, at(r, back, 0.25));
        g.wall(r, 'socket', back, at(r, back, 0.6));
        g.wall(r, 'rj45', back, at(r, back, 0.8));
        g.floor(r, 'desk', r.x + r.w / 2, r.y + 60);
        g.floor(r, 'pc', r.x + r.w / 2, r.y + 55);
        break;
      case 'garage':
        g.wall(r, 'socket2', back, at(r, back, 0.2));
        g.wall(r, 'irve', back, at(r, back, 0.7), { name: 'Borne VE' });
        break;
      case 'couloir':
        g.wall(r, 'socket', back, at(r, back, 0.5));
        g.wall(r, 'smoke' as ItemType, back, at(r, back, 0.3));
        break;
      default:
        g.wall(r, 'socket', back, at(r, back, 0.5));
    }
    for (const [t, side, along, extra] of s.extra ?? []) g.wall(r, t, side, at(r, side, along), extra ?? {});
    for (const [t, fx, fy, rot] of s.furn ?? []) g.floor(r, t, r.x + fx, r.y + fy, rot ? { rot } : {});
  });

  // tableau électrique dans la pièce désignée
  const pr = made[opts.panelRoom];
  const pSide: Dir = specs[opts.panelRoom].door === 'left' ? 'right' : 'left';
  g.wall(pr, 'panel', pSide, pr.y + pr.h * 0.4);
  for (const idx of opts.ac ?? []) {
    const r = made[idx];
    const side: Dir = specs[idx].window ? opposite[specs[idx].window as Dir] : 'top';
    g.wall(r, 'ac_split', side, at(r, side, 0.5));
  }
  opts.extraItems?.(g);

  return {
    floors,
    activeFloorId: 0,
    finishStyle: 'blanc_mat',
    rooms,
    items,
    nextId,
    k: opts.k ?? 0.65,
    sockMode: opts.sock ?? 8,
    includeSurgeProtector: true,
    subscriptionKva: opts.kva ?? 9,
  };
}

function window_side(s: RoomSpec, doorSide: Dir): Dir {
  return s.window ?? (doorSide === 'top' ? 'bottom' : 'top');
}

export interface Gen {
  rooms: Room[];
  items: PlanItem[];
  wall: (r: Room, type: ItemType, side: Dir, along: number, extra?: Partial<PlanItem>) => PlanItem;
  floor: (r: Room, type: ItemType, x: number, y: number, extra?: Partial<PlanItem>) => PlanItem;
}

const F2: FloorLevel[] = [
  { id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 },
  { id: 1, name: '1er étage', elevationIndex: 1 },
];

const RAW_HOUSE_MODELS: HouseModel[] = [
  {
    id: 'f2',
    label: 'F2 économique (2 pièces)',
    description: 'Salon, chambre, cuisine et douche — logement d’entrée de gamme.',
    area: '≈ 42 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 420, h: 300, type: 'sejour', name: 'Salon', door: 'bottom', window: 'top' },
          { x: 420, y: 0, w: 300, h: 300, type: 'chambre', name: 'Chambre', door: 'left', window: 'top' },
          { x: 0, y: 300, w: 300, h: 180, type: 'cuisine', name: 'Cuisine', door: 'top', window: 'bottom' },
          { x: 300, y: 300, w: 200, h: 180, type: 'sdb', name: 'Douche / WC', door: 'top' },
        ],
        { panelRoom: 0, kva: 6, sock: 8, ac: [0] }
      ),
  },
  {
    id: 'f3',
    label: 'F3 familial plain-pied',
    description: 'Salon, 2 chambres, cuisine, salle de bain, WC, couloir.',
    area: '≈ 85 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 520, h: 400, type: 'sejour', name: 'Salon / Séjour', door: 'right', window: 'top' },
          { x: 520, y: 0, w: 300, h: 160, type: 'cuisine', name: 'Cuisine', door: 'left', window: 'top' },
          { x: 520, y: 160, w: 300, h: 80, type: 'couloir', name: 'Couloir', door: 'left' },
          { x: 520, y: 240, w: 300, h: 220, type: 'chambre', name: 'Chambre parents', door: 'top', window: 'right' },
          { x: 0, y: 400, w: 300, h: 260, type: 'chambre', name: 'Chambre enfants', door: 'top', window: 'bottom' },
          { x: 300, y: 400, w: 220, h: 160, type: 'sdb', name: 'Salle de bain', door: 'top' },
          { x: 300, y: 560, w: 220, h: 100, type: 'wc', name: 'WC', door: 'top' },
        ],
        { panelRoom: 2, kva: 9, ac: [0, 3, 4] }
      ),
  },
  {
    id: 'f4',
    label: 'F4 plain-pied + terrasse',
    description: 'Séjour ouvert, 3 chambres, cuisine, 2 sanitaires et terrasse couverte.',
    area: '≈ 120 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 600, h: 420, type: 'sejour', name: 'Séjour', door: 'right', window: 'top' },
          { x: 600, y: 0, w: 320, h: 220, type: 'cuisine', name: 'Cuisine', door: 'left', window: 'top' },
          { x: 600, y: 220, w: 320, h: 80, type: 'couloir', name: 'Couloir', door: 'left' },
          { x: 600, y: 300, w: 320, h: 260, type: 'chambre', name: 'Chambre parents', door: 'top', window: 'right' },
          { x: 0, y: 420, w: 300, h: 260, type: 'chambre', name: 'Chambre 2', door: 'top', window: 'left' },
          { x: 300, y: 420, w: 300, h: 260, type: 'chambre', name: 'Chambre 3', door: 'top', window: 'bottom' },
          { x: 600, y: 560, w: 160, h: 120, type: 'sdb', name: 'Salle de bain', door: 'top' },
          { x: 760, y: 560, w: 160, h: 120, type: 'wc', name: 'WC', door: 'top' },
          { x: 0, y: 680, w: 600, h: 240, type: 'terrasse', name: 'Terrasse' },
        ],
        { panelRoom: 2, kva: 12, ac: [0, 3, 4, 5] }
      ),
  },
  {
    id: 'villa_r1',
    label: 'Villa R+1 (4 chambres)',
    description: 'RDC : séjour, cuisine, bureau, garage ; étage : 4 chambres et 2 salles de bain.',
    area: '≈ 190 m²',
    build: () => {
      const p = assemble(
        [
          { x: 0, y: 0, w: 640, h: 440, type: 'sejour', name: 'Grand séjour', door: 'right', window: 'top' },
          { x: 640, y: 0, w: 300, h: 260, type: 'cuisine', name: 'Cuisine', door: 'left', window: 'top' },
          { x: 640, y: 260, w: 300, h: 180, type: 'bureau', name: 'Bureau', door: 'left', window: 'right' },
          { x: 0, y: 440, w: 400, h: 300, type: 'garage', name: 'Garage', door: 'top' },
          { x: 400, y: 440, w: 540, h: 300, type: 'couloir', name: 'Hall / Escalier', door: 'top' },
          { floor: 1, x: 0, y: 0, w: 400, h: 340, type: 'chambre', name: 'Chambre parents', door: 'bottom', window: 'top' },
          { floor: 1, x: 400, y: 0, w: 260, h: 220, type: 'sdb', name: 'Salle de bain parents', door: 'left' },
          { floor: 1, x: 660, y: 0, w: 280, h: 340, type: 'chambre', name: 'Chambre 2', door: 'bottom', window: 'top' },
          { floor: 1, x: 0, y: 340, w: 360, h: 300, type: 'chambre', name: 'Chambre 3', door: 'top', window: 'left' },
          { floor: 1, x: 360, y: 340, w: 300, h: 300, type: 'couloir', name: 'Palier', door: 'top' },
          { floor: 1, x: 660, y: 340, w: 280, h: 300, type: 'chambre', name: 'Chambre 4', door: 'top', window: 'right' },
        ],
        { floors: F2, panelRoom: 4, kva: 15, ac: [0, 5, 7, 8, 10] }
      );
      return p;
    },
  },
  {
    id: 'duplex',
    label: 'Duplex moderne',
    description: 'Séjour-cuisine ouvert en bas, 3 chambres et bureau à l’étage.',
    area: '≈ 140 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 700, h: 460, type: 'sejour', name: 'Séjour / Cuisine ouverte', door: 'bottom', window: 'top' },
          { x: 700, y: 0, w: 220, h: 230, type: 'wc', name: 'WC invités', door: 'left' },
          { x: 700, y: 230, w: 220, h: 230, type: 'couloir', name: 'Entrée / Escalier', door: 'bottom' },
          { floor: 1, x: 0, y: 0, w: 360, h: 300, type: 'chambre', name: 'Suite parentale', door: 'bottom', window: 'top' },
          { floor: 1, x: 360, y: 0, w: 280, h: 300, type: 'chambre', name: 'Chambre 2', door: 'bottom', window: 'top' },
          { floor: 1, x: 640, y: 0, w: 280, h: 300, type: 'bureau', name: 'Bureau', door: 'bottom', window: 'top' },
          { floor: 1, x: 0, y: 300, w: 300, h: 160, type: 'sdb', name: 'Salle de bain', door: 'top' },
          { floor: 1, x: 300, y: 300, w: 620, h: 160, type: 'couloir', name: 'Palier', door: 'top' },
        ],
        { floors: F2, panelRoom: 2, kva: 12, ac: [0, 3, 4] }
      ),
  },
  {
    id: 'boutique',
    label: 'Boutique + arrière-boutique',
    description: 'Local commercial : salle de vente, réserve, bureau, sanitaires.',
    area: '≈ 70 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 600, h: 380, type: 'autre', name: 'Salle de vente', door: 'bottom', window: 'top', extra: [['camera', 'top', 0.1, {}]] },
          { x: 600, y: 0, w: 220, h: 200, type: 'bureau', name: 'Bureau', door: 'left', window: 'top' },
          { x: 600, y: 200, w: 220, h: 180, type: 'autre', name: 'Réserve', door: 'left' },
          { x: 0, y: 380, w: 220, h: 120, type: 'wc', name: 'WC', door: 'top' },
        ],
        { panelRoom: 2, kva: 9, ac: [0, 1] }
      ),
  },
  {
    id: 'bureaux',
    label: 'Plateau de bureaux',
    description: 'Open space, 2 bureaux, salle de réunion, local technique, sanitaires.',
    area: '≈ 110 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 640, h: 420, type: 'bureau', name: 'Open space', door: 'right', window: 'top', extra: [['camera', 'left', 0.2, {}]] },
          { x: 640, y: 0, w: 280, h: 210, type: 'bureau', name: 'Bureau direction', door: 'left', window: 'top' },
          { x: 640, y: 210, w: 280, h: 210, type: 'bureau', name: 'Salle de réunion', door: 'left', window: 'right' },
          { x: 0, y: 420, w: 300, h: 140, type: 'autre', name: 'Local technique', door: 'top' },
          { x: 300, y: 420, w: 160, h: 140, type: 'wc', name: 'WC', door: 'top' },
          { x: 460, y: 420, w: 460, h: 140, type: 'couloir', name: 'Accueil', door: 'top', window: 'bottom' },
        ],
        { panelRoom: 3, kva: 12, ac: [0, 1, 2, 5] }
      ),
  },
  {
    id: 'bungalow',
    label: 'Bungalow 2 chambres + véranda',
    description: 'Petite maison de campagne avec véranda ombragée.',
    area: '≈ 75 m²',
    build: () =>
      assemble(
        [
          { x: 0, y: 0, w: 460, h: 340, type: 'sejour', name: 'Salon', door: 'bottom', window: 'top' },
          { x: 460, y: 0, w: 280, h: 200, type: 'chambre', name: 'Chambre 1', door: 'left', window: 'top' },
          { x: 460, y: 200, w: 280, h: 140, type: 'cuisine', name: 'Cuisine', door: 'left', window: 'right' },
          { x: 0, y: 340, w: 280, h: 200, type: 'chambre', name: 'Chambre 2', door: 'top', window: 'left' },
          { x: 280, y: 340, w: 180, h: 200, type: 'sdb', name: 'Douche / WC', door: 'top' },
          { x: 460, y: 340, w: 280, h: 200, type: 'terrasse', name: 'Véranda' },
        ],
        { panelRoom: 0, kva: 6, sock: 8, ac: [1] }
      ),
  },
];

/** Modèles prédéfinis, livrés avec leurs décors extérieurs (clôture, portail, jardin, véhicules…). */
export const HOUSE_MODELS: HouseModel[] = RAW_HOUSE_MODELS.map((m) => ({
  ...m,
  build: () => withDecor(m.build(), m.id),
}));
