import { EnvKind, EnvObject, GroundStyle } from '../types/planelec';

export interface EnvDef {
  kind: EnvKind;
  label: string;
  group: 'Végétation' | 'Clôture & accès' | 'Aménagement' | 'Technique';
  /** Dimensions par défaut (cm). */
  defaults: Pick<EnvObject, 'len' | 'w' | 'h'>;
  /** Paramètres redimensionnables dans le panneau. */
  resize?: 'len' | 'area';
}

export const ENV_DEFS: Record<EnvKind, EnvDef> = {
  tree: { kind: 'tree', label: 'Arbre (manguier)', group: 'Végétation', defaults: {} },
  palm: { kind: 'palm', label: 'Palmier', group: 'Végétation', defaults: {} },
  bush: { kind: 'bush', label: 'Arbuste', group: 'Végétation', defaults: {} },
  hedge: { kind: 'hedge', label: 'Haie', group: 'Végétation', defaults: { len: 300 }, resize: 'len' },
  lawn: { kind: 'lawn', label: 'Pelouse', group: 'Végétation', defaults: { w: 400, h: 300 }, resize: 'area' },
  wall: { kind: 'wall', label: 'Mur de clôture', group: 'Clôture & accès', defaults: { len: 600 }, resize: 'len' },
  fence: { kind: 'fence', label: 'Clôture grillagée', group: 'Clôture & accès', defaults: { len: 500 }, resize: 'len' },
  gate: { kind: 'gate', label: 'Portail coulissant', group: 'Clôture & accès', defaults: { len: 400 }, resize: 'len' },
  path: { kind: 'path', label: 'Allée dallée', group: 'Aménagement', defaults: { len: 500, w: 120 }, resize: 'area' },
  pool: { kind: 'pool', label: 'Piscine', group: 'Aménagement', defaults: { w: 500, h: 250 }, resize: 'area' },
  car: { kind: 'car', label: 'Voiture', group: 'Aménagement', defaults: {} },
  garden_light: { kind: 'garden_light', label: 'Lampadaire de jardin', group: 'Technique', defaults: {} },
  generator: { kind: 'generator', label: 'Groupe électrogène', group: 'Technique', defaults: {} },
  solar: { kind: 'solar', label: 'Panneaux solaires', group: 'Technique', defaults: { len: 340 }, resize: 'len' },
  tank: { kind: 'tank', label: 'Château d’eau / citerne', group: 'Technique', defaults: {} },
};

export const ENV_GROUPS: EnvDef['group'][] = ['Végétation', 'Clôture & accès', 'Aménagement', 'Technique'];

export const GROUND_STYLES: { id: GroundStyle; label: string; hex: string }[] = [
  { id: 'neutre', label: 'Neutre', hex: '#e2e8f0' },
  { id: 'herbe', label: 'Pelouse', hex: '#6aa84f' },
  { id: 'terre', label: 'Terre latéritique', hex: '#b5651d' },
  { id: 'sable', label: 'Sable', hex: '#e5d3a1' },
  { id: 'dalles', label: 'Dallage', hex: '#cbd5e1' },
];

/** Rayon approximatif (cm) de l'empreinte au sol, pour l'anneau de sélection. */
export function envFootprintRadiusCm(o: EnvObject): number {
  const s = o.scale ?? 1;
  switch (o.kind) {
    case 'tree':
      return 170 * s;
    case 'palm':
      return 120 * s;
    case 'bush':
      return 60 * s;
    case 'garden_light':
      return 30 * s;
    case 'car':
      return 240 * s;
    case 'generator':
      return 70 * s;
    case 'tank':
      return 90 * s;
    case 'hedge':
    case 'wall':
    case 'fence':
    case 'gate':
    case 'solar':
      return ((o.len ?? ENV_DEFS[o.kind].defaults.len ?? 300) / 2) * s;
    case 'path':
      return Math.max(o.len ?? 500, o.w ?? 120) / 2;
    case 'lawn':
    case 'pool':
      return Math.hypot(o.w ?? 400, o.h ?? 300) / 2;
  }
}

export function makeEnvObject(kind: EnvKind, id: number, x: number, y: number): EnvObject {
  return { id, kind, x: Math.round(x), y: Math.round(y), rot: 0, scale: 1, ...ENV_DEFS[kind].defaults };
}
