import { HOUSE_MODELS } from './data/houseModels';
import { withDecor } from './data/decorPresets';
import { COMPANY } from './data/company';
import { LOGO_DATA_URI } from './utils/brand';
import { buildPlanSvg } from './utils/planSvg';
import { brandSvg, buildReportHtml, defaultReference, loadBudgetPrefs, loadDocInfo, printHtml } from './utils/reportExport';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Activity,
  Box,
  Boxes,
  CircuitBoard,
  Command,
  Download,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  Layers,
  LayoutGrid,
  Lightbulb,
  Moon,
  Printer,
  Redo2,
  Search,
  Sparkles,
  Sun,
  Undo2,
  Upload,
  Wallet,
  X,
  Zap,
} from 'lucide-react';
import {
  AppViewMode,
  FloorLevel,
  ItemType,
  PlanItem,
  PlanProjectData,
  Room,
  SelectionTarget,
} from './types/planelec';
import {
  createExampleT3Project,
  createMultiStoryHouseProject,
  createStudioProject,
  DEFAULT_UNIT_PRICES,
} from './data/catalog';
import { frNum, runElectricalSimulation } from './utils/electricalEngine';
import { formatFcfa } from './utils/formatters';
import { describeAdded, reconcileCompanions } from './utils/companions';
import { Plan2DEditor } from './components/Plan2DEditor';
import { ManualWiringLab } from './components/ManualWiringLab';
import { PanelSchematicView } from './components/PanelSchematicView';
import { Building3DView } from './components/Building3DView';
import { ResultsSidebar } from './components/ResultsSidebar';
import { BudgetReportView } from './components/BudgetReportView';
import { LiveSimulationView } from './components/LiveSimulationView';
import { CommandPalette, PaletteCommand } from './components/CommandPalette';
import { TYPES } from './data/catalog';

declare global {
  interface Window {
    planelec?: {
      isElectron: true;
      saveFile: (opts: { defaultPath: string; content: string; filters?: { name: string; extensions: string[] }[] }) => Promise<{ ok: boolean; path?: string }>;
      openFile: (opts: { filters?: { name: string; extensions: string[] }[] }) => Promise<{ ok: boolean; content?: string; path?: string }>;
      exportPdf: (opts: { defaultPath: string }) => Promise<{ ok: boolean; path?: string }>;
    };
  }
}

const VIEW_META: { id: AppViewMode; label: string; short: string }[] = [
  { id: 'plan2d', label: 'Plan 2D', short: 'Plan' },
  { id: 'cablage', label: 'Câblage & Bibliothèque', short: 'Câblage' },
  { id: 'tableau', label: 'Tableau & Schéma', short: 'Tableau' },
  { id: 'vue3d', label: 'Vue 3D', short: '3D' },
  { id: 'simu', label: 'Simulation live', short: 'Live' },
  { id: 'devis', label: 'Matériel & Devis', short: 'Devis' },
];

const STORAGE_KEY = 'planelec.studio.v2';
// v2 : tarifs exprimés en FCFA (la v1 stockait des euros, on ne la réutilise pas)
const PRICES_KEY = 'planelec.prices.fcfa.v2';
const THEME_KEY = 'planelec.theme.v1';
const AUTO_EQUIP_KEY = 'planelec.autoEquip.v1';

function normalizeProject(parsed: Partial<PlanProjectData>): PlanProjectData {
  const floors: FloorLevel[] =
    Array.isArray(parsed.floors) && parsed.floors.length > 0
      ? parsed.floors
      : [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }];
  const defaultFloorId = floors[0].id;
  const rooms: Room[] = Array.isArray(parsed.rooms)
    ? parsed.rooms.map((r) => ({ ...r, floorId: r.floorId ?? defaultFloorId }))
    : [];
  const items: PlanItem[] = Array.isArray(parsed.items)
    ? parsed.items.map((i) => ({ ...i, floorId: i.floorId ?? defaultFloorId }))
    : [];

  return {
    floors,
    activeFloorId:
      typeof parsed.activeFloorId === 'number' &&
      floors.some((f) => f.id === parsed.activeFloorId)
        ? parsed.activeFloorId
        : defaultFloorId,
    finishStyle: parsed.finishStyle ?? 'blanc_mat',
    rooms,
    items,
    nextId:
      parsed.nextId ||
      Math.max(
        1,
        ...floors.map((f) => f.id),
        ...rooms.map((r) => r.id),
        ...items.map((i) => i.id)
      ) + 1,
    k: typeof parsed.k === 'number' ? parsed.k : 0.6,
    sockMode: parsed.sockMode === 12 ? 12 : 8,
    includeSurgeProtector:
      typeof parsed.includeSurgeProtector === 'boolean'
        ? parsed.includeSurgeProtector
        : true,
    subscriptionKva:
      parsed.subscriptionKva && [6, 9, 12, 15].includes(parsed.subscriptionKva)
        ? parsed.subscriptionKva
        : 12,
    env: Array.isArray(parsed.env) ? parsed.env : [],
    groundStyle: parsed.groundStyle ?? 'neutre',
  };
}

function loadInitialProject(): PlanProjectData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.rooms) && Array.isArray(parsed.items)) {
        return normalizeProject(parsed);
      }
    }
  } catch {
    // Ignore parse errors
  }
  return withDecor(createMultiStoryHouseProject(), 'house');
}

function loadInitialPrices(): Record<string, number> {
  try {
    const raw = localStorage.getItem(PRICES_KEY);
    if (raw) {
      return { ...DEFAULT_UNIT_PRICES, ...JSON.parse(raw) };
    }
  } catch {
    // Ignore parse errors
  }
  return { ...DEFAULT_UNIT_PRICES };
}

function loadInitialAutoEquip(): boolean {
  try {
    return localStorage.getItem(AUTO_EQUIP_KEY) !== 'off';
  } catch {
    return true;
  }
}

function loadInitialTheme(): boolean {
  try {
    return localStorage.getItem(THEME_KEY) === 'dark';
  } catch {
    return false;
  }
}

export default function App() {
  const [project, setProject] = useState<PlanProjectData>(loadInitialProject);
  const [past, setPast] = useState<PlanProjectData[]>([]);
  const [future, setFuture] = useState<PlanProjectData[]>([]);
  const [unitPrices, setUnitPrices] = useState<Record<string, number>>(loadInitialPrices);
  const [isDark, setIsDark] = useState<boolean>(loadInitialTheme);
  // Équipements associés automatiques (groupe de clim, interrupteur, prises…) — actif par défaut
  const [autoEquip, setAutoEquip] = useState<boolean>(loadInitialAutoEquip);
  const autoEquipRef = useRef(autoEquip);
  autoEquipRef.current = autoEquip;

  const [viewMode, setViewMode] = useState<AppViewMode>('plan2d');
  const [selected, setSelected] = useState<SelectionTarget | null>(null);
  const [highlightedCircuitId, setHighlightedCircuitId] = useState<string | null>(null);
  const [trippedCircuitIds, setTrippedCircuitIds] = useState<Set<string>>(() => new Set());
  const [requestedTool, setRequestedTool] = useState<ItemType | null>(null);

  // Display layer flags
  const [showCables, setShowCables] = useState(true);
  const [showFurn, setShowFurn] = useState(true);
  const [showNames, setShowNames] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);
  const [showSafetyZones, setShowSafetyZones] = useState(true);
  const [simulateLighting, setSimulateLighting] = useState(false);

  // Sequential Luminous Staircase live state (shared across 2D & 3D)
  const [activeStairStep, setActiveStairStep] = useState<number | null>(5);
  const [stairWalkMode, setStairWalkMode] = useState<'up' | 'down' | null>(null);

  const [notice, setNotice] = useState<string | null>(null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [clockHour, setClockHour] = useState<number | null>(null);
  const [savedAt, setSavedAt] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const planSvgRef = useRef<SVGSVGElement | null>(null);
  const lastCommittedRef = useRef<PlanProjectData>(project);
  const latestProjectRef = useRef<PlanProjectData>(project);
  const handleExportJsonRef = useRef<() => void>(() => {});
  const openProjectRef = useRef<() => void>(() => {});

  // Persist project
  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
        setSavedAt(Date.now());
      } catch {
        // Ignore storage errors
      }
    }, 300);
    return () => window.clearTimeout(timer);
  }, [project]);

  useEffect(() => {
    try {
      localStorage.setItem(AUTO_EQUIP_KEY, autoEquip ? 'on' : 'off');
    } catch {
      // Ignore
    }
  }, [autoEquip]);

  useEffect(() => {
    try {
      localStorage.setItem(PRICES_KEY, JSON.stringify(unitPrices));
    } catch {
      // Ignore
    }
  }, [unitPrices]);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem(THEME_KEY, 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem(THEME_KEY, 'light');
    }
  }, [isDark]);

  useEffect(() => {
    if (!notice) return;
    const t = window.setTimeout(() => setNotice(null), 3200);
    return () => window.clearTimeout(t);
  }, [notice]);

  // Progressive step-by-step staircase animation
  const maxStairSteps = useMemo(() => {
    const stairs = project.items.filter((i) => i.type === 'staircase');
    return Math.max(14, ...stairs.map((s) => s.stepCount ?? 14));
  }, [project.items]);

  useEffect(() => {
    if (!stairWalkMode) return;
    const id = window.setInterval(() => {
      setActiveStairStep((prev) => {
        if (stairWalkMode === 'up') {
          if (prev === null || prev >= maxStairSteps) return 1;
          return prev + 1;
        }
        if (prev === null || prev <= 1) return maxStairSteps;
        return prev - 1;
      });
    }, 280);
    return () => window.clearInterval(id);
  }, [stairWalkMode, maxStairSteps]);

  const commitProject = useCallback(
    (nextRaw: PlanProjectData, recordHistory = true, opts?: { raw?: boolean }) => {
      // Équipements associés : création, suivi du parent, nettoyage (même historique d'annulation que l'action d'origine)
      const rec = opts?.raw
        ? { project: nextRaw, added: [] as PlanItem[] }
        : reconcileCompanions(latestProjectRef.current, nextRaw, autoEquipRef.current);
      const next = rec.project;
      latestProjectRef.current = next;
      if (rec.added.length > 0) {
        setNotice(
          `${rec.added.length} équipement${rec.added.length > 1 ? 's' : ''} associé${
            rec.added.length > 1 ? 's' : ''
          } placé${rec.added.length > 1 ? 's' : ''} automatiquement : ${describeAdded(rec.added)}. Ajustez leur position si besoin.`
        );
      }
      if (recordHistory) {
        setPast((prev) => [...prev.slice(-29), lastCommittedRef.current]);
        setFuture([]);
        lastCommittedRef.current = next;
      }
      setProject(next);
    },
    []
  );

  const undo = useCallback(() => {
    setPast((prev) => {
      if (prev.length === 0) return prev;
      const previous = prev[prev.length - 1];
      setFuture((f) => [lastCommittedRef.current, ...f.slice(0, 29)]);
      lastCommittedRef.current = previous;
      latestProjectRef.current = previous;
      setProject(previous);
      setSelected(null);
      return prev.slice(0, -1);
    });
  }, []);

  const redo = useCallback(() => {
    setFuture((prev) => {
      if (prev.length === 0) return prev;
      const next = prev[0];
      setPast((p) => [...p.slice(-29), lastCommittedRef.current]);
      lastCommittedRef.current = next;
      latestProjectRef.current = next;
      setProject(next);
      setSelected(null);
      return prev.slice(1);
    });
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      const isInput = tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA';

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((o) => !o);
        return;
      }
      if (isInput) return;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleExportJsonRef.current();
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        openProjectRef.current();
        return;
      }
      if (!e.metaKey && !e.ctrlKey && !e.altKey && /^[1-6]$/.test(e.key)) {
        setViewMode(VIEW_META[Number(e.key) - 1].id);
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        redo();
        return;
      }

      if ((e.key === 'Delete' || e.key === 'Backspace') && selected) {
        e.preventDefault();
        if (selected.kind === 'item') {
          commitProject(
            {
              ...project,
              items: project.items.filter((i) => i.id !== selected.id),
            },
            true
          );
        } else {
          commitProject(
            {
              ...project,
              rooms: project.rooms.filter((r) => r.id !== selected.id),
              items: project.items.filter((i) => i.roomId !== selected.id),
            },
            true
          );
        }
        setSelected(null);
      } else if (e.key === 'Escape') {
        setSelected(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selected, project, commitProject, undo, redo]);

  const { sim, materials } = useMemo(
    () => runElectricalSimulation(project, unitPrices),
    [project, unitPrices]
  );

  const toggleCircuitTrip = (circuitId: string) => {
    setTrippedCircuitIds((prev) => {
      const next = new Set(prev);
      if (next.has(circuitId)) next.delete(circuitId);
      else next.add(circuitId);
      return next;
    });
  };

  const setCircuitsTripped = useCallback((ids: string[], tripped: boolean) => {
    setTrippedCircuitIds((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => (tripped ? next.add(id) : next.delete(id)));
      return next;
    });
  }, []);

  const applyTemplate = (templateId: string) => {
    if (!templateId) return;
    let next: PlanProjectData;
    if (templateId === 'multistory') next = withDecor(createMultiStoryHouseProject(), 'house');
    else if (templateId === 't3') next = withDecor(createExampleT3Project(), 'house');
    else if (templateId === 'studio') next = withDecor(createStudioProject(), 'studio');
    else if (HOUSE_MODELS.some((m) => m.id === templateId)) next = HOUSE_MODELS.find((m) => m.id === templateId)!.build();
    else {
      next = {
        floors: [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }],
        activeFloorId: 0,
        finishStyle: 'blanc_mat',
        rooms: [],
        items: [],
        nextId: 1,
        k: 0.6,
        sockMode: 8,
        includeSurgeProtector: true,
        subscriptionKva: 9,
      };
    }
    commitProject(next, true);
    setSelected(null);
    setTrippedCircuitIds(new Set());
    setNotice(
      templateId === 'empty'
        ? 'Nouveau plan vierge créé.'
        : 'Modèle de bâtiment chargé.'
    );
  };

  const downloadFile = (filename: string, mime: string, content: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJson = async () => {
    const content = JSON.stringify({ v: 4, ...project }, null, 2);
    if (window.planelec) {
      const res = await window.planelec.saveFile({
        defaultPath: 'plan-electrique.json',
        content,
        filters: [{ name: 'Projet PlanÉlec', extensions: ['json'] }],
      });
      if (res.ok) setNotice('Projet enregistré.');
      return;
    }
    downloadFile('plan-electrique.json', 'application/json', content);
    setNotice('Projet enregistré au format JSON.');
  };
  handleExportJsonRef.current = handleExportJson;

  const openProject = async () => {
    if (window.planelec) {
      const res = await window.planelec.openFile({
        filters: [{ name: 'Projet PlanÉlec', extensions: ['json'] }],
      });
      if (res.ok && res.content) {
        await handleImportJson(new File([res.content], 'projet.json'));
      }
      return;
    }
    fileInputRef.current?.click();
  };
  openProjectRef.current = openProject;

  const handleExportPdf = () => {
    const prefs = loadBudgetPrefs();
    const doc = loadDocInfo();
    printHtml(
      buildReportHtml({
        project,
        sim,
        materials,
        vatRate: prefs.vatRate,
        includeLabor: prefs.includeLabor,
        laborPerCircuit: prefs.laborPerCircuit,
        doc: doc.reference ? doc : { ...doc, reference: defaultReference() },
        mode: 'dossier',
      })
    );
    setNotice('Dossier PDF prêt : choisissez « Enregistrer en PDF » dans la fenêtre d’impression.');
  };

  const handleImportJson = async (file: File) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!parsed || !Array.isArray(parsed.rooms) || !Array.isArray(parsed.items)) {
        setNotice('Fichier JSON non reconnu.');
        return;
      }
      const next = normalizeProject(parsed);
      commitProject(next, true);
      setSelected(null);
      setNotice('Projet importé avec succès.');
    } catch {
      setNotice('Impossible de lire ce fichier JSON.');
    }
  };

  const handleExportCsv = () => {
    const rows = materials.map(
      (m) =>
        `${m.category};${m.label};${m.quantity} ${m.unit};${Math.round(m.unitPrice)};${Math.round(m.total)}`
    );
    const csv =
      `\uFEFF${COMPANY.name};${COMPANY.engineer};${COMPANY.phones.join(' / ')};${COMPANY.email}\n` +
      `Liste de matériel;;;;${new Date().toLocaleDateString('fr-FR')}\n\n` +
      'Lot;Désignation;Quantité;Prix Unitaire HT (FCFA);Total HT (FCFA)\n' +
      rows.join('\n');
    downloadFile('liste-materiel-devis.csv', 'text/csv;charset=utf-8', csv);
    setNotice('Liste de matériel CSV exportée.');
  };

  const handleExportPlanSvg = () => {
    const fl = project.floors.find((f) => f.id === project.activeFloorId) ?? project.floors[0];
    const plan = buildPlanSvg(project, fl.id, sim.itemCircuitColor);
    if (!plan.svg) {
      setNotice('Aucune pièce à exporter sur ce niveau.');
      return;
    }
    const svg = brandSvg(plan.svg, { w: plan.width, h: plan.height }, `Plan électrique · ${fl.name}`, `${COMPANY.name} — ${new Date().toLocaleDateString('fr-FR')}`);
    downloadFile(`plan-electrique-${fl.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.svg`, 'image/svg+xml', svg);
    setNotice('Plan exporté en SVG (cartouche FALO FINITION BTP).');
  };

  const activeKw = sim.totalActiveW / 1000;
  const totalDevis = useMemo(() => materials.reduce((a, m) => a + m.total, 0), [materials]);
  const warnCount = useMemo(() => sim.roomReports.reduce((a, r) => a + r.warnCount, 0), [sim.roomReports]);

  const paletteCommands = useMemo<PaletteCommand[]>(() => {
    const viewIcons: Record<AppViewMode, React.ReactNode> = {
      plan2d: <LayoutGrid className="h-4 w-4" />,
      cablage: <Boxes className="h-4 w-4" />,
      tableau: <CircuitBoard className="h-4 w-4" />,
      vue3d: <Box className="h-4 w-4" />,
      simu: <Activity className="h-4 w-4" />,
      devis: <Wallet className="h-4 w-4" />,
    };
    const cmds: PaletteCommand[] = VIEW_META.map((v, i) => ({
      id: `view-${v.id}`,
      group: 'Navigation',
      label: `Aller à : ${v.label}`,
      hint: String(i + 1),
      icon: viewIcons[v.id],
      run: () => setViewMode(v.id),
    }));
    cmds.push(
      { id: 'a-save', group: 'Actions', label: 'Enregistrer le projet', hint: 'Ctrl S', icon: <Download className="h-4 w-4" />, run: () => handleExportJsonRef.current() },
      { id: 'a-open', group: 'Actions', label: 'Ouvrir un projet…', hint: 'Ctrl O', icon: <FolderOpen className="h-4 w-4" />, run: () => openProjectRef.current() },
      { id: 'a-undo', group: 'Actions', label: 'Annuler', hint: 'Ctrl Z', icon: <Undo2 className="h-4 w-4" />, run: undo },
      { id: 'a-redo', group: 'Actions', label: 'Rétablir', hint: 'Ctrl Y', icon: <Redo2 className="h-4 w-4" />, run: redo },
      { id: 'a-theme', group: 'Actions', label: isDark ? 'Passer en mode clair' : 'Passer en mode sombre', icon: isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />, run: () => setIsDark((p) => !p) },
      { id: 'a-csv', group: 'Export', label: 'Exporter la liste de matériel (CSV)', icon: <FileSpreadsheet className="h-4 w-4" />, run: handleExportCsv },
      { id: 'a-svg', group: 'Export', label: 'Exporter le plan 2D (SVG)', icon: <Layers className="h-4 w-4" />, run: () => { setViewMode('plan2d'); window.setTimeout(handleExportPlanSvg, 250); } },
      { id: 'a-pdf', group: 'Export', label: 'Exporter / imprimer en PDF', icon: <Printer className="h-4 w-4" />, run: handleExportPdf },
      { id: 't-multi', group: 'Modèles', label: 'Charger : Maison R+1 + escalier LED + borne VE', icon: <FileText className="h-4 w-4" />, run: () => applyTemplate('multistory') },
      { id: 't-t3', group: 'Modèles', label: 'Charger : Appartement plain-pied + terrasse', icon: <FileText className="h-4 w-4" />, run: () => applyTemplate('t3') },
      { id: 't-studio', group: 'Modèles', label: 'Charger : Studio optimisé 28 m²', icon: <FileText className="h-4 w-4" />, run: () => applyTemplate('studio') },
      ...HOUSE_MODELS.map((m) => ({ id: `t-${m.id}`, group: 'Modèles', label: `Charger : ${m.label} (${m.area})`, icon: <FileText className="h-4 w-4" />, run: () => applyTemplate(m.id) })),
      { id: 't-empty', group: 'Modèles', label: 'Nouveau plan vierge', icon: <FileText className="h-4 w-4" />, run: () => applyTemplate('empty') }
    );
    (Object.keys(TYPES) as ItemType[]).forEach((t) => {
      cmds.push({
        id: `tool-${t}`,
        group: 'Poser un équipement',
        label: `Poser : ${TYPES[t].label}`,
        keywords: 'poser ajouter placer outil',
        icon: <Lightbulb className="h-4 w-4" />,
        run: () => {
          setRequestedTool(t);
          setViewMode('plan2d');
        },
      });
    });
    return cmds;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDark, undo, redo, materials, project]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Top Bar Contract: Brand — Navigation Views — 1 Primary Action */}
      <header className="no-print sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 px-4 py-2.5 backdrop-blur-xl sm:px-6 dark:border-slate-800/80 dark:bg-slate-900/75">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-5">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setViewMode('plan2d');
            }}
            className="group flex shrink-0 items-center gap-2.5 font-display text-lg font-bold tracking-tight text-slate-950 whitespace-nowrap dark:text-white"
          >
            <span
              className="flex h-10 items-center rounded-xl border-b-2 border-[#f2b705] bg-gradient-to-r from-[#071d42] to-[#0b2a5b] px-2.5 shadow-md shadow-blue-900/25 transition-transform duration-300 group-hover:scale-[1.03]"
              title={`${COMPANY.name} — ${COMPANY.baseline}`}
            >
              <img src={LOGO_DATA_URI} alt={COMPANY.name} className="h-7 w-auto" draggable={false} />
            </span>
            <span className="flex flex-col leading-none">
              <span>PlanÉlec <span className="text-[#c99400] dark:text-[#f2b705]">Studio</span></span>
              <span className="mt-0.5 hidden text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-500 lg:block dark:text-slate-400">
                {COMPANY.name}
              </span>
            </span>
          </a>

          <nav aria-label="Vues principales" className="flex items-center gap-1 overflow-x-auto">
            {VIEW_META.map(({ id, label }, i) => {
              const active = viewMode === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setViewMode(id)}
                  title={`${label} (touche ${i + 1})`}
                  className={`relative shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium whitespace-nowrap transition-colors ${
                    active
                      ? 'text-slate-950 dark:text-white'
                      : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 -z-10 rounded-lg bg-slate-100 dark:bg-slate-800"
                      transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                    />
                  )}
                  {id === 'simu' && (
                    <span className="mr-1.5 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500 align-middle" />
                  )}
                  {label}
                </button>
              );
            })}
          </nav>

          <div className="flex shrink-0 items-center gap-2">
            <div className="hidden items-center gap-1.5 min-[1700px]:flex">
              <LiveChip icon={<Zap className="h-3 w-3" />} value={activeKw} unit="kW" decimals={1} title="Puissance appelée (après simultanéité)" />
              <LiveChip icon={<CircuitBoard className="h-3 w-3" />} value={sim.circuits.length} unit="circuits" decimals={0} title="Circuits calculés" />
              <LiveChip icon={<Wallet className="h-3 w-3" />} value={totalDevis} unit="FCFA HT" decimals={0} title="Total matériel HT" />
              {warnCount > 0 && (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-[11px] font-semibold text-amber-800 dark:bg-amber-950 dark:text-amber-300" title="Alertes de conformité NF C 15-100">
                  {warnCount} alerte{warnCount > 1 ? 's' : ''}
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={() => setPaletteOpen(true)}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white/70 px-2.5 py-1.5 text-xs text-slate-500 transition hover:border-slate-300 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-400 dark:hover:text-white"
              title="Palette de commandes (Ctrl+K)"
            >
              <Search className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Rechercher…</span>
              <kbd className="hidden rounded border border-slate-200 px-1 font-mono text-[10px] sm:inline dark:border-slate-600">Ctrl K</kbd>
            </button>
            <button
              type="button"
              onClick={handleExportJson}
              title="Enregistrer (Ctrl+S)"
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-medium text-white shadow-sm transition hover:bg-slate-800 active:scale-95 whitespace-nowrap shrink-0 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Enregistrer</span>
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6">
        {/* Engineering Settings & Project Toolbar */}
        <section
          aria-label="Paramètres du projet"
          className="no-print mb-5 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
              <span>Modèle</span>
              <select
                aria-label="Charger un modèle de bâtiment"
                value=""
                onChange={(e) => applyTemplate(e.target.value)}
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value="" disabled>
                  Charger un modèle…
                </option>
                <option value="multistory">Maison R+1 + Escalier LED + Borne VE</option>
                <option value="t3">Appartement plain-pied + Terrasse</option>
                <option value="studio">Studio optimisé 28 m²</option>
                <optgroup label="Bibliothèque de maisons">
                  {HOUSE_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label} · {m.area}
                    </option>
                  ))}
                </optgroup>
                <option value="empty">Nouveau plan vierge</option>
              </select>
            </label>

            <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
              <span>Prises / circuit</span>
              <select
                value={project.sockMode}
                onChange={(e) =>
                  commitProject(
                    { ...project, sockMode: Number(e.target.value) === 12 ? 12 : 8 },
                    true
                  )
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value={8}>8 max (1,5 mm², 16 A)</option>
                <option value={12}>12 max (2,5 mm², 20 A)</option>
              </select>
            </label>

            <label
              className="flex cursor-pointer items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300"
              title="Quand vous posez une clim, un plafonnier, une TV, un lit… les équipements nécessaires (groupe extérieur, interrupteur, prises) sont ajoutés et placés automatiquement."
            >
              <input
                type="checkbox"
                checked={autoEquip}
                onChange={(e) => setAutoEquip(e.target.checked)}
                className="rounded border-slate-300"
              />
              <Sparkles className="h-3.5 w-3.5 text-amber-500" />
              <span className="whitespace-nowrap">Équipements associés auto</span>
            </label>

            <label className="flex items-center gap-2.5 text-xs font-medium text-slate-600 dark:text-slate-300">
              <span className="whitespace-nowrap">
                Simultanéité k :{' '}
                <strong className="font-mono tabular-nums text-slate-950 dark:text-white">
                  {frNum(project.k, 2)}
                </strong>
              </span>
              <input
                type="range"
                min={0.3}
                max={1}
                step={0.05}
                value={project.k}
                onChange={(e) =>
                  commitProject({ ...project, k: parseFloat(e.target.value) }, false)
                }
                className="w-24 accent-blue-700 dark:accent-sky-400"
              />
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={undo}
              disabled={past.length === 0}
              title="Annuler (Ctrl+Z)"
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Undo2 className="h-3.5 w-3.5" />
              <span>Annuler</span>
            </button>
            <button
              type="button"
              onClick={redo}
              disabled={future.length === 0}
              title="Rétablir (Ctrl+Y)"
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Redo2 className="h-3.5 w-3.5" />
              <span>Rétablir</span>
            </button>

            <div className="h-5 w-px bg-slate-200 dark:bg-slate-700" />

            <button
              type="button"
              onClick={openProject}
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Ouvrir (.json)</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  handleImportJson(file);
                  e.target.value = '';
                }
              }}
            />

            {viewMode === 'plan2d' && (
              <button
                type="button"
                onClick={handleExportPlanSvg}
                className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Plan (.svg)</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsDark((p) => !p)}
              aria-label={isDark ? 'Passer en mode clair' : 'Passer en mode sombre'}
              title={isDark ? 'Mode clair' : 'Mode sombre'}
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {isDark ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
              <span>{isDark ? 'Clair' : 'Sombre'}</span>
            </button>
          </div>
        </section>

        {/* Active View Layout */}
        <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={viewMode}
          initial={{ opacity: 0, y: 12, filter: 'blur(4px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
        >
        {viewMode === 'plan2d' && (
          <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
            <Plan2DEditor
              project={project}
              sim={sim}
              selected={selected}
              highlightedCircuitId={highlightedCircuitId}
              trippedCircuitIds={trippedCircuitIds}
              showCables={showCables}
              showFurn={showFurn}
              showNames={showNames}
              showDimensions={showDimensions}
              showSafetyZones={showSafetyZones}
              simulateLighting={simulateLighting}
              activeStairStep={activeStairStep}
              stairWalkMode={stairWalkMode}
              requestedTool={requestedTool}
              onClearRequestedTool={() => setRequestedTool(null)}
              onToggleCables={setShowCables}
              onToggleFurn={setShowFurn}
              onToggleNames={setShowNames}
              onToggleDimensions={setShowDimensions}
              onToggleSafetyZones={setShowSafetyZones}
              onToggleSimulateLighting={setSimulateLighting}
              onChangeStairStep={setActiveStairStep}
              onSetStairWalkMode={setStairWalkMode}
              onSelect={setSelected}
              onCommitProject={commitProject}
              svgRefExternal={planSvgRef}
            />

            <ResultsSidebar
              project={project}
              sim={sim}
              highlightedCircuitId={highlightedCircuitId}
              trippedCircuitIds={trippedCircuitIds}
              onHighlightCircuit={setHighlightedCircuitId}
              onSelectRoom={(roomId) => {
                const rm = project.rooms.find((r) => r.id === roomId);
                if (rm && rm.floorId !== project.activeFloorId) {
                  commitProject({ ...project, activeFloorId: rm.floorId }, false);
                }
                setSelected({ kind: 'room', id: roomId });
              }}
            />
          </div>
        )}

        {viewMode === 'cablage' && (
          <ManualWiringLab
            finishStyle={project.finishStyle}
            onChangeFinishStyle={(style) =>
              commitProject({ ...project, finishStyle: style }, true)
            }
            onPlaceOnPlan={(toolType) => {
              setRequestedTool(toolType);
              setViewMode('plan2d');
              setNotice('Sélectionnez une pièce ou un mur sur le plan pour poser cet appareil.');
            }}
          />
        )}

        {viewMode === 'tableau' && (
          <PanelSchematicView
            sim={sim}
            subscriptionKva={project.subscriptionKva}
            includeSurgeProtector={project.includeSurgeProtector}
            trippedCircuitIds={trippedCircuitIds}
            highlightedCircuitId={highlightedCircuitId}
            onToggleCircuitTrip={toggleCircuitTrip}
            onHighlightCircuit={setHighlightedCircuitId}
            onToggleSurgeProtector={(enabled) =>
              commitProject({ ...project, includeSurgeProtector: enabled }, true)
            }
            onChangeSubscriptionKva={(kva) =>
              commitProject({ ...project, subscriptionKva: kva }, true)
            }
          />
        )}

        {viewMode === 'vue3d' && (
          <Building3DView
            project={project}
            sim={sim}
            trippedCircuitIds={trippedCircuitIds}
            activeStairStep={activeStairStep}
            stairWalkMode={stairWalkMode}
            onSetStairWalkMode={setStairWalkMode}
            onCommitProject={commitProject}
            onToggleCircuitTrip={toggleCircuitTrip}
            clockHour={clockHour}
            autoEquip={autoEquip}
            onToggleAutoEquip={() => setAutoEquip((p) => !p)}
          />
        )}

        {viewMode === 'simu' && (
          <LiveSimulationView
            project={project}
            sim={sim}
            trippedCircuitIds={trippedCircuitIds}
            onSetTripped={setCircuitsTripped}
            onClockChange={setClockHour}
          />
        )}

        {viewMode === 'devis' && (
          <BudgetReportView
            project={project}
            sim={sim}
            materials={materials}
            unitPrices={unitPrices}
            onChangeUnitPrice={(key, val) =>
              setUnitPrices((prev) => ({ ...prev, [key]: val }))
            }
            onResetPrices={() => {
              setUnitPrices({ ...DEFAULT_UNIT_PRICES });
              setNotice('Tarifs unitaires par défaut restaurés.');
            }}
            onExportCsv={handleExportCsv}
            onExportJson={handleExportJson}
            onExportPlanSvg={handleExportPlanSvg}
          />
        )}

        </motion.div>
        </AnimatePresence>

        <div className="no-print mt-8 flex flex-wrap items-center justify-between gap-4 rounded-xl border-b-4 border-[#f2b705] bg-gradient-to-r from-[#071d42] to-[#0b2a5b] px-5 py-3 text-white">
          <img src={LOGO_DATA_URI} alt={COMPANY.name} className="h-12 w-auto" draggable={false} />
          <div className="text-xs leading-relaxed text-slate-200">
            <div className="text-sm font-semibold text-white">{COMPANY.engineer}</div>
            <div>
              {COMPANY.phones.join(' / ')} · {COMPANY.email}
            </div>
            <div>
              {COMPANY.city}, {COMPANY.district}
            </div>
          </div>
          <div className="text-right text-xs font-semibold italic text-[#f2b705]">{COMPANY.baseline}</div>
        </div>
        <footer className="mt-4 border-t border-slate-200 pt-4 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          Outil de modélisation et de pré-dimensionnement électrique selon la norme NF C 15-100 (bâtiment multi-niveaux, câblage manuel, escalier séquentiel, contrôle des volumes 60 cm en salle d’eau). Pour toute mise en œuvre réelle, faites valider votre dossier par un électricien qualifié ou un bureau de contrôle Consuel.
        </footer>
      </div>

      <AnimatePresence>
        {notice && (
          <motion.div
            key={notice}
            role="status"
            aria-live="polite"
            initial={{ opacity: 0, y: 24, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 460, damping: 30 }}
            className="no-print fixed right-5 bottom-5 z-50 flex items-center gap-3 rounded-xl border border-slate-700 bg-slate-900/95 px-4 py-2.5 text-sm font-medium text-white shadow-xl backdrop-blur dark:border-slate-300 dark:bg-white/95 dark:text-slate-950"
          >
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice(null)} aria-label="Fermer la notification" className="rounded p-0.5 opacity-75 hover:opacity-100">
              <X className="h-3.5 w-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} commands={paletteCommands} />
    </div>
  );
}

function useTween(target: number, ms = 450) {
  const [v, setV] = useState(target);
  const from = useRef(target);
  useEffect(() => {
    const start = performance.now();
    const a = from.current;
    let raf = 0;
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / ms);
      const e = 1 - Math.pow(1 - p, 3);
      const cur = a + (target - a) * e;
      from.current = cur;
      setV(cur);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

function LiveChip({
  icon,
  value,
  unit,
  decimals,
  title,
}: {
  icon: React.ReactNode;
  value: number;
  unit: string;
  decimals: number;
  title: string;
}) {
  const v = useTween(value);
  return (
    <span
      title={title}
      className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/70 px-2.5 py-1 text-[11px] font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-300"
    >
      {icon}
      <span className="font-mono font-semibold tabular-nums text-slate-900 dark:text-white">{frNum(v, decimals)}</span>
      {unit}
    </span>
  );
}
