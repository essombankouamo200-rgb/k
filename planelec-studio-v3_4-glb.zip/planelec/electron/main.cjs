const { app, BrowserWindow, Menu, shell, dialog, ipcMain, screen } = require('electron');
const path = require('path');
const fs = require('fs');

const stateFile = () => path.join(app.getPath('userData'), 'window-state.json');

function loadWindowState() {
  const fallback = { width: 1440, height: 900, maximized: false };
  try {
    const s = JSON.parse(fs.readFileSync(stateFile(), 'utf8'));
    const visible = screen.getAllDisplays().some((d) => {
      const b = d.workArea;
      return s.x >= b.x - 50 && s.y >= b.y - 50 && s.x < b.x + b.width && s.y < b.y + b.height;
    });
    if (s.width >= 1024 && s.height >= 680) {
      return visible ? s : { width: s.width, height: s.height, maximized: !!s.maximized };
    }
  } catch {
    // premier lancement
  }
  return fallback;
}

function saveWindowState(win) {
  try {
    const maximized = win.isMaximized();
    const b = maximized ? win.getNormalBounds() : win.getBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ ...b, maximized }));
  } catch {
    // ignoré
  }
}

function createWindow() {
  const st = loadWindowState();
  const win = new BrowserWindow({
    x: st.x,
    y: st.y,
    width: st.width,
    height: st.height,
    minWidth: 1024,
    minHeight: 680,
    title: 'PlanÉlec Studio',
    backgroundColor: '#0f172a',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false,
    },
  });
  if (st.maximized) win.maximize();
  win.once('ready-to-show', () => win.show());
  win.on('close', () => saveWindowState(win));

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://') && !url.startsWith(process.env.ELECTRON_DEV_URL || 'file://')) {
      e.preventDefault();
    }
  });

  // F11 plein écran, Ctrl+Maj+I outils de développement
  win.webContents.on('before-input-event', (_e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') win.setFullScreen(!win.isFullScreen());
    if (input.control && input.shift && input.key.toLowerCase() === 'i') win.webContents.toggleDevTools();
  });

  if (process.env.ELECTRON_DEV_URL) {
    win.loadURL(process.env.ELECTRON_DEV_URL);
  } else {
    win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }
  return win;
}

/* --- Fichiers natifs ---------------------------------------------------- */

const winOf = (e) => BrowserWindow.fromWebContents(e.sender);

ipcMain.handle('planelec:save', async (e, opts) => {
  const { defaultPath, content, filters } = opts || {};
  if (typeof content !== 'string' || content.length > 200 * 1024 * 1024) return { ok: false };
  const res = await dialog.showSaveDialog(winOf(e), {
    defaultPath: path.join(app.getPath('documents'), String(defaultPath || 'plan.json')),
    filters: Array.isArray(filters) ? filters : [],
  });
  if (res.canceled || !res.filePath) return { ok: false };
  await fs.promises.writeFile(res.filePath, content, 'utf8');
  return { ok: true, path: res.filePath };
});

ipcMain.handle('planelec:open', async (e, opts) => {
  const res = await dialog.showOpenDialog(winOf(e), {
    defaultPath: app.getPath('documents'),
    properties: ['openFile'],
    filters: Array.isArray(opts && opts.filters) ? opts.filters : [],
  });
  if (res.canceled || !res.filePaths[0]) return { ok: false };
  const stat = await fs.promises.stat(res.filePaths[0]);
  if (stat.size > 50 * 1024 * 1024) return { ok: false };
  const content = await fs.promises.readFile(res.filePaths[0], 'utf8');
  return { ok: true, content, path: res.filePaths[0] };
});

ipcMain.handle('planelec:pdf', async (e, opts) => {
  const win = winOf(e);
  const res = await dialog.showSaveDialog(win, {
    defaultPath: path.join(app.getPath('documents'), String((opts && opts.defaultPath) || 'planelec.pdf')),
    filters: [{ name: 'PDF', extensions: ['pdf'] }],
  });
  if (res.canceled || !res.filePath) return { ok: false };
  const data = await win.webContents.printToPDF({
    printBackground: true,
    landscape: true,
    pageSize: 'A4',
    margins: { marginType: 'default' },
  });
  await fs.promises.writeFile(res.filePath, data);
  return { ok: true, path: res.filePath };
});

Menu.setApplicationMenu(null);

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
