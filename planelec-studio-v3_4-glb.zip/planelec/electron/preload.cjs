const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('planelec', {
  isElectron: true,
  saveFile: (opts) => ipcRenderer.invoke('planelec:save', opts),
  openFile: (opts) => ipcRenderer.invoke('planelec:open', opts),
  exportPdf: (opts) => ipcRenderer.invoke('planelec:pdf', opts),
});
