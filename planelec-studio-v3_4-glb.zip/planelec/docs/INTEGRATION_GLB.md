# Intégration GLB – bilan

Fichiers : `src/data/glbCatalog.ts` (catalogue), `src/utils/glbLibrary.ts` (chargement unique, cache, clones),
`src/components/Building3DView.tsx` (branchement), `src/assets/glb/` (modèles).

Phase 1 (fait) : GLTFLoader, catalogue central, chargement unique + clonage, unités en mètres vérifiées
(dos à Z≈0, face avant +Z, centré), indicateur de chargement, repli procédural si un GLB échoue.
Phase 2 (partiel) : prises simple/double, interrupteur, bouton, variateur, RJ45, USB, tableau modulaire
sur les murs (plaque teintée selon la finition). La boîte procédurale reste comme surface de sélection
invisible : sélection, déplacement, identifiants métier et collisions inchangés.
À faire : boîte de dérivation et gaine ICTA dans le câblage 3D (Phase 3), variantes/LOD (Phase 4),
validation métier (Phase 5). Rendu visuel ≠ calcul ni conformité.
