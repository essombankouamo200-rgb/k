# Feuille de route – intégration des équipements 3D PlanÉlec Studio

## État du lot livré
- [x] Prise 2P+T simple et double
- [x] Interrupteur mural
- [x] Variateur rotatif
- [x] Prise réseau RJ45
- [x] Prise USB
- [x] Gaine ICTA avec phase, neutre et terre
- [x] Boîte de dérivation ouverte avec borniers et presse-étoupes
- [x] Tableau électrique modulaire de visualisation

Les GLB sont des maquettes visuelles paramétriques exportées pour servir de base d'intégration. Vérifier dimensions, orientation et détails avant usage de production. Les modèles ne représentent pas une certification électrique ou normative.

## Phase 1 – Import et validation technique
1. Installer/activer GLTFLoader dans le projet Three.js existant.
2. Créer un catalogue central avec chemin GLB, catégorie, dimensions nominales, point d'ancrage et orientation.
3. Charger chaque GLB une seule fois et cloner les scènes pour les instances.
4. Vérifier unités en mètres, échelle, pivot, normales, matériaux et transparence.
5. Ajouter gestion d'erreurs et indicateur de chargement.

## Phase 2 – Placement dans le bâtiment
1. Aligner prises et interrupteurs sur les faces des murs.
2. Définir hauteur d'installation configurable et distance au mur.
3. Ajouter accrochage, rotation par pas, déplacement et duplication.
4. Lier chaque équipement à un identifiant métier stable du projet.
5. Empêcher les modèles visuels de perturber les collisions/navigation.

## Phase 3 – Réseaux et raccordements
1. Relier les équipements aux boîtes et au tableau via le modèle de données électrique.
2. Générer chemins de câbles et conduits sans confondre rendu 3D et connectivité électrique.
3. Appliquer les 4 modes : apparent libre, goulotte/conduit apparent, encastré, installation finie masquée.
4. Distinguer phase, neutre, terre et circuits spécialisés par règles configurables.

## Phase 4 – Qualité visuelle et interaction
1. Ajouter variantes de finition/couleur et LOD.
2. Améliorer textures PBR, visserie, détails et étiquetage.
3. Ajouter sélection, propriétés, remplacement de modèle et bibliothèque filtrable.
4. Contrôler performances avec scènes contenant plusieurs centaines d'objets.

## Phase 5 – Validation métier
1. Vérifier dimensions et symboles avec les fiches fabricants réellement retenues.
2. Faire valider les règles d'implantation et de câblage par un professionnel qualifié.
3. Tester sauvegarde/rechargement, export de plans et compatibilité des anciens projets.
4. Documenter les limites : rendu visuel ≠ calcul, conformité ou certification.
